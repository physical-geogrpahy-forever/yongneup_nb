# Pelletier AGB Eq. (5) candidate

This is an experimental candidate, NOT the canonical production package.

Only the AGB bridge is changed relative to PB4-McKenzie-nativeClimate:

AGB = e exp(f EEMT), with e=1 kg m^-2 and f=0.1 yr m^2 MJ^-1,
following Pelletier et al. (2013) Eq. (5). No Yongneup refitting or AGB clipping is used.

Wang et al. (2011) Cveg=NPP*tau_veg is calculated for diagnostics only and never feeds geomorphology.
