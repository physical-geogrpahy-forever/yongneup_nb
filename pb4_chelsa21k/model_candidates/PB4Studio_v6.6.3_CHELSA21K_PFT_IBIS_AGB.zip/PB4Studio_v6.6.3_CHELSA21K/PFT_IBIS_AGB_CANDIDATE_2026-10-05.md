# PFT-specific BIOME4 NPP to dry AGB candidate

Experimental candidate only. Canonical production package is not overwritten.

AGB_dry [kg m-2] = coefficient(PFT) * NPP [g C m-2 yr-1]

PFT0  = 0
PFT4  = 0.0286 * NPP
PFT5  = 0.0222 * NPP
PFT6  = 0.0327 * NPP
PFT7  = 0.0422 * NPP
PFT10 = 0.00285 * NPP

Source lineage: Foley/Kucharik IBIS carbon-pool equation, Xue et al.
PFT allocation and residence-time parameters, Xue dry-AGB conversion.
PFT10 uses the Xue/IBIS evergreen-shrub structural analogue.

Any unsupported vegetated dominant PFT aborts the run rather than being
silently assigned an approximate coefficient.
