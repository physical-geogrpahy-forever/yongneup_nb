# BIOME4 optLAI -> Reich leaf + BIOME4 sapwood dry AGB proxy

Experimental candidate only. Canonical production package is not overwritten.

Leaf:
log10(SLA [cm2 g-1]) = 2.44 - 0.43 log10(L_m [months])
B_leaf,dry = LAI / SLA = 0.03630780547701014 * LAI * L_m^0.43
(Reich et al. 1992, Table 1; L_m from BIOME4 pftpar(pft,7)).

Sapwood:
Cs = LAI * Cn (Haxeltine & Prentice 1996, Eq. 34).
BIOME4 v4.2b2 uses stemcarbon=0.5 kg C m-2 per unit LAI.
With fC=0.5, B_sapwood,dry = LAI for PFTs with pftpar(pft,10)=1,
and 0 for PFTs with pftpar(pft,10)=2.

Final proxy:
AGB*_dry = B_leaf,dry + B_sapwood,dry.

All 13 BIOME4 v4.2b2 PFT slots are parameterized from pftdata.
PFT13 is treated exactly as the source code (sapwood respiration present).
