# Jackson life-form sub-30 cm root-profile candidate

Candidate only, not production.

The native BIOME4 PFT-specific cumulative root fraction at 0.30 m is preserved.
For soil depth <= 0.30 m, the within-topsoil root profile is refined using
Jackson et al. (1996) life-form beta values:

- grasses and herbs: beta = 0.952
- shrubs: beta = 0.978
- trees: beta = 0.970

For depth > 0.30 m, the existing PB4 McKenzie/Jackson tail is retained.

This is not calibrated to Park et al. (2021), Jang et al. (2011), or any
Yongneup pollen score. It tests whether the previous use of identical
sub-30-cm shape for PFT7 and PFT8 suppressed shallow-soil grass competition.
