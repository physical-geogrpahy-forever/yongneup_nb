# BIOME4-SD McKenzie2003 reference audit — 2026-08-17

## 1. Scope and status

This audit applies to the **soil-depth -> available-water storage -> root-accessibility** extension only.

Status: **reference-derived coupling; no empirical/fitted soil-depth coefficient introduced**.

This does **not** certify the entire BIOME4-Pelletier coupled model as assumption-free. In particular, the pre-existing BIOME4 NPP -> Pelletier AGB bridge remains a separate unresolved provenance issue and is not justified by McKenzie et al. (2003), Jackson et al. (1996), or SoilGrids.

At the time of this McKenzie-only audit, the pre-existing project climate settings were PFT5 TCM >= -8 degC and PFT6 TWM <= 22 degC. They are not part of the McKenzie soil-depth derivation. **hotfix10n5 supersedes only the PFT6 climate sieve with Sitch et al. (2003) BoNE (TCM -32.5..-2 degC, GDD5 >= 600, TWM <= 23 degC); PFT5 remains unchanged.**

## 2. Reference inputs used

### 2.1 McKenzie et al. (2003)

Reference:
N. J. McKenzie et al. (2003), *Estimating Water Storage Capacities in Soil at Catchment Scales*, CRC for Catchment Hydrology Technical Report 03/3.

Directly used statements/equations:

1. **Profile available water capacity (AWC)** is the difference between volumetric water content at a notional field capacity of -10 kPa and at a wilting point of -1.5 MPa, integrated over profile depth:

   AWC_profile = integral [theta(-10 kPa) - theta(-1.5 MPa)] dz

2. **Root-density / plant-accessibility scaling** uses:

   f(z) = exp(-z / Xi)

   where Xi is the depth at which 37% of roots are deeper.

3. Plant-available storage is obtained by integrating profile AWC multiplied by this depth-scaling term. The report explicitly gives analytical A- and B-horizon integrals of the exponential scaling function.

Not transferred from McKenzie:
- Australian Soil Order-specific Xi values in their Table 2.
- Kyeamba Catchment calibration or soil-depth relations.
- Any Australian site coefficient.

Reason: there is no defensible one-to-one mapping from the Yongneup BIOME4 PFTs/site to those Australian soil-specific Xi values.

## 2.2 SoilGrids Yongneup point

Point supplied/inspected in SoilGrids Explore:
- longitude: 128.1236 E
- latitude: 38.2153 N

SoilGrids properties used:
- wv0010: volumetric water content at 10 kPa
- wv1500: volumetric water content at 1500 kPa

SoilGrids raw mapped units for both are 10^-3 cm3 cm^-3, equivalent to 1 mm water per metre of soil for a unit map difference.

Standard depth intervals and values used:

| depth (cm) | wv0010 | wv1500 | theta10-theta1500 (mm/m) |
|---:|---:|---:|---:|
| 0-5 | 402 | 165 | 237 |
| 5-15 | 395 | 163 | 232 |
| 15-30 | 385 | 167 | 218 |
| 30-60 | 363 | 156 | 207 |
| 60-100 | 354 | 156 | 198 |
| 100-200 | 339 | 160 | 179 |

Packaged machine-readable copy:
`pb4studio/data/yongneup_soilgrids_mckenzie2003_awc.csv`

The model uses these water-retention predictions directly. **Saxton & Rawls (2006) is not used in the main calculation**, because no pedotransfer estimate is needed when theta(-10 kPa) and theta(-1500 kPa) are already available.

Coarse fragments are **not** used in this first reference implementation. No `(1-CF)` correction is introduced because that simple correction is not prescribed by the McKenzie procedure being implemented here.

## 2.3 BIOME4 v4.2b2 native root parameters

The original BIOME4 v4.2b2 source defines parameter 6 as:

`fraction of roots in top soil layer, 30 cm from Jackson et al.`

Original source location in this package:
`fortran_src/biome4_original_4_2b2.f`, PFT parameter table.

Key native values:
- PFT4 Temperate Deciduous Trees: r30 = 0.65
- PFT5 Cool Conifer Trees: r30 = 0.52
- PFT6 Boreal Evergreen Trees: r30 = 0.83

No new PFT-specific root-depth values are fitted.

## 2.4 Jackson et al. (1996)

Reference:
R. B. Jackson et al. (1996), *A global analysis of root distributions for terrestrial biomes*, Oecologia 108:389-411, DOI 10.1007/BF00333714.

Published cumulative root relation:

Y(d) = 1 - beta^d

where d is depth and Y(d) is the cumulative proportion of roots from the surface to depth d.

For the BIOME4 native 30-cm root fraction r30:

r30 = 1 - beta^30

therefore

beta = (1-r30)^(1/30).

Since

beta^(100 z) = exp[-z / Xi]

for z in metres, the mathematically equivalent exponential length scale is

Xi = -0.30 / ln(1-r30).

This is an **analytical transformation**, not a fitted parameter.

For the key PFTs:

| PFT | BIOME4 r30 | derived beta | derived Xi (m) |
|---:|---:|---:|---:|
| 4 | 0.65 | ~0.9656 | ~0.28576 |
| 5 | 0.52 | ~0.9758 | ~0.40874 |
| 6 | 0.83 | ~0.9427 | ~0.16930 |

These derived beta values are also consistent with the published Jackson patterns: temperate coniferous forest is deep-rooted (beta about 0.976) and boreal forest is shallow-rooted (beta about 0.943).

## 3. Implemented equations

### 3.1 Profile AWC storage

For cell soil depth H:

AWC(z) = theta_10(z) - theta_1500(z)

The supplied SoilGrids interval values are integrated piecewise to actual H.

BIOME4's native hydraulic domains are retained:
- top store: 0 to min(H, 0.30 m)
- bottom store: 0.30 to min(H, 1.50 m)

The 1.50 m maximum is a **retained BIOME4 structural limit**, not a McKenzie coefficient. SoilGrids values below 1.5 m are available, but extending BIOME4 hydraulic geometry beyond its native domain would constitute an additional model redesign and is not done here.

Expected cumulative profile stores from the packaged point values:
- H=0.05 m: 11.85 mm
- H=0.10 m: 23.45 mm
- H=0.20 m: 45.95 mm
- H=0.30 m: 67.75 mm
- H=0.50 m: 109.15 mm
- H=1.00 m: 209.05 mm
- H=1.50 m: 298.55 mm
- H>1.50 m: 298.55 mm in this BIOME4 implementation

### 3.2 Finite-depth root accessibility

For each PFT with native BIOME4 top-30-cm fraction r30:

Xi = -0.30 / ln(1-r30)

For effective hydraulic depth D = min(max(H,0),1.5):

R_top(D) = 1 - exp[-min(D,0.30)/Xi]

R_bottom(D) = 0, D <= 0.30

R_bottom(D) = exp(-0.30/Xi) - exp(-D/Xi), D > 0.30

No normalization is imposed at 1.5 m. In particular, there is no factor chosen to force R_top+R_bottom to equal one at 1.5 m. This avoids introducing an undocumented normalization coefficient.

At D=0.30 m, R_top is exactly the native BIOME4 r30 by construction and R_bottom is zero.

### 3.3 BIOME4 hydrology interface

Original BIOME4 uses the fixed root split in root-zone wetness and extraction. For the `mckenzie2003` variant only, the same native equations are supplied with finite-depth weights:

wr = R_top*w_top + R_bottom*w_bottom

root extraction weight, top = R_top*(w_top/wr)

root extraction weight, bottom = R_bottom*(w_bottom/wr)

when wr>0; otherwise both extraction weights are zero.

This is explicitly classified as a **coupling implementation adaptation**: McKenzie did not implement BIOME4. The depth functions and parameters, however, are wholly determined by the cited equations and the native BIOME4/Jackson root parameter; no calibration to Yongneup vegetation observations is used.

## 4. Explicit exclusions

The following are not used in the `mckenzie2003` scientific path. The release-level variant validator also blocks the legacy `modified`, `muso_rootzone`, and `bgc_hybrid` execution modes; their historical source branches remain only as inherited code and are not selectable through the scientific API/GUI:

- no soil-depth -> NPP multiplier
- no soil-depth -> LAI multiplier
- no soil-depth -> FVC multiplier
- no pollen-fit soil-depth coefficient
- no Kang depth response
- no MuSo finite-root formula
- no Biome-BGC reduced-order response
- no Saxton & Rawls PTF in the main calculation
- no Hong et al. mapping method
- no coarse-fragment multiplier
- no McKenzie Australian Soil Order Xi table value
- no 1.5-m root-weight normalization
- no hidden 280 ppm CO2 fallback

## 5. Numerical regression checks

The package includes `tools/test_mckenzie2003_reference_contract.py` and the full diagnostic tables:
- `YONGNEUP_MCKENZIE2003_DEPTH_SENSITIVITY.csv`
- `YONGNEUP_MCKENZIE2003_ROOT_WEIGHTS.csv`

Required checks:

1. McKenzie/SoilGrids AWC integration equals the expected values listed above.
2. At H=0.30 m, the analytical root top fraction equals the original BIOME4 r30.
3. H=0.299999 -> 0.300001 m produces a continuous McKenzie2003 root-weight change.
4. In the 4 ka BIOME4 diagnostic, old WHC-only BIOME4 shows the known lower-layer discontinuity, while `mckenzie2003` does not:
   - original PFT4 wetness: 69.5 -> 75.1%; fire days: 73 -> 14
   - mckenzie2003 PFT4 wetness: 71.8 -> 71.8%; fire days: 63 -> 63
5. No direct NPP/LAI/FVC depth multiplier is present in the generated McKenzie2003 Fortran path.

## 6. Scientific interpretation boundary

The implementation supports the statement:

> Soil depth affects BIOME4 vegetation through reference-defined available-water storage and reference-derived finite root accessibility, without a fitted direct productivity multiplier.

It does **not** support the stronger statement that McKenzie et al. (2003) published a BIOME4 soil-depth extension. The connection of their storage/root-scaling framework to BIOME4 is a transparent, parameter-free coupling adaptation.

It also does not solve the independent mid-Holocene conifer climate-constraint issue. At 4 ka PFT5/PFT6 are excluded by their climatic limits before soil-depth hydrology can rescue their NPP.

## 7. References

- McKenzie, N. J. et al. (2003). *Estimating Water Storage Capacities in Soil at Catchment Scales*. CRC for Catchment Hydrology Technical Report 03/3.
- Jackson, R. B., Canadell, J., Ehleringer, J. R., Mooney, H. A., Sala, O. E., & Schulze, E. D. (1996). A global analysis of root distributions for terrestrial biomes. *Oecologia*, 108, 389-411. DOI: 10.1007/BF00333714.
- BIOME4 v4.2b2 source by J. O. Kaplan, original PFT parameter table and hydrology routines, as packaged in `fortran_src/biome4_original_4_2b2.f`.
- ISRIC SoilGrids documentation, `wv0010` and `wv1500` definitions and six standard depth intervals.
