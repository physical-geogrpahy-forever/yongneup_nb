# -*- coding: utf-8 -*-
from pathlib import Path
import json, os, sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from pb4studio.config import RunConfig,RunMode,InputPaths,TimeConfig,ScienceConfig
from pb4studio import runner
EMB=ROOT/'embedded_inputs'/'yongneup_exact20m'
OUT=ROOT/'outputs_CHELSA21K'
inputs=InputPaths(
 dem_path=str(EMB/'dem_20m_exact.tif'),
 climate_nc_path=str(EMB/'YONGNEUP_CHELSA_TRACE21k_ENVICLOUD_RAW_WIDE.csv'),
 soil_depth_path=str(EMB/'soil_depth_20m_exact_m.tif'),
 soil_texture_path=str(EMB/'soil_texture_20m_exact.tif'),
 basin_polygon_path=str(EMB/'basin_exact20m.geojson'),
 open_free_shp=str(EMB/'outlet_open_free_exact20m.geojson'),
 soil_depth_unit='m')
cfg=RunConfig(mode=RunMode.COMPARISON,inputs=inputs,
 time=TimeConfig(start_ka=21.0,end_ka=0.0,interval_kyr=0.1,snapshot_ka=(21.0,20.0,15.0,10.0,5.9,5.0,4.2,4.0,3.0,2.0,1.0,0.0)),
 resolution_m_override=20.0,requested_core_count=max(1,min(os.cpu_count() or 1,24)),
 science=ScienceConfig(biome4_variant='mckenzie2003',force_compile_biome4=True,validation_accuracy_method='per_output_time',basin_presence_min_fraction=0.01),
 output_dir=str(OUT))
OUT.mkdir(parents=True,exist_ok=True)
cfg.to_json(OUT/'run_config_CHELSA21K.json')
def progress(case_label,step_index,n_steps,ka):
 if step_index==0 or step_index==n_steps-1 or step_index%25==0: print(f'[{case_label}] {step_index+1}/{n_steps} {ka:.1f} ka BP',flush=True)
print('PB4Studio CHELSA21K self-contained Yongneup run',flush=True)
results=runner.run(cfg,progress_callback=progress)
(OUT/'run_return_summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print('FINISHED',flush=True)
