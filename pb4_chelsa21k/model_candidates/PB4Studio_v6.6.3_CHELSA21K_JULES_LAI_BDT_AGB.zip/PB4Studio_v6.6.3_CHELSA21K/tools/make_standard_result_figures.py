# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import argparse
import sys

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pb4studio.standard_report import make_standard_report


def main() -> int:
    ap = argparse.ArgumentParser(description="Generate PB4Studio standard seven-figure result board.")
    ap.add_argument("output_dir", nargs="?", default=str(ROOT / "outputs_hotfix10n10_selfcontained"))
    ap.add_argument("--allow-nearest", action="store_true", help="Use nearest saved snapshot when 100/50/10/1 ka is missing")
    ns = ap.parse_args()
    result = make_standard_report(Path(ns.output_dir), allow_nearest=bool(ns.allow_nearest))
    print("STANDARD REPORT FINISHED")
    print("Report dir:", result["report_dir"])
    for p in result["figures"]:
        print(" -", p)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
