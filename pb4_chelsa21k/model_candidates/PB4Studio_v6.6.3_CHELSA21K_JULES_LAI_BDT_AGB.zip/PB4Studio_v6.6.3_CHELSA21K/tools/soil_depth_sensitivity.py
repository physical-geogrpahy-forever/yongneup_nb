#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure-BIOME4 soil-depth sensitivity for a single, spatially uniform texture.

Scientific rules:
- BIOME4 variant is fixed to ``original``.
- Soil depth changes only native BIOME4 WHC stores.
- No Kang/MuSo/Biome-BGC depth response is used.
- The package's active PFT5 project setting and Sitch-2003 PFT6 BoNE climate sieve are compiled.
- A texture class MUST be supplied; there is deliberately no guessed default.
- Climate MUST be supplied; there is deliberately no synthetic climate fallback.

Examples:
  python tools/soil_depth_sensitivity.py --climate LateQuaternary_Environment.nc --texture-class 2
  python tools/soil_depth_sensitivity.py --climate yongneup_climate.csv --texture-class 2 --ages 5.35 4.10 1.895 0.195
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pb4studio import biome4_backend
from pb4studio.climate import load_climate, build_soil_arrays, run_biome4_dynamic_step
from pb4studio.config import ScienceConfig, _LegacyCfgShim

YONGNEUP_LON = 128.12356111111112
YONGNEUP_LAT = 38.21537777777778
# Sensitivity depths are structural breakpoints / simple diagnostic depths, not fitted coefficients.
DEFAULT_DEPTHS_M = (0.05, 0.10, 0.20, 0.30, 0.50, 1.00, 1.50)
# Midpoints of the four embedded Yongneup palaeovegetation intervals.
DEFAULT_AGES_KA = (5.35, 4.10, 1.895, 0.195)


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--climate', required=True, help='Beyer NetCDF or previously extracted monthly climate CSV')
    ap.add_argument('--texture-class', type=int, choices=(1,2,3), required=True,
                    help='Uniform original BIOME4 texture class: 1 coarse, 2 medium, 3 fine')
    ap.add_argument('--depths', type=float, nargs='+', default=list(DEFAULT_DEPTHS_M), help='Soil depths in metres')
    ap.add_argument('--ages', type=float, nargs='+', default=list(DEFAULT_AGES_KA), help='Target ages in ka BP')
    ap.add_argument('--elevation-m', type=float, required=True,
                    help='Yongneup elevation used for pressure/lapse adjustment; no guessed default')
    ap.add_argument('--lon', type=float, default=YONGNEUP_LON)
    ap.add_argument('--lat', type=float, default=YONGNEUP_LAT)
    ap.add_argument('--threads', type=int, default=1)
    ap.add_argument('--output', default='soil_depth_sensitivity_pure_biome4.csv')
    return ap.parse_args()


def main():
    a=parse_args()
    biome4_backend.FORTRAN_SOURCE_DIR = ROOT/'fortran_src'
    sci=ScienceConfig(biome4_variant='original')
    cfg=_LegacyCfgShim(sci, max(1,int(a.threads)))
    climate=load_climate(Path(a.climate), lon_value=float(a.lon), lat_value=float(a.lat))
    available=np.asarray(sorted(climate['ka_bp'].unique()),dtype=float)
    rows=[]
    for target_age in a.ages:
        age=float(available[np.argmin(np.abs(available-float(target_age)))])
        sub=climate.loc[np.isclose(climate['ka_bp'],age)].sort_values('month')
        if len(sub)!=12:
            raise RuntimeError(f'age {age} ka has {len(sub)} monthly rows, expected 12')
        temp=np.asarray(sub['temp_C'],dtype=float).reshape(12,1,1)
        prec=np.asarray(sub['precip_mm'],dtype=float).reshape(12,1,1)
        cloud=np.asarray(sub['cloud_pct'],dtype=float).reshape(12,1,1)
        tmin=np.array([[float(sub['tmin_C'].min())]],dtype=float)
        if 'co2_ppm' not in sub.columns:
            raise RuntimeError('Packaged Bereiter-2015 CO2 forcing was not attached by load_climate().')
        co2=float(sub['co2_ppm'].iloc[0])
        land=np.array([[True]])
        tex=np.array([[int(a.texture_class)]],dtype=float)
        lat=np.array([[float(a.lat)]])
        lon=np.array([[float(a.lon)]])
        elev=np.array([[float(a.elevation_m)]])
        for h in a.depths:
            soil=build_soil_arrays(cfg, np.array([[float(h)]],dtype=float), land, tex)
            veg=run_biome4_dynamic_step(cfg,temp,prec,cloud,tmin,co2,soil,lat,lon,elev,land)
            row={
                'target_age_ka':float(target_age),'climate_age_ka':age,
                'texture_class':int(a.texture_class),'depth_m':float(h),
                'whc_top_mm':float(soil['whc_top_mm'][0,0]),
                'whc_bottom_mm':float(soil['whc_bottom_mm'][0,0]),
                'whc_total_mm':float(soil['whc_top_mm'][0,0]+soil['whc_bottom_mm'][0,0]),
                'biome_id':int(veg['biome4_full_id_node'][0,0]) if np.isfinite(veg['biome4_full_id_node'][0,0]) else -9999,
                'optpft':int(veg['optpft_node'][0,0]) if np.isfinite(veg['optpft_node'][0,0]) else -9999,
                'npp_gC_m2_yr':float(veg['npp_node'][0,0]),
                'lai':float(veg['lai_node'][0,0]),
            }
            for pft in range(1,14):
                nk=f'pft{pft:02d}_raw_npp_node'
                lk=f'pft{pft:02d}_raw_lai_node'
                if nk in veg: row[f'pft{pft:02d}_npp']=float(veg[nk][0,0])
                if lk in veg: row[f'pft{pft:02d}_lai']=float(veg[lk][0,0])
            rows.append(row)
    out=Path(a.output)
    pd.DataFrame(rows).to_csv(out,index=False,encoding='utf-8-sig')
    print(out.resolve())

if __name__=='__main__':
    main()
