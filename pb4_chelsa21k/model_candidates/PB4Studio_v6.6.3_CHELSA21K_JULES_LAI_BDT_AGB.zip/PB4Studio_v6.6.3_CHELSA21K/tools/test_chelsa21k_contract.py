# -*- coding: utf-8 -*-
from pathlib import Path
import sys, numpy as np
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from pb4studio.climate import load_climate, climate_arrays_for_time
from pb4studio.config import TimeConfig, RunConfig, RunMode, InputPaths, ScienceConfig
from pb4studio.pelletier_geomorph import PelletierStrictConfig
EMB=ROOT/'embedded_inputs'/'yongneup_exact20m'
RAW=EMB/'YONGNEUP_CHELSA_TRACE21k_ENVICLOUD_RAW_WIDE.csv'
cl=load_climate(RAW)
assert len(cl)==211*12, len(cl)
assert abs(float(cl.ka_bp.min())-0.0)<1e-9 and abs(float(cl.ka_bp.max())-21.0)<1e-9
assert np.allclose(cl['lapse_rate_C_per_m'].to_numpy(float),0.0)
assert np.allclose(cl['tmin_lapse_rate_C_per_m'].to_numpy(float),0.0)
assert np.isfinite(cl[['temp_C','precip_mm','cloud_pct','tmin_C','co2_ppm']].to_numpy(float)).all()
# 0 ka MAT from the raw CHELSA monthly Tmin/Tmax transformation
x0=cl[np.isclose(cl.ka_bp,0)].sort_values('month')
assert abs(float(x0.temp_C.mean())-5.75833333333336)<1e-6
assert abs(float(x0.precip_mm.sum())-1838.0)<1e-6
# Time limit contract
TimeConfig(start_ka=21.0,end_ka=0.0,interval_kyr=.1)
try:
 TimeConfig(start_ka=21.1,end_ka=0.0,interval_kyr=.1)
 raise AssertionError('21.1 ka should be rejected')
except ValueError:
 pass
# No elevation correction: use a tiny shim and wildly different elevations.
inputs=InputPaths(dem_path=str(EMB/'dem_20m_exact.tif'),climate_nc_path=str(RAW),soil_depth_path=str(EMB/'soil_depth_20m_exact_m.tif'),soil_texture_path=str(EMB/'soil_texture_20m_exact.tif'),basin_polygon_path=str(EMB/'basin_exact20m.geojson'),soil_depth_unit='m')
cfg=RunConfig(mode=RunMode.STATIC,inputs=inputs,time=TimeConfig(start_ka=21.0,end_ka=20.9,interval_kyr=.1),science=ScienceConfig(),pelletier=PelletierStrictConfig())
leg=cfg.legacy_cfg_shim()
elev=np.array([[0.,1000.],[2000.,3000.]],dtype=float); land=np.ones((2,2),bool)
t,p,c,tm,co2=climate_arrays_for_time(leg,cl,10.0,elev,land)
for m in range(12): assert np.nanmax(t[m])-np.nanmin(t[m])<1e-7
assert np.nanmax(tm)-np.nanmin(tm)<1e-7
print('PASS CHELSA21K contract')
print('rows=',len(cl),'coverage=',cl.ka_bp.min(),cl.ka_bp.max())
print('0ka MAT=',float(x0.temp_C.mean()),'MAP=',float(x0.precip_mm.sum()))
print('lapse=',float(cl.lapse_rate_C_per_m.abs().max()))
