#!/usr/bin/env python3
"""Reference-contract diagnostic for Pelletier (2010) A/w classification.

This test is intentionally limited to issue 1 of the fluvial audit:
  * remove the fixed 1-ha valley threshold from the strict A/w path;
  * compute f=A_delta/A_delta/2 using Freeman-style MFD (p=1.1);
  * classify f<1.2 as valley and f>=1.2 as hillslope.

It does NOT exercise outlet self-erosion (issue 2) or adaptive fluvial dt (issue 3); those are covered by separate diagnostics in this package.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import rasterio

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pb4studio.boundary import BoundaryConfig, BoundaryType
from pb4studio.pelletier_geomorph import (
    PelletierStrictConfig,
    _bilinear_half_cell_dem,
    _half_cell_boundary_config,
    _mfd_flow_accumulation_area_on_routing_surface,
    _routing_surface_to_boundaries,
    d8_flow_accumulation_area_multi_boundary,
    pelletier2010_unit_contributing_area,
)


def planar_test() -> dict:
    nrows = ncols = 40
    dx = 10.0
    # Strict monotonic planar surface flowing south; bottom row open.
    z = np.repeat(np.arange(nrows, 0, -1, dtype=float)[:, None], ncols, axis=1)
    land = np.ones_like(z, dtype=bool)
    bt = np.full(z.shape, int(BoundaryType.CLOSED), dtype=np.uint8)
    bt[-1, :] = int(BoundaryType.OPEN_FREE)
    bc = BoundaryConfig(boundary_type=bt, free_tie_break_eps_m=1e-4)
    cfg = PelletierStrictConfig()
    _, _, _, f, valley = pelletier2010_unit_contributing_area(cfg, z, land, bc, dx)
    core = np.zeros_like(land)
    core[4:-4, 4:-4] = True
    vals = f[core & np.isfinite(f)]
    valley_core = int(np.count_nonzero(valley & core))
    # Expected from the resolution-dependence method: planar hillslopes f ~ 2.
    assert abs(float(np.median(vals)) - 2.0) < 0.05, float(np.median(vals))
    assert valley_core == 0, valley_core
    return {
        "median_f": float(np.median(vals)),
        "p05_f": float(np.quantile(vals, 0.05)),
        "p95_f": float(np.quantile(vals, 0.95)),
        "core_valley_cells": valley_core,
    }


def load_yongneup(dem_path: Path, outlet_path: Path):
    with rasterio.open(dem_path) as ds:
        z = ds.read(1).astype("float64")
        nodata = ds.nodata
        land = np.isfinite(z)
        if nodata is not None and np.isfinite(nodata):
            land &= z != nodata
        transform = ds.transform
        crs = ds.crs
        dx = abs(float(transform.a))
    bc = BoundaryConfig.from_shapefiles(
        land_mask=land,
        transform=transform,
        dst_crs=crs,
        open_free_shp=outlet_path,
        snap_to_land_boundary=True,
    )
    return z, land, transform, crs, dx, bc


def mfd_export_conservation(cfg, z, land, bc, dx) -> dict:
    route, _, _, _, opens = _routing_surface_to_boundaries(
        z=z, land=land, boundary_cfg=bc, dx_m=dx,
        sink_fill_enabled=bool(cfg.sink_fill_enabled),
    )
    a = _mfd_flow_accumulation_area_on_routing_surface(
        route, land, opens, dx, cfg.mfd_slope_exponent,
    )
    native_export = float(sum(a[r, c] for r, c in opens))
    native_total = float(np.count_nonzero(land) * dx * dx)

    fz, fland = _bilinear_half_cell_dem(z, land)
    fbc = _half_cell_boundary_config(bc, fland)
    fdx = dx / 2.0
    froute, _, _, _, fopens = _routing_surface_to_boundaries(
        z=fz, land=fland, boundary_cfg=fbc, dx_m=fdx,
        sink_fill_enabled=bool(cfg.sink_fill_enabled),
    )
    fa = _mfd_flow_accumulation_area_on_routing_surface(
        froute, fland, fopens, fdx, cfg.mfd_slope_exponent,
    )
    fine_export = float(sum(fa[r, c] for r, c in fopens))
    fine_total = float(np.count_nonzero(fland) * fdx * fdx)
    return {
        "native_total_area_m2": native_total,
        "native_export_area_m2": native_export,
        "native_abs_mass_balance_error_m2": abs(native_total-native_export),
        "fine_total_area_m2": fine_total,
        "fine_export_area_m2": fine_export,
        "fine_abs_mass_balance_error_m2": abs(fine_total-fine_export),
        "native_open_cells": [list(map(int, rc)) for rc in opens],
        "fine_open_cells": [list(map(int, rc)) for rc in fopens],
    }


def yongneup_test(dem_path: Path, outlet_path: Path, csv_path: Path) -> dict:
    z, land, transform, crs, dx, bc = load_yongneup(dem_path, outlet_path)
    cfg = PelletierStrictConfig()
    unit_a, a_native, a_halfmax, f, valley = pelletier2010_unit_contributing_area(
        cfg, z, land, bc, dx,
    )

    # Legacy fixed-1-ha comparison only; it is not used by the new strict path.
    d8_area, *_ = d8_flow_accumulation_area_multi_boundary(z, land, bc, dx, cfg)
    legacy_valley = land & (d8_area >= 10000.0)

    # Prove old threshold/cell-size correction controls are inert in the new path.
    cfg_a = PelletierStrictConfig(
        valley_area_threshold_m2=1.0,
        cell_size_correction_enabled=False,
        cell_size_reference_m=1.0,
    )
    cfg_b = PelletierStrictConfig(
        valley_area_threshold_m2=1.0e12,
        cell_size_correction_enabled=True,
        cell_size_reference_m=1000.0,
    )
    out_a = pelletier2010_unit_contributing_area(cfg_a, z, land, bc, dx)
    out_b = pelletier2010_unit_contributing_area(cfg_b, z, land, bc, dx)
    max_diff = 0.0
    for xa, xb in zip(out_a[:4], out_b[:4]):
        mask = np.isfinite(xa) & np.isfinite(xb)
        if np.any(mask):
            max_diff = max(max_diff, float(np.max(np.abs(xa[mask] - xb[mask]))))
    assert max_diff == 0.0, max_diff
    assert np.array_equal(out_a[4], out_b[4])

    overlap = int(np.count_nonzero(legacy_valley & valley))
    old_only = int(np.count_nonzero(legacy_valley & ~valley))
    new_only = int(np.count_nonzero(~legacy_valley & valley & land))
    q = np.quantile(f[land & np.isfinite(f)], [0.01,0.05,0.10,0.25,0.50,0.75,0.90,0.95,0.99])

    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow([
            "row","col","elevation_m","d8_area_m2","legacy_1ha_valley",
            "mfd_A_delta_m2","mfd_A_halfmax_m2","f_A_delta_over_half",
            "pelletier2010_valley","unit_contributing_area_A_over_w_m",
        ])
        for r, c in np.argwhere(land):
            w.writerow([
                int(r), int(c), float(z[r,c]), float(d8_area[r,c]), int(legacy_valley[r,c]),
                float(a_native[r,c]), float(a_halfmax[r,c]), float(f[r,c]), int(valley[r,c]), float(unit_a[r,c]),
            ])

    return {
        "dem": str(dem_path),
        "shape": [int(v) for v in z.shape],
        "valid_cells": int(np.count_nonzero(land)),
        "dx_m": dx,
        "crs": str(crs),
        "open_cells_native": [list(map(int, rc)) for rc in bc.all_open_cells()],
        "legacy_1ha_valley_cells": int(np.count_nonzero(legacy_valley)),
        "pelletier2010_valley_cells": int(np.count_nonzero(valley)),
        "pelletier2010_valley_fraction": float(np.count_nonzero(valley)/np.count_nonzero(land)),
        "overlap_cells": overlap,
        "legacy_only_cells": old_only,
        "new_only_cells": new_only,
        "f_quantiles": {k: float(v) for k,v in zip(
            ["p01","p05","p10","p25","p50","p75","p90","p95","p99"], q
        )},
        "legacy_controls_max_numeric_difference": max_diff,
        "mass_balance": mfd_export_conservation(cfg, z, land, bc, dx),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dem", type=Path, required=True)
    ap.add_argument("--outlet", type=Path, required=True)
    ap.add_argument("--json", type=Path, required=True)
    ap.add_argument("--csv", type=Path, required=True)
    args = ap.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.csv.parent.mkdir(parents=True, exist_ok=True)
    report = {
        "scope": "fluvial issue 1 only: Pelletier 2010 grid-resolution-dependence A/w classifier",
        "problem_2_outlet_boundary_exercised_by_this_test": False,
        "problem_3_adaptive_fluvial_timestep_exercised_by_this_test": False,
        "synthetic_planar": planar_test(),
        "yongneup": yongneup_test(args.dem, args.outlet, args.csv),
    }
    args.json.write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
