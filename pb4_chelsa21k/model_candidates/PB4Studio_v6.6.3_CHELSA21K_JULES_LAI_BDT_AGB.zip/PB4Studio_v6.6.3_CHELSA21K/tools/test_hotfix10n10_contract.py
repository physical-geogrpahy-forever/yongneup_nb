# -*- coding: utf-8 -*-
from pathlib import Path
import hashlib, json, sys, tempfile
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from pb4studio.config import RunConfig,RunMode,InputPaths,TimeConfig,ScienceConfig
from pb4studio.runner import build_initial_grid
from pb4studio.climate import load_climate,climate_arrays_for_time,build_soil_arrays,run_biome4_dynamic_step,vegetation_array
from pb4studio import biome4_backend

EMB=ROOT/'embedded_inputs/yongneup_exact20m'
inputs=InputPaths(dem_path=str(EMB/'dem_20m_exact.tif'),climate_nc_path=str(EMB/'climate_yongneup_128.25E_38.25N.csv'),soil_depth_path=str(EMB/'soil_depth_20m_exact_m.tif'),soil_texture_path=str(EMB/'soil_texture_20m_exact.tif'),basin_polygon_path=str(EMB/'basin_exact20m.geojson'),open_free_shp=str(EMB/'outlet_open_free_exact20m.geojson'),soil_depth_unit='m')
cfg=RunConfig(mode=RunMode.STATIC,inputs=inputs,time=TimeConfig(start_ka=24,end_ka=0,interval_kyr=.1),resolution_m_override=20.0,requested_core_count=2,science=ScienceConfig(biome4_variant='mckenzie2003',force_compile_biome4=True))
g=build_initial_grid(cfg,20.0)
assert g.shape==(20,23) and int(g.land.sum())==298
assert abs(float(np.mean(g.soil0[g.land]))-1.9403876762928847)<2e-6
source=ROOT/'fortran_src/biome4_original_4_2b2.f'
sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert sha=='23b5194b7b2ca25439f9a97e4f55c147c78ee9198c5f953ca2fac8c4ce689968',sha
# patched source must retain native PFT2--13 competition (only original PFT1 disable)
with tempfile.TemporaryDirectory() as td:
    dst=Path(td)/'patched.f'
    biome4_backend._patch_fortran_source(source,dst,'mckenzie2003')
    txt=dst.read_text(encoding='latin-1')
    assert 'PFT5_REF_M19_GDD900' in txt and 'SITCH2003_BONE' in txt
    for p in (2,3,7,9,10,11,12,13):
        assert f'pfts({p})=0' not in txt, p

leg=cfg.legacy_cfg_shim(); leg.force_compile_biome4=True
cl=load_climate(Path(inputs.climate_nc_path),float(np.mean(g.lon[g.land])),float(np.mean(g.lat[g.land])))
# exact source ages are unchanged, midpoint ages must be strict linear midpoints for monthly climate.
t22=climate_arrays_for_time(leg,cl,22.0,g.dem0,g.land)
t24=climate_arrays_for_time(leg,cl,24.0,g.dem0,g.land)
t23=climate_arrays_for_time(leg,cl,23.0,g.dem0,g.land)
for a,b,m in zip(t22[:4],t24[:4],t23[:4]):
    mask=np.isfinite(m)
    assert np.nanmax(np.abs(m[mask] - 0.5*(a[mask]+b[mask]))) < 2e-4
# CO2 is continuous direct interpolation; midpoint need not equal climate-slice midpoint exactly.
assert np.isfinite(t23[4])

# Full-PFT LGM smoke: cold/open PFTs must be allowed to pass when climate permits.
temp,prec,cloud,tmin,co2=t24
soil=build_soil_arrays(leg,g.soil0,g.land,g.texture0)
r=run_biome4_dynamic_step(leg,temp,prec,cloud,tmin,co2,soil,g.lat,g.lon,g.dem0,g.land)
passes={p:int(np.sum(np.asarray(r[f'pft{p:02d}_constraint_pass_node'])[g.land]>0)) for p in range(1,14)}
assert passes[1]==0
assert any(passes[p]>0 for p in (7,10,11,12,13)),passes

# Reduced classification contracts.
shape=(1,1); land=np.ones(shape,bool)
def field(v): return np.array([[v]],dtype=float)
base={'biome4_full_id_node':field(21),'optpft_node':field(10),'npp_node':field(50),'lai_node':field(0.5)}
assert int(vegetation_array(base,shape,land)[0,0])==3  # vegetated desert -> open
base={'biome4_full_id_node':field(27),'optpft_node':field(0),'npp_node':field(0),'lai_node':field(0)}
assert int(vegetation_array(base,shape,land)[0,0])==4
base={'biome4_full_id_node':field(11),'optpft_node':field(7),'npp_node':field(300),'lai_node':field(3)}
assert int(vegetation_array(base,shape,land)[0,0])==0  # deciduous taiga -> conifer
base={'biome4_full_id_node':field(22),'optpft_node':field(12),'npp_node':field(100),'lai_node':field(1)}
assert int(vegetation_array(base,shape,land)[0,0])==3
# Mixed: PFT7 conifer group vs PFT4 broadleaf group, 51% threshold.
base={'biome4_full_id_node':field(7),'optpft_node':field(7),'npp_node':field(300),'lai_node':field(3)}
for p in range(2,8): base[f'pft{p:02d}_mod_npp_node']=field(0)
base['pft04_mod_npp_node']=field(49); base['pft07_mod_npp_node']=field(51)
assert int(vegetation_array(base,shape,land)[0,0])==0
base['pft04_mod_npp_node']=field(50); base['pft07_mod_npp_node']=field(50)
assert int(vegetation_array(base,shape,land)[0,0])==2
print('PASS hotfix10n10 all-PFT/interpolation/classification contract')
print('grid=20x23 active=298 meanH=',float(np.mean(g.soil0[g.land])))
print('PFT constraint pass counts at 24 ka=',passes)
print('source_sha256=',sha)
