import sys, json, time
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
from pb4studio.pelletier_geomorph import PelletierStrictConfig, threshold_slope_adjustment
from pb4studio.boundary import BoundaryConfig, BoundaryType
from pb4studio.runner import _advance_geomorph_interval_adaptive
S=np.load(BASE/'diagnostics'/'reference_6ka_geomorph_state.npz')
z10=S['z'].astype(float); h10=S['h'].astype(float); b10=S['b'].astype(float); land10=S['land'].astype(bool); e10=S['eemt'].astype(float); a10=S['agb'].astype(float)
dx=float(abs(S['transform'][0]))*2

def agg(arr):
    out=np.full((20,23),np.nan); mask=np.zeros((20,23),bool)
    for r in range(20):
        for c in range(23):
            sl=(slice(2*r,2*r+2),slice(2*c,2*c+2)); m=land10[sl]&np.isfinite(arr[sl])
            if np.any(m): out[r,c]=np.mean(arr[sl][m]); mask[r,c]=1
    return out,mask
z,land=agg(z10); h,_=agg(h10); b,_=agg(b10); eemt,_=agg(e10); agb,_=agg(a10); z=b+h
outlet=(2,16); assert land[outlet]
bt=np.zeros_like(land,dtype=np.uint8); bt[outlet]=int(BoundaryType.OPEN_FREE)
bc=BoundaryConfig(bt,free_tie_break_eps_m=0.0001)

def face_stats(zz,sc):
    vals=[]; nr,nc=zz.shape
    for r in range(nr):
      for c in range(nc):
        if not land[r,c]: continue
        for dr,dc in ((0,1),(1,0)):
          rr,cc=r+dr,c+dc
          if rr<nr and cc<nc and land[rr,cc]: vals.append(abs(zz[r,c]-zz[rr,cc])/dx)
    vals=np.asarray(vals)
    return {'faces':int(vals.size),'over':int(np.sum(vals>sc+1e-10)),'at':int(np.sum(np.abs(vals-sc)<=1e-10)),'max':float(vals.max()),'p95':float(np.quantile(vals,.95))}

def run(tol):
    cfg=PelletierStrictConfig()
    assert cfg.hillslope_critical_slope == 1.5, cfg.hillslope_critical_slope
    sc=cfg.hillslope_critical_slope
    initial_face=face_stats(z,sc)
    zi,bi,hi,iadj=threshold_slope_adjustment(cfg,z,b,h,land,bc,dx)
    after_init=face_stats(zi,sc)
    t0=time.time()
    zo,bo,ho,stats=_advance_geomorph_interval_adaptive(
        cfg,z,b,h,land,bc,eemt,agb,interval_kyr=1.0,dx_m=dx,
        max_substep_kyr=0.1,min_substep_kyr=1e-12,
        fluvial_max_change_tolerance_m=tol,adaptive=True)
    arr=ho[land]; dh=(ho-hi)[land]
    last=stats.pop('last_diagnostics')
    out={
      'tol_m':tol,'Sc_default':sc,'dx_m':dx,'land_cells':int(land.sum()),
      'initial_faces':initial_face,
      'initial_adjustment':{
        'cells':int(np.sum(iadj['adjusted_mask'])),
        'lowering_sum_m':float(np.sum(iadj['surface_lowering_m'][land])),
        'lowering_max_m':float(np.max(iadj['surface_lowering_m'][land])),
        'soil_removed_depthsum_m':float(np.sum(iadj['soil_removed_m'][land])),
        'bedrock_lowered_depthsum_m':float(np.sum(iadj['bedrock_lowered_m'][land])),
        'mass_equiv_export_depthsum_m':float(np.sum(iadj['threshold_export_mass_equivalent_m'][land])),
      },
      'faces_after_initial_adjustment':after_init,
      'accepted_substeps':stats['accepted_substeps'],
      'rejected_total':stats['rejected_or_halved_substeps'],
      'rejected_process_change':stats['rejected_process_change_trials'],
      'rejected_other':stats['rejected_other_trials'],
      'min_dt_yr':stats['min_dt_kyr']*1000,
      'max_dt_yr':stats['max_dt_kyr']*1000,
      'max_accepted_process_change_m':stats['max_accepted_process_change_m'],
      'H_min_m':float(arr.min()),'H_mean_m':float(arr.mean()),'H_max_m':float(arr.max()),
      'H_zero_cells':int(np.sum(arr<=1e-9)),'H_gt5_cells':int(np.sum(arr>5)),
      'dH_min_m':float(dh.min()),'dH_mean_m':float(dh.mean()),'dH_max_m':float(dh.max()),
      'final_faces':face_stats(zo,sc),
      'outlet_dz_m':float(zo[outlet]-zi[outlet]),
      'supply_limited_cells_last':int(np.sum(last['hillslope_supply_limited_mask'][land])),
      'threshold_post_cells_last':int(np.sum(last['threshold_post_surface_lowering_m'][land]>1e-12)),
      'runtime_s':time.time()-t0,
    }
    return out,(zo,bo,ho)

outdir=BASE/'diagnostics'; outdir.mkdir(exist_ok=True)
results={}; states={}
for tol in (0.025,0.0125):
    o,state=run(tol); results[str(tol)]=o; states[str(tol)]=state
    (outdir/f'hillslope_sc15_20m_1k_tol_{tol}.json').write_text(json.dumps(o,indent=2),encoding='utf-8')
z1,b1,h1=states['0.025']; z2,b2,h2=states['0.0125']
conv={
 'H_max_abs_diff_m':float(np.max(np.abs((h1-h2)[land]))),
 'H_p99_abs_diff_m':float(np.quantile(np.abs((h1-h2)[land]),.99)),
 'H_mean_abs_diff_m':float(np.mean(np.abs((h1-h2)[land]))),
 'z_max_abs_diff_m':float(np.max(np.abs((z1-z2)[land]))),
 'z_p99_abs_diff_m':float(np.quantile(np.abs((z1-z2)[land]),.99)),
 'b_max_abs_diff_m':float(np.max(np.abs((b1-b2)[land]))),
 'H_zero_mask_diff_cells':int(np.sum(((h1<=1e-9)!=(h2<=1e-9))&land)),
}
(outdir/'hillslope_sc15_20m_1k_convergence.json').write_text(json.dumps(conv,indent=2),encoding='utf-8')
print(json.dumps({'runs':results,'convergence':conv},indent=2))
