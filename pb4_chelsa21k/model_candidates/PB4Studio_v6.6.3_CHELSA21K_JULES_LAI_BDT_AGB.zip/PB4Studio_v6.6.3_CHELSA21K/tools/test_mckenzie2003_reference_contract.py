#!/usr/bin/env python3
"""Strict numerical/source-contract checks for BIOME4-SD McKenzie2003."""
from __future__ import annotations

import math
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pb4studio.climate import _mckenzie2003_yongneup_awc_stores


def root_weights(r30: float, depth_m: float):
    xi = -0.30 / math.log(1.0 - r30)
    rd = min(max(depth_m, 0.0), 1.5)
    rtop = 1.0 - math.exp(-min(rd, 0.30) / xi) if rd > 0 else 0.0
    rbot = (math.exp(-0.30 / xi) - math.exp(-rd / xi)) if rd > 0.30 else 0.0
    return xi, rtop, rbot


def main() -> None:
    # 1) McKenzie/SoilGrids AWC integration contract.
    depths = np.array([0.05, 0.10, 0.20, 0.30, 0.50, 1.00, 1.50, 1.94])
    top, bottom = _mckenzie2003_yongneup_awc_stores(depths, max_depth_m=1.5)
    total = top + bottom
    expected = np.array([11.85, 23.45, 45.95, 67.75, 109.15, 209.05, 298.55, 298.55])
    np.testing.assert_allclose(total, expected, rtol=0, atol=1e-9)

    # 2) Native BIOME4 r30 must be recovered exactly at 0.30 m.
    pfts = {4: 0.65, 5: 0.52, 6: 0.83}
    for pft, r30 in pfts.items():
        xi, rtop, rbot = root_weights(r30, 0.30)
        assert math.isclose(rtop, r30, rel_tol=0, abs_tol=2e-15), (pft, xi, rtop, r30)
        assert rbot == 0.0

    # 3) Analytical continuity across the old 30-cm discontinuity.
    for pft, r30 in pfts.items():
        _, ta, ba = root_weights(r30, 0.299999)
        _, tb, bb = root_weights(r30, 0.300001)
        assert abs(tb - ta) < 1e-5
        assert bb >= 0.0 and bb < 1e-5

    # 4) Generated source must contain reference-derived path and not normalize to 1.5 m.
    fsrc = ROOT / 'fortran_src' / '_biome4_fortran_batch_build_mckenzie2003' / 'biome4_mckenzie2003_batch_instrumented.f'
    if fsrc.exists():
        text = fsrc.read_text(encoding='latin-1')
        required = [
            'xi=-0.30/log(1.0-root0)',
            'rtop_eff=1.0-exp(-min(rd,0.30)/xi)',
            'rbot_eff=exp(-0.30/xi)-exp(-rd/xi)',
            'wr = rtop_eff*w(1) + rbot_eff*w(2)',
            'r1(1) = rtop_eff * (w(1)/wr)',
            'r1(2) = rbot_eff * (w(2)/wr)',
        ]
        for needle in required:
            assert needle in text, needle
        forbidden = ['kang_nppfac', 'kang_laifac', 'pb4_rootspace(pft)=', 'bgc_leafalloc']
        for needle in forbidden:
            assert needle not in text, needle

    # 5) Existing full diagnostic must show continuity in the actual BIOME4 run.
    diag = ROOT / 'YONGNEUP_MCKENZIE2003_DEPTH_SENSITIVITY.csv'
    if diag.exists():
        df = pd.read_csv(diag)
        sub = df[(df['variant']=='mckenzie2003') & (df['target_age_ka']==4.0) & (df['depth_m'].isin([0.299999, 0.300001]))]
        assert len(sub) == 2
        sub = sub.sort_values('depth_m')
        assert abs(float(sub.iloc[1]['pft04_wetness']) - float(sub.iloc[0]['pft04_wetness'])) <= 0.1
        assert abs(float(sub.iloc[1]['pft04_firedays']) - float(sub.iloc[0]['pft04_firedays'])) <= 1.0

    # 6) Packaged SoilGrids CSV must match hard-coded source-of-run values exactly.
    profile = pd.read_csv(ROOT / 'pb4studio' / 'data' / 'yongneup_soilgrids_mckenzie2003_awc.csv')
    np.testing.assert_array_equal(profile['awc_mm_per_m'].to_numpy(), np.array([237,232,218,207,198,179]))

    print('PASS: BIOME4-SD McKenzie2003 strict reference contract')
    print('AWC totals mm:', dict(zip(depths.tolist(), total.tolist())))
    for pft, r30 in pfts.items():
        xi, _, _ = root_weights(r30, 0.30)
        print(f'PFT{pft}: r30={r30:.2f}, Xi={xi:.9f} m')


if __name__ == '__main__':
    main()
