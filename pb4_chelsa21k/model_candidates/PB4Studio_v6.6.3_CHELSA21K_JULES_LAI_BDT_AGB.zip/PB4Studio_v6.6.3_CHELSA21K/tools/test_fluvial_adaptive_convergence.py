#!/usr/bin/env python3
"""Issue-3 numerical convergence audit for fluvial timestep rejection.

This deliberately disables hillslope transport so the test isolates the fluvial
adaptive control. It does not alter production code. Each tolerance is run in a
fresh Python subprocess to avoid any cross-run state/performance contamination.
"""
from __future__ import annotations
import argparse, json, subprocess, sys, time
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import pb4studio.pelletier_geomorph as pg
import pb4studio.runner as rr
from pb4studio.boundary import BoundaryConfig, BoundaryType

def boundary_from_state(land, outlet):
    bt=np.full(land.shape,int(BoundaryType.CLOSED),dtype=np.uint8)
    bt[outlet]=int(BoundaryType.OPEN_FREE)
    return BoundaryConfig(boundary_type=bt, free_tie_break_eps_m=1e-4)

def run_one(state, tol, interval, max_dt, min_dt, outlet):
    z0=state['z'].astype(float); h0=state['h'].astype(float); b0=state['b'].astype(float)
    eemt=state['eemt'].astype(float); agb=state['agb'].astype(float); land=state['land'].astype(bool)
    transform=state['transform'].astype(float); dx=abs(float(transform[0]))
    bc=boundary_from_state(land,outlet)
    def no_hill(cfg,z,h,land,eemt,agb,dt_kyr,dx_m):
        slope,cost=pg.local_slope_and_costheta(z,dx_m,land)
        return np.zeros_like(z,dtype=float),slope,cost,{"hillslope_supply_limited_mask":np.zeros_like(land,dtype=bool)}
    def no_threshold(cfg,z,b,h,land,boundary_cfg,dx_m,block_size=512):
        zeros=np.zeros_like(z,dtype=float)
        return z.copy(),b.copy(),h.copy(),{
          "surface_lowering_m":zeros,"soil_removed_m":zeros,"bedrock_lowered_m":zeros,
          "adjusted_mask":np.zeros_like(land,dtype=bool),"threshold_export_mass_equivalent_m":zeros}
    orig=pg.nonlinear_hillslope_change_closed_boundary
    orig_thr=pg.threshold_slope_adjustment
    pg.nonlinear_hillslope_change_closed_boundary=no_hill
    pg.threshold_slope_adjustment=no_threshold
    try:
        t=time.time()
        z,b,h,stats=rr._advance_geomorph_interval_adaptive(
            pg.PelletierStrictConfig(), z0.copy(), b0.copy(), h0.copy(), land, bc,
            eemt, agb, interval, dx, max_dt, min_dt, tol, True,
        )
        elapsed=time.time()-t
    finally:
        pg.nonlinear_hillslope_change_closed_boundary=orig
        pg.threshold_slope_adjustment=orig_thr
    diag=stats.pop('last_diagnostics')
    report={
        'tol_m':tol,'elapsed_s':elapsed,'stats':stats,
        'h_min':float(h[land].min()),'h_mean':float(h[land].mean()),'h_max':float(h[land].max()),
        'bare_n':int(np.count_nonzero((h<=1e-8)&land)),
        'dz_min':float((z-z0)[land].min()),'dz_mean':float((z-z0)[land].mean()),'dz_max':float((z-z0)[land].max()),
        'outlet':list(map(int,outlet)),'outlet_h_change':float(h[outlet]-h0[outlet]),
        'outlet_z_change':float(z[outlet]-z0[outlet]),
        'outlet_last_fluvial':float(diag['fluvial_regolith_erosion_m'][outlet]+diag['fluvial_bedrock_erosion_m'][outlet]),
        'last_valley_n':int(np.count_nonzero(diag['valley_mask'][land])),
    }
    return report, {'z':z,'b':b,'h':h,'land':land}

def parser():
    ap=argparse.ArgumentParser()
    ap.add_argument('--state',type=Path,default=ROOT/'diagnostics/reference_6ka_geomorph_state.npz')
    ap.add_argument('--outdir',type=Path,default=ROOT/'diagnostics')
    ap.add_argument('--tolerances',type=float,nargs='+',default=[0.025,0.0125])
    ap.add_argument('--interval-kyr',type=float,default=1.0)
    ap.add_argument('--max-dt-kyr',type=float,default=0.1)
    ap.add_argument('--min-dt-kyr',type=float,default=1e-8)
    ap.add_argument('--outlet-row',type=int,default=5)
    ap.add_argument('--outlet-col',type=int,default=33)
    ap.add_argument('--worker-tol',type=float,default=None,help=argparse.SUPPRESS)
    return ap

def worker(args):
    args.outdir.mkdir(parents=True,exist_ok=True)
    state=np.load(args.state); outlet=(args.outlet_row,args.outlet_col)
    rep,arr=run_one(state,args.worker_tol,args.interval_kyr,args.max_dt_kyr,args.min_dt_kyr,outlet)
    tag=f'{args.worker_tol:g}'
    (args.outdir/f'_issue3_worker_{tag}.json').write_text(json.dumps(rep,indent=2)+'\n')
    np.savez_compressed(args.outdir/f'_issue3_worker_{tag}.npz',**arr)

def main():
    args=parser().parse_args()
    if args.worker_tol is not None:
        worker(args); return
    args.outdir.mkdir(parents=True,exist_ok=True)
    results={}; arrays={}
    for tol in args.tolerances:
        cmd=[sys.executable,str(Path(__file__).resolve()),'--worker-tol',str(tol),'--state',str(args.state),'--outdir',str(args.outdir),'--interval-kyr',str(args.interval_kyr),'--max-dt-kyr',str(args.max_dt_kyr),'--min-dt-kyr',str(args.min_dt_kyr),'--outlet-row',str(args.outlet_row),'--outlet-col',str(args.outlet_col)]
        subprocess.run(cmd,check=True)
        tag=f'{tol:g}'
        results[str(tol)]=json.loads((args.outdir/f'_issue3_worker_{tag}.json').read_text())
        arrays[tol]=np.load(args.outdir/f'_issue3_worker_{tag}.npz')
    comparisons=[]
    for a,b in zip(args.tolerances[:-1],args.tolerances[1:]):
        A,B=arrays[a],arrays[b]; land=A['land'].astype(bool); row={'coarse_tol_m':a,'fine_tol_m':b}
        for k in ('h','z','b'):
            d=np.abs(A[k].astype(float)-B[k].astype(float))[land]
            row[f'{k}_max_abs_m']=float(d.max()); row[f'{k}_mean_abs_m']=float(d.mean()); row[f'{k}_p99_abs_m']=float(np.quantile(d,0.99))
        row['bare_mask_diff_n']=int(np.count_nonzero(((A['h']<=1e-8)!=(B['h']<=1e-8))&land))
        comparisons.append(row)
    out={'scope':'issue 3 fluvial adaptive timestep only; hillslope transport disabled in audit','runs':results,'halving_comparisons':comparisons}
    (args.outdir/'fluvial_issue3_reproducible_convergence.json').write_text(json.dumps(out,indent=2)+'\n')
    for tol in args.tolerances:
        tag=f'{tol:g}'
        for suffix in ('json','npz'):
            (args.outdir/f'_issue3_worker_{tag}.{suffix}').unlink(missing_ok=True)
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
