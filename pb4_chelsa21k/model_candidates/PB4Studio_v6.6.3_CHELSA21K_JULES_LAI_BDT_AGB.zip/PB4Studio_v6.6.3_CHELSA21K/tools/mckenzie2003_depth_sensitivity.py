#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reference-audited BIOME4-SD depth sensitivity for Yongneup.

No fitted soil-depth response is used.
- McKenzie et al. (2003): profile AWC = theta(-10 kPa)-theta(-1.5 MPa),
  integrated with depth; root-density scaling f(z)=exp(-z/Xi).
- SoilGrids Yongneup point supplied by user: wv0010 and wv1500 at six depths.
- BIOME4 v4.2b2: PFT parameter 6 is root fraction in top 30 cm from Jackson et al.
- Jackson et al. (1996): cumulative roots Y(d)=1-beta**d.
  Therefore Xi=-0.30/log(1-r30) m exactly; no fitted coefficient.
- BIOME4 native hydraulic-profile maximum 1.5 m is retained.
"""
from __future__ import annotations
import argparse, math, sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from pb4studio import biome4_backend
from pb4studio.climate import load_climate, climate_arrays_for_time, build_soil_arrays, run_biome4_dynamic_step
from pb4studio.config import ScienceConfig, _LegacyCfgShim

YONGNEUP_LON=128.1236
YONGNEUP_LAT=38.2153
PFT_R30={1:.69,2:.70,3:.67,4:.65,5:.52,6:.83,7:.83,8:.83,9:.57,10:.53,11:.93,12:.93,13:.93}
DEFAULT_DEPTHS=(.05,.10,.20,.299999,.30,.300001,.35,.50,1.0,1.5,1.94)
DEFAULT_AGES=(6.,5.,4.,3.,2.,1.,0.)

def root_metrics(pft:int,h:float):
    r30=PFT_R30[pft]
    xi=-0.30/math.log(1.0-r30)
    rd=min(max(float(h),0.0),1.5)
    rtop=1.0-math.exp(-min(rd,.30)/xi) if rd>0 else 0.0
    rbot=(math.exp(-.30/xi)-math.exp(-rd/xi)) if rd>.30 else 0.0
    return xi,rtop,rbot,rtop+rbot

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--climate',required=True)
    ap.add_argument('--elevation-m',type=float,required=True)
    ap.add_argument('--depths',type=float,nargs='+',default=list(DEFAULT_DEPTHS))
    ap.add_argument('--ages',type=float,nargs='+',default=list(DEFAULT_AGES))
    ap.add_argument('--threads',type=int,default=1)
    ap.add_argument('--output',default='YONGNEUP_MCKENZIE2003_DEPTH_SENSITIVITY.csv')
    a=ap.parse_args()
    biome4_backend.FORTRAN_SOURCE_DIR=ROOT/'fortran_src'
    climate=load_climate(Path(a.climate),lon_value=YONGNEUP_LON,lat_value=YONGNEUP_LAT)
    available=np.asarray(sorted(climate['ka_bp'].unique()),float)
    land=np.array([[True]])
    tex=np.array([[2.0]])
    lat=np.array([[YONGNEUP_LAT]])
    lon=np.array([[YONGNEUP_LON]])
    elev=np.array([[a.elevation_m]],float)
    rows=[]
    for variant in ('original','mckenzie2003'):
        sci=ScienceConfig(biome4_variant=variant)
        cfg=_LegacyCfgShim(sci,max(1,int(a.threads)))
        for target in a.ages:
            age=float(available[np.argmin(np.abs(available-float(target)))])
            temp,prec,cloud,tmin,co2=climate_arrays_for_time(cfg,climate,age,elev,land)
            for h in a.depths:
                soil=build_soil_arrays(cfg,np.array([[float(h)]],float),land,tex)
                veg=run_biome4_dynamic_step(cfg,temp,prec,cloud,tmin,co2,soil,lat,lon,elev,land)
                row={
                    'variant':variant,'target_age_ka':float(target),'climate_age_ka':age,'depth_m':float(h),
                    'whc_top_mm':float(soil['whc_top_mm'][0,0]),'whc_bottom_mm':float(soil['whc_bottom_mm'][0,0]),
                    'whc_total_mm':float(soil['whc_top_mm'][0,0]+soil['whc_bottom_mm'][0,0]),
                    'biome_id':int(veg['biome4_full_id_node'][0,0]),'optpft':int(veg['optpft_node'][0,0]),
                    'npp_gC_m2_yr':float(veg['npp_node'][0,0]),'lai':float(veg['lai_node'][0,0]),
                }
                for pft in range(1,14):
                    for src,sfx in ((f'pft{pft:02d}_raw_npp_node','npp'),(f'pft{pft:02d}_raw_lai_node','lai'),
                                    (f'pft{pft:02d}_wetness_node','wetness'),(f'pft{pft:02d}_aet_node','aet'),
                                    (f'pft{pft:02d}_firedays_node','firedays'),(f'pft{pft:02d}_greendays_node','greendays')):
                        if src in veg: row[f'pft{pft:02d}_{sfx}']=float(veg[src][0,0])
                rows.append(row)
    out=Path(a.output)
    pd.DataFrame(rows).to_csv(out,index=False,encoding='utf-8-sig')
    rootrows=[]
    for pft in range(1,14):
        for h in a.depths:
            xi,rt,rb,rs=root_metrics(pft,h)
            rootrows.append({'pft':pft,'biome4_r30':PFT_R30[pft],'Xi_m':xi,'depth_m':float(h),
                             'root_weight_top':rt,'root_weight_bottom':rb,'root_weight_total':rs})
    pd.DataFrame(rootrows).to_csv(out.with_name('YONGNEUP_MCKENZIE2003_ROOT_WEIGHTS.csv'),index=False,encoding='utf-8-sig')
    print(out.resolve())

if __name__=='__main__': main()
