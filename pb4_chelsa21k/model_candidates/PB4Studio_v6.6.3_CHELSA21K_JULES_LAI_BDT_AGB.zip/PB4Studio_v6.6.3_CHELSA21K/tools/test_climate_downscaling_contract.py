from __future__ import annotations

import numpy as np
import pandas as pd

from pb4studio.climate import climate_arrays_for_time
from types import SimpleNamespace


def _base_df():
    rows=[]
    for m in range(1,13):
        rows.append(dict(ka_bp=4.0, month=m, temp_C=float(m), precip_mm=10.0, cloud_pct=50.0, tmin_C=-10.0, co2_ppm=260.0))
    return pd.DataFrame(rows)


def main():
    cfg=SimpleNamespace()
    elev=np.array([[100.0, 200.0]], dtype='float64')
    land=np.array([[True, True]])

    # No explicit lapse -> raw Beyer value everywhere, irrespective of elevation.
    df=_base_df()
    temp, _, _, tmin, _=climate_arrays_for_time(cfg, df, 4.0, elev, land)
    assert np.allclose(temp[:,0,0], np.arange(1,13,dtype=float))
    assert np.allclose(temp[:,0,1], np.arange(1,13,dtype=float))
    assert np.allclose(tmin, -10.0)

    # Monthly lapse is applied row-by-row around one explicit reference elevation.
    df=_base_df()
    df['reference_elevation_m']=100.0
    df['lapse_rate_C_per_m']=-np.arange(1,13,dtype=float)/10000.0
    temp, _, _, tmin, _=climate_arrays_for_time(cfg, df, 4.0, elev, land)
    assert np.allclose(temp[:,0,0], np.arange(1,13,dtype=float))
    expected=np.arange(1,13,dtype=float) + (-np.arange(1,13,dtype=float)/10000.0)*100.0
    assert np.allclose(temp[:,0,1], expected)
    # Coldest monthly mean is January (month 1): -0.0001 C/m.
    assert np.isclose(tmin[0,1], -10.01)

    # A non-zero lapse without a source-grid reference elevation is forbidden.
    df=_base_df()
    df['lapse_rate_C_per_m']=-0.0065
    try:
        climate_arrays_for_time(cfg, df, 4.0, elev, land)
    except ValueError as exc:
        assert 'reference_elevation_m' in str(exc)
    else:
        raise AssertionError('non-zero lapse without reference elevation did not fail')

    print('PASS: explicit climate downscaling contract')

if __name__ == '__main__':
    main()
