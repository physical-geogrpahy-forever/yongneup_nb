# -*- coding: utf-8 -*-
"""
gui/state.py — GUI 폼 값과 RunConfig 사이의 순수 변환 로직.

Qt 위젯과 완전히 분리해서, 위젯 없이도(헤드리스 환경에서도) 이 모듈만으로
RunConfig 조립 로직을 테스트할 수 있게 한다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

from pb4studio.config import RunConfig, RunMode, InputPaths, TimeConfig, ScienceConfig
from pb4studio.pelletier_geomorph import PelletierStrictConfig


@dataclass
class GuiState:
    # 입력 자료
    dem_path: str = ""
    basin_path: str = ""
    climate_path: str = ""
    soil_depth_path: str = ""
    soil_depth_unit: str = "cm"
    soil_texture_path: str = ""
    biome4_variant: str = "mckenzie2003"  # Yongneup production: McKenzie2003 + native BIOME4 PFT2-13 competition
    resolution_m_override: Optional[float] = None  # None=DEM 네이티브 해상도 자동사용

    # 경계 조건
    open_free_shp: str = ""
    open_fixed_slope_shp: str = ""
    common_slope_percent: float = 0.5
    snap_open_cells_to_boundary: bool = False  # 기본 꺼짐: shp 좌표를 그대로 신뢰

    # 시간
    start_ka: float = 21.0
    end_ka: float = 0.0
    interval_kyr: float = 0.1
    snapshot_interval_ka: float = 5.0  # 지도/CSV 스냅샷을 저장할 간격 (내부 계산은 interval_kyr 그대로 유지)

    # 모드/자원
    mode: str = "comparison"  # "static" | "dynamic" | "comparison"
    requested_core_count: Optional[int] = None
    output_dir: str = "outputs"

    # 검증
    use_embedded_validation: bool = True
    custom_validation_csv: str = ""
    basin_presence_min_percent: float = 1.0
    validation_accuracy_method: str = "per_output_time"  # "per_output_time" | "interval_any_dt"

    # 계수 (필드명 -> 값, 기본값에서 바뀐 것만 채우면 됨)
    pelletier_overrides: Dict[str, object] = field(default_factory=dict)

    def _snapshot_ka_tuple(self) -> tuple:
        """start_ka에서 end_ka까지 snapshot_interval_ka 간격의 스냅샷 시점 목록.
        간격이 0 이하이거나 이상하면 None을 반환해 '매 스텝 저장'(기존 기본값)으로 대체한다."""
        if self.snapshot_interval_ka is None or self.snapshot_interval_ka <= 0:
            return None
        times = []
        t = self.start_ka
        while t > self.end_ka + 1e-9:
            times.append(round(t, 6))
            t -= self.snapshot_interval_ka
        times.append(self.end_ka)
        # Standard result-board ages are always saved when they fall inside the
        # simulated interval. This only adds output snapshots; the model time
        # step and scientific calculations are unchanged.
        for age in (100.0, 50.0, 10.0, 1.0):
            if self.end_ka - 1e-9 <= age <= self.start_ka + 1e-9:
                times.append(float(age))
        return tuple(sorted(set(times), reverse=True))

    def missing_required_fields(self) -> list[str]:
        """실행 전 필수 입력이 비어있는지 확인. 비어있는 필드의 한글 이름 목록 반환."""
        required = {
            "dem_path": "DEM 파일", "basin_path": "유역 폴리곤 파일",
            "climate_path": "CHELSA RAW WIDE CSV", "soil_depth_path": "토심 자료",
            "soil_texture_path": "토성 자료",
        }
        return [label for field_name, label in required.items() if not getattr(self, field_name).strip()]

    def to_run_config(self) -> RunConfig:
        if self.missing_required_fields():
            raise ValueError("필수 입력 자료가 비어 있습니다: " + ", ".join(self.missing_required_fields()))

        inputs = InputPaths(
            dem_path=self.dem_path,
            climate_nc_path=self.climate_path,
            soil_depth_path=self.soil_depth_path,
            soil_texture_path=self.soil_texture_path,
            basin_polygon_path=self.basin_path,
            open_free_shp=self.open_free_shp or None,
            open_fixed_slope_shp=self.open_fixed_slope_shp or None,
            soil_depth_unit=self.soil_depth_unit,
            validation_points_csv=(
                None if self.use_embedded_validation
                else (self.custom_validation_csv or "")
            ),
        )
        time_cfg = TimeConfig(
            start_ka=self.start_ka, end_ka=self.end_ka, interval_kyr=self.interval_kyr,
            snapshot_ka=self._snapshot_ka_tuple(),
        )
        pelletier = PelletierStrictConfig(**self.pelletier_overrides)
        if self.biome4_variant not in {"mckenzie2003", "original"}:
            raise ValueError(
                "이 배포판은 BIOME4-SD McKenzie2003 경로와 원본 BIOME4 비교 기준만 실행할 수 있습니다."
            )

        validation_percent = float(self.basin_presence_min_percent)
        if not (0.0 < validation_percent <= 100.0):
            raise ValueError("고식생 유역 점유율 판정 기준은 0보다 크고 100 이하인 값이어야 합니다.")
        if self.mode not in {"static", "dynamic", "comparison"}:
            raise ValueError("실행 모드는 정적모델, 동적모델 또는 정적+동적 비교여야 합니다.")
        if self.validation_accuracy_method not in {"per_output_time", "interval_any_dt"}:
            raise ValueError("고식생 정확도 측정 방법이 올바르지 않습니다.")

        return RunConfig(
            mode=RunMode(self.mode),
            inputs=inputs,
            time=time_cfg,
            common_slope_percent=self.common_slope_percent,
            snap_open_cells_to_boundary=self.snap_open_cells_to_boundary,
            resolution_m_override=self.resolution_m_override,
            requested_core_count=self.requested_core_count,
            pelletier=pelletier,
            science=ScienceConfig(
                biome4_variant=self.biome4_variant,
                basin_presence_min_fraction=validation_percent / 100.0,
                validation_accuracy_method=self.validation_accuracy_method,
            ),
            output_dir=self.output_dir,
        )
