# -*- coding: utf-8 -*-
"""gui/main.py — PB4Studio 실행 진입점.

Windows 배포판에서는 이 파일을 PyInstaller 엔트리포인트로 쓴다.

중요: PyInstaller로 묶인 앱에서는 ``__file__`` 기반 경로 계산이 신뢰할 수 없다
(번들된 모듈은 실제 디스크 파일이 아니라 PYZ 아카이브 안에 있을 수 있어서,
``Path(__file__).resolve()``가 기대한 경로를 안 준다). 대신 PyInstaller가
심어주는 ``sys._MEIPASS``(번들 데이터가 실제로 풀려있는 폴더)를 써야 한다.
이 파일은 개발 모드(그냥 python gui/main.py로 실행)와 frozen 모드(PyInstaller로
빌드된 .exe) 양쪽에서 다 fortran_src/를 올바르게 찾도록 두 경로를 모두 시도한다.
"""
from __future__ import annotations

import sys
from pathlib import Path

EXPECTED_VERSION = "6.6.3-CHELSA21K-envicloud-nolapse"

# Source launcher hardening: when a file inside gui/ is executed directly, Python
# normally puts gui/ rather than the project root at sys.path[0].  That can make
# an older site-packages copy of ``pb4studio`` win the import.  Force this
# release root to the front before importing any local package.
if not getattr(sys, "frozen", False):
    _PROJECT_ROOT = Path(__file__).resolve().parent.parent
    _root_text = str(_PROJECT_ROOT)
    if not sys.path or sys.path[0] != _root_text:
        try:
            sys.path.remove(_root_text)
        except ValueError:
            pass
        sys.path.insert(0, _root_text)
else:
    _PROJECT_ROOT = None


def _find_fortran_source_dir() -> Path | None:
    candidates = []
    if getattr(sys, "frozen", False):
        # PyInstaller onedir/onefile 빌드: 번들 데이터는 sys._MEIPASS 밑에 있다.
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            candidates.append(Path(meipass) / "fortran_src")
        # onedir 빌드는 실행파일과 같은 폴더(_internal 옆)에도 있을 수 있어 보험으로 추가.
        candidates.append(Path(sys.executable).resolve().parent / "fortran_src")
        candidates.append(Path(sys.executable).resolve().parent / "_internal" / "fortran_src")
    else:
        # 개발 모드: gui/main.py 기준 프로젝트 루트.
        candidates.append(Path(__file__).resolve().parent.parent / "fortran_src")

    for c in candidates:
        if c.exists():
            return c
    return None



def _verify_engine_provenance():
    """Fail fast if an older/stale PB4Studio engine was imported.

    This specifically protects source-mode launches from accidentally importing
    a previously installed ``pb4studio`` from site-packages.  Such a stale import
    can resurrect already-fixed errors (including the old ``ka_label`` NameError)
    even when the GUI files themselves came from a newer ZIP.
    """
    import pb4studio
    from pb4studio import runner

    loaded_version = str(getattr(pb4studio, "__version__", "<unknown>"))
    runner_path = Path(getattr(runner, "__file__", "<unknown>")).resolve()

    if loaded_version != EXPECTED_VERSION:
        raise RuntimeError(
            "다른 버전의 PB4Studio 엔진이 불러와졌습니다.\n"
            f"기대 버전: {EXPECTED_VERSION}\n"
            f"실제 버전: {loaded_version}\n"
            f"runner 경로: {runner_path}\n\n"
            "기존 압축해제 폴더/설치본을 닫고 이 ZIP을 새 폴더에 풀어 "
            "START_PB4Studio.bat으로 실행하십시오."
        )

    if not getattr(sys, "frozen", False):
        expected_pkg = (Path(__file__).resolve().parent.parent / "pb4studio").resolve()
        if expected_pkg not in runner_path.parents:
            raise RuntimeError(
                "현재 ZIP의 엔진이 아니라 외부/구버전 pb4studio가 불러와졌습니다.\n"
                f"기대 엔진 폴더: {expected_pkg}\n"
                f"실제 runner 경로: {runner_path}"
            )
    return loaded_version, runner_path


def main() -> int:
    from PySide6.QtWidgets import QApplication, QMessageBox

    app = QApplication(sys.argv)
    app.setApplicationName("PB4Studio CHELSA21K")

    try:
        loaded_version, runner_path = _verify_engine_provenance()
    except Exception as exc:
        QMessageBox.critical(None, "PB4Studio 버전/경로 오류", str(exc))
        return 2

    from gui.main_window import MainWindow
    from pb4studio import biome4_backend

    fortran_src = _find_fortran_source_dir()
    if fortran_src is not None:
        biome4_backend.FORTRAN_SOURCE_DIR = fortran_src

    _write_startup_log(fortran_src, loaded_version=loaded_version, runner_path=runner_path)

    if fortran_src is None:
        QMessageBox.warning(
            None, "BIOME4 소스를 찾지 못함",
            "fortran_src 폴더의 원본 BIOME4 v4.2b2 소스를 찾지 못했습니다.\n"
            "설치 폴더 구조가 바뀌었을 수 있습니다. 실행은 계속되지만, "
            "'5. 실행' 단계에서 BIOME4 관련 오류가 날 것입니다.\n\n"
            f"찾아본 위치 기준 실행파일 경로: {sys.executable}",
        )

    window = MainWindow()
    window.show()
    return app.exec()


def _write_startup_log(fortran_src: Path | None, loaded_version: str = "<unknown>", runner_path: Path | None = None) -> None:
    """콘솔 창이 없는 GUI 앱(console=False)이라 문제 진단용으로 로그 파일을 남긴다.
    실행파일과 같은 폴더에 pb4studio_startup.log 로 저장된다."""
    try:
        log_dir = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path.cwd()
        log_path = log_dir / "pb4studio_startup.log"
        lines = [
            f"frozen = {getattr(sys, 'frozen', False)}",
            f"sys.executable = {sys.executable}",
            f"sys._MEIPASS = {getattr(sys, '_MEIPASS', None)}",
            f"expected_version = {EXPECTED_VERSION}",
            f"loaded_version = {loaded_version}",
            f"runner_path = {runner_path}",
            f"fortran_src found = {fortran_src}",
        ]
        log_path.write_text("\n".join(lines), encoding="utf-8")
    except Exception:  # noqa: BLE001 - 로그 기록 실패는 앱 실행을 막으면 안 됨
        pass


if __name__ == "__main__":
    sys.exit(main())

