# -*- coding: utf-8 -*-
"""gui/tab_time_mode.py — 시간 범위, 실행 모드, 병렬 코어 수, 출력 폴더."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout, QDoubleSpinBox, QSpinBox,
    QRadioButton, QButtonGroup, QPushButton, QLabel, QHBoxLayout, QCheckBox, QComboBox,
)

from gui.widgets_common import PathPickerRow
from pb4studio.config import TimeConfig, resolve_core_count
import os


class TimeModeTab(QWidget):
    def __init__(self, get_climate_path_callback, parent=None):
        super().__init__(parent)
        self._get_climate_path = get_climate_path_callback
        layout = QVBoxLayout(self)

        time_group = QGroupBox("시간 범위")
        time_form = QFormLayout(time_group)
        self.start_spin = QDoubleSpinBox()
        self.start_spin.setRange(0.001, 21.0)
        self.start_spin.setValue(21.0)
        self.start_spin.setSuffix(" ka BP")
        self.end_spin = QDoubleSpinBox()
        self.end_spin.setRange(0.0, 21.0)
        self.end_spin.setValue(0.0)
        self.end_spin.setSuffix(" ka BP")
        self.interval_spin = QDoubleSpinBox()
        self.interval_spin.setRange(0.001, 10_000.0)
        self.interval_spin.setDecimals(3)
        self.interval_spin.setValue(0.1)
        self.interval_spin.setSuffix(" kyr")
        time_form.addRow("시작 시점(과거)", self.start_spin)
        time_form.addRow("종료 시점(현재에 가까움)", self.end_spin)
        time_form.addRow("기후·식생 갱신 및 출력 간격", self.interval_spin)
        chelsa_note = QLabel(
            "CHELSA21K 버전은 21 ka BP보다 오래된 시작시점을 허용하지 않습니다. "
            "기후 CSV의 실제 커버리지보다 긴 범위도 실행되지 않습니다."
        )
        chelsa_note.setWordWrap(True)
        time_form.addRow("CHELSA 제한", chelsa_note)

        geomorph_note = QLabel(
            "지형발달은 각 기후·식생 간격 사이를 최대 0.1 kyr(100년) 단위로 계산하며, "
            "Pelletier 안정시간 조건이 더 짧으면 자동으로 시간간격을 절반씩 줄입니다."
        )
        geomorph_note.setWordWrap(True)
        time_form.addRow("지형발달 내부 계산", geomorph_note)

        self.snapshot_interval_spin = QDoubleSpinBox()
        self.snapshot_interval_spin.setRange(0.0, 10_000.0)
        self.snapshot_interval_spin.setDecimals(2)
        self.snapshot_interval_spin.setValue(5.0)
        self.snapshot_interval_spin.setSuffix(" ka")
        time_form.addRow("스냅샷 저장 간격 (지도/그래프용, 0=매 스텝 저장)", self.snapshot_interval_spin)

        self.check_climate_button = QPushButton("기후자료 시간범위와 대조")
        self.check_climate_button.clicked.connect(self._on_check_climate)
        time_form.addRow(self.check_climate_button)
        self.climate_status = QLabel("")
        self.climate_status.setWordWrap(True)
        time_form.addRow(self.climate_status)
        layout.addWidget(time_group)

        validation_group = QGroupBox("고식생 검증")
        validation_form = QFormLayout(validation_group)
        self.basin_presence_percent_spin = QDoubleSpinBox()
        self.basin_presence_percent_spin.setRange(0.01, 100.0)
        self.basin_presence_percent_spin.setDecimals(2)
        self.basin_presence_percent_spin.setSingleStep(1.0)
        self.basin_presence_percent_spin.setValue(1.0)
        self.basin_presence_percent_spin.setSuffix(" %")
        self.basin_presence_percent_spin.setToolTip(
            "각 모델 출력시점에서 관측 식생이 0~3 식생유형으로 유효하게 분류된 유역 셀 중 "
            "이 값 이상을 차지하면 해당 dt를 일치로 판정합니다."
        )
        validation_form.addRow("유효식생 점유율 기준", self.basin_presence_percent_spin)

        self.validation_accuracy_method_combo = QComboBox()
        self.validation_accuracy_method_combo.addItem("출력시점(dt)별 일치율", userData="per_output_time")
        self.validation_accuracy_method_combo.addItem("구간 내 최소 1회(dt) 출현율", userData="interval_any_dt")
        self.validation_accuracy_method_combo.setToolTip(
            "출력시점(dt)별: 고식생 구간 안의 모든 모델 출력시점을 각각 평가합니다. "
            "구간 내 최소 1회(dt): 각 고식생 구간에서 한 번이라도 점유율 기준 이상이면 그 구간을 일치로 판정합니다."
        )
        validation_form.addRow("정확도 측정 방법", self.validation_accuracy_method_combo)
        validation_note = QLabel(
            "출력시점(dt)별 방법은 기본 출력간격 0.1 kyr에서 100년 시간단위 일치율입니다. "
            "구간 내 최소 1회(dt) 방법은 각 고식생 연대구간을 한 번씩만 평가합니다. "
            "선택한 점유율 기준 하나에서 정확도(%)를 결과 탭과 CSV로 확인할 수 있습니다. "
            "정적+동적 비교모드에서도 같은 단일 점유율 기준만 사용하며 1%·5%·10% 자동 비교는 하지 않습니다. "
            "구간 평균 면적비율은 보조 진단으로 별도 저장됩니다."
        )
        validation_note.setWordWrap(True)
        validation_form.addRow(validation_note)
        layout.addWidget(validation_group)

        mode_group = QGroupBox("실행 모드")
        mode_layout = QHBoxLayout(mode_group)
        self.radio_static = QRadioButton("정적모델")
        self.radio_dynamic = QRadioButton("동적모델")
        self.radio_comparison = QRadioButton("정적+동적 비교")
        self.radio_comparison.setChecked(True)
        self.mode_group_btns = QButtonGroup(self)
        for i, rb in enumerate([self.radio_static, self.radio_dynamic, self.radio_comparison]):
            self.mode_group_btns.addButton(rb, i)
            mode_layout.addWidget(rb)
        layout.addWidget(mode_group)

        res_group = QGroupBox("병렬처리 / 출력")
        res_form = QFormLayout(res_group)
        detected = os.cpu_count() or 1
        self.core_spin = QSpinBox()
        self.core_spin.setRange(1, detected)
        self.core_spin.setValue(resolve_core_count(None))
        res_form.addRow(f"병렬 코어 수 (이 컴퓨터에서 감지된 코어: {detected})", self.core_spin)
        self.output_row = PathPickerRow("출력 폴더", mode="save_dir")
        self.output_row.set_path("outputs")
        res_form.addRow(self.output_row)
        layout.addWidget(res_group)

        layout.addStretch(1)

    def _on_check_climate(self) -> None:
        climate_path = self._get_climate_path()
        if not climate_path:
            self.climate_status.setText("⚠ '입력 자료' 탭에서 기후자료(NetCDF/CSV)를 먼저 선택하세요.")
            return
        try:
            t = TimeConfig(start_ka=self.start_spin.value(), end_ka=self.end_spin.value(),
                            interval_kyr=self.interval_spin.value())
            warnings = t.validate_against_climate(Path(climate_path))
        except Exception as exc:  # noqa: BLE001
            self.climate_status.setText(f"⚠ 확인 중 오류: {exc}")
            return
        if warnings:
            self.climate_status.setText("⚠ " + " / ".join(warnings))
        else:
            coverage = t.climate_coverage_ka(Path(climate_path))
            self.climate_status.setText(
                f"✓ 기후자료 커버리지({coverage['min_ka']:.2f}~{coverage['max_ka']:.2f} ka BP) 안에 들어옵니다."
            )

    def mode_value(self) -> str:
        if self.radio_static.isChecked():
            return "static"
        if self.radio_dynamic.isChecked():
            return "dynamic"
        return "comparison"

    def set_mode_value(self, mode: str) -> None:
        if mode not in {"static", "dynamic", "comparison"}:
            raise ValueError(f"알 수 없는 실행 모드입니다: {mode}")
        {"static": self.radio_static, "dynamic": self.radio_dynamic,
         "comparison": self.radio_comparison}[mode].setChecked(True)

    def validation_accuracy_method_value(self) -> str:
        return str(self.validation_accuracy_method_combo.currentData())

    def set_validation_accuracy_method_value(self, method: str) -> None:
        idx = self.validation_accuracy_method_combo.findData(method)
        if idx < 0:
            raise ValueError(f"알 수 없는 정확도 측정 방법입니다: {method}")
        self.validation_accuracy_method_combo.setCurrentIndex(idx)

    def apply_state(self, state) -> None:
        self.start_spin.setValue(state.start_ka)
        self.end_spin.setValue(state.end_ka)
        self.interval_spin.setValue(state.interval_kyr)
        self.snapshot_interval_spin.setValue(state.snapshot_interval_ka)
        self.basin_presence_percent_spin.setValue(state.basin_presence_min_percent)
        self.set_validation_accuracy_method_value(state.validation_accuracy_method)
        self.set_mode_value(state.mode)
        if state.requested_core_count:
            self.core_spin.setValue(state.requested_core_count)
        self.output_row.set_path(state.output_dir)

    def collect_into(self, state) -> None:
        state.start_ka = self.start_spin.value()
        state.end_ka = self.end_spin.value()
        state.interval_kyr = self.interval_spin.value()
        state.snapshot_interval_ka = self.snapshot_interval_spin.value()
        state.basin_presence_min_percent = self.basin_presence_percent_spin.value()
        state.validation_accuracy_method = self.validation_accuracy_method_value()
        state.mode = self.mode_value()
        state.requested_core_count = self.core_spin.value()
        state.output_dir = self.output_row.path() or "outputs"
