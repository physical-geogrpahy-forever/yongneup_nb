# hotfix10n10 standard-report layout fix audit (2026-08-18)

This patch changes **report layout only**. Scientific model equations, PFT constraints/classification, climate interpolation, WHC/root handling, geomorphic coupling, and validation rules are unchanged from hotfix10n10.

## Changes

- Numeric map boards (`01_soil_depth_maps.png`, `06_elevation_maps.png`)
  - three equal-width map columns: dynamic / static / dynamic-minus-static
  - both colorbars moved to dedicated far-right GridSpec columns
  - no figure-level fixed-position colorbar axes remain
- Vegetation map board (`03_vegetation_maps.png`)
  - equal-width 3-column GridSpec
  - dedicated bottom margin for the vegetation/match legend
- Mean time-series (`02_mean_soil_depth.png`, `07_mean_elevation.png`)
  - unified figure size and fixed outer margins
- Vegetation-ratio plot (`04_vegetation_ratio.png`)
  - fixed title/axes/legend spacing and dedicated bottom legend margin
- Palaeovegetation accuracy (`05_paleovegetation_accuracy.png`)
  - validation method unchanged: palaeovegetation-record × 100-year output-time rows, expected vegetation >=1% of mapped vegetation cells
  - larger bottom margin for the validation-rule note

## Regression check

The seven standard-report figures were regenerated from the previously completed hotfix10n8 output set. All seven files were written successfully; the accuracy figure remained 81/86 (94.19%) dynamic and 36/86 (41.86%) static for that regression dataset, confirming that only presentation changed.
