# Fluvial issue 3 audit — adaptive timestep convergence (2026-08-17)

## Scope
This patch addresses only fluvial timestep convergence on top of hotfix10m2.
Issue 1 (Pelletier-2010 grid-resolution A/w classifier) and issue 2 (fixed-baselevel outlet) are retained.
The known supercritical nonlinear-hillslope solver problem is outside this patch and is not claimed to be solved here.

## Production-code changes
1. `ScienceConfig.geomorph_fluvial_max_change_m = 0.025` added as a numerical tolerance.
2. `_advance_geomorph_interval_adaptive()` now computes a trial geomorphic step, inspects `max(fluvial_regolith_erosion_m + fluvial_bedrock_erosion_m)`, rejects the entire trial if the tolerance is exceeded, halves `dt`, and retries from the unchanged accepted state.
3. No erosion depth/rate is capped or rescaled.
4. Accepted geomorphic `z/b/H` state is retained internally as float64 across substeps. This removes timestep-count-dependent float32 roundoff at ~1160 m elevations. Output and BIOME4 I/O may still use float32 at their existing boundaries.
5. Diagnostics now report rejected fluvial trials, accepted dt range, tolerance, and maximum accepted/trial fluvial change.

## Why 0.025 m is the default
Pelletier et al. (2013) describe dynamically reducing dt to limit per-step erosion/deposition and checking convergence by halving the threshold, but do not publish the numerical threshold used. Therefore 0.025 m is explicitly treated as a numerical tolerance, not a physical parameter or calibration coefficient.

Fluvial-only 1 kyr audit (hillslope disabled only in the audit harness):

| tolerance | accepted steps | accepted dt | max accepted fluvial change | H=0 cells |
|---:|---:|---:|---:|---:|
| 0.050 m | 80 | 0.0125 kyr | 0.0432903 m | 2 |
| 0.025 m | 160 | 0.00625 kyr | 0.0216452 m | 2 |
| 0.0125 m | 320 | 0.003125 kyr | 0.0108226 m | 2 |

Threshold-halving differences:

| comparison | max |ΔH| | p99 |ΔH| | max |Δz| | p99 |Δz| | bare-mask differences |
|---|---:|---:|---:|---:|---:|
| 0.050 → 0.025 m | 0.0430626 m | 0.00620888 m | 0.0439498 m | 0.00625624 m | 0 |
| 0.025 → 0.0125 m | 0.0135511 m | 0.00189889 m | 0.0136663 m | 0.00193472 m | 0 |

Thus the 0.025→0.0125 halving changes 99% of cells by ~2 mm or less and the worst local difference by ~1.4 cm, with no change in the H=0 mask. 0.025 m is retained as the default numerical tolerance; 0.0125 m remains available for stricter convergence checks.

## Reproducibility and rejection purity
Fresh independent reruns reproduced:
- 0.025 m: 160 accepted substeps, 4 rejected fluvial trials, dt=0.00625 kyr, H=0 cells=2, outlet drift=0.
- 0.0125 m: 320 accepted substeps, 5 rejected fluvial trials, dt=0.003125 kyr, H=0 cells=2, outlet drift=0.

A separate purity test compared the adaptive 0.025 m result with a direct sequence of 160 fixed 0.00625-kyr accepted steps. Maximum differences in z, b, and H were all exactly 0.0 m and the bare mask was identical. Rejected trial calculations therefore do not mutate accepted state.

## Regression checks
- Python compileall: PASS (28 Python files).
- BIOME4-SD McKenzie2003 strict-reference contract: PASS.
- Issue-1 Pelletier-2010 classifier regression: PASS; Yongneup initial valley count remains 359 and MFD area mass-balance errors remain ~1e-11 m2.
- Issue-2 outlet regression: outlet `slope_flow=0`, fluvial erosion=0, z/b/H drift=0.
- `biome4_backend.py` SHA256 is unchanged from hotfix10m2.

## Important scope boundary
A short production-path smoke test with the existing nonlinear hillslope routine remained finite and preserved the fixed outlet, but produced a large local soil accumulation (H max ~8.65 m in 0.01 kyr). This is the previously identified supercritical nonlinear-hillslope/denominator problem; it is not caused by the fluvial adaptive timestep and is not fixed by hotfix10m3. Therefore hotfix10m3 closes fluvial issue 3 only and must not be presented as solving the separate hillslope solver problem.

## Event splitting
No separate soil-exhaustion event-split algorithm was added. The reference-supported trial-halving method already gives a convergent solution and adding a second, non-reference event algorithm would complicate the strict-reference path without demonstrated need. Soil exhaustion remains handled by the existing regolith-then-bedrock accounting at each accepted substep, with convergence controlled by dt halving.
