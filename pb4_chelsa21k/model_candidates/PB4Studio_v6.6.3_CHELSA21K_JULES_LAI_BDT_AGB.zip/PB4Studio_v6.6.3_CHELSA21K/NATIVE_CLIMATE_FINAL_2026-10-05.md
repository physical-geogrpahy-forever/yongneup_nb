# PB4Studio CHELSA21K native-climate production decision

This package is the 2026-10-05 production revision for Yongneup wetland ecology,
palaeoecology, palaeoclimate, and biogeomorphology modelling.

Production policy:
- CHELSA-TraCE21k/EnviCloud forcing, 21-0 ka BP, 0.1 kyr interval
- BIOME4 v4.2b2 native PFT5/PFT6 climate limits retained
- McKenzie soil-depth/AWC coupling retained
- Jackson-style finite-depth PFT root accessibility retained
- symmetric 51% majority rule for reduced broadleaf/conifer classification retained
- dynamic Pelletier vegetation-geomorphology coupling retained

A full 21-0 ka ablation showed that removing the PFT5/PFT6 climate tuning leaves
Jang et al. (2011) corrected 1% validation unchanged:
static 24/62 = 38.71%, dynamic 55/62 = 88.71%.

The previous tuned-climate package SHA-256 was:
bc336bdc3232dcfb912cc8f4072565591714064c6446dfb28630f785ee90fb09
It remains recoverable from Git history but is no longer the canonical production package.
