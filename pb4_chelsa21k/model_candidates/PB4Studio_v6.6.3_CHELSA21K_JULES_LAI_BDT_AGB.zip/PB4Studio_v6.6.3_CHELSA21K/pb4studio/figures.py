# -*- coding: utf-8 -*-
"""
figures.py — 스냅샷 비교 지도 + 시계열 리포트 그래프.

yongneup_dynstat20m 원본 노트북의 ``make_snapshot_figures``/``make_timeseries_figures``를
새 아키텍처(임의 basin, 일반화된 static/dynamic 2케이스 구조)에 맞게 이식했다.
시각 스타일(색상표, 레이아웃, 통계적 스케일링 방식)은 원본과 동일하게 맞췄다.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
import rasterio

from .validation import setup_korean_matplotlib
from .snapshots import snapshot_dir_name

VEG_CODE_LABEL_KO = {
    0: "침엽수림",
    1: "활엽수림",
    2: "혼효림",
    3: "초본·개방식생",
    4: "무식생·나지",
}


def _read_snapshot_tif(case_dir: Path, ka: float, var: str) -> Optional[np.ndarray]:
    path = Path(case_dir) / snapshot_dir_name(ka) / f"{var}.tif"
    if not path.exists():
        return None
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float32")
        arr = np.where(arr == src.nodata, np.nan, arr)
    return arr


def _plot_basin_outline(ax, arr: np.ndarray) -> None:
    finite_mask = np.isfinite(arr)
    if np.any(finite_mask):
        ax.contour(finite_mask.astype(float), levels=[0.5], colors="black", linewidths=0.8)


def make_snapshot_figures(
    static_dir: Path,
    dynamic_dir: Path,
    snapshots: Sequence[float],
    fig_dir: Path,
    static_label: str = "정적모델",
    dynamic_label: str = "동적모델",
) -> List[Path]:
    """4×3(스냅샷 수×[동적,정적,차이]) 비교 지도를 변수별 PNG로 저장한다."""
    setup_korean_matplotlib()
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap, TwoSlopeNorm
    from matplotlib.patches import Patch

    fig_dir = Path(fig_dir)
    fig_dir.mkdir(parents=True, exist_ok=True)
    snapshots = sorted([float(x) for x in snapshots], reverse=True)
    written: List[Path] = []

    numeric_specs = [
        ("elevation_m", "고도 (m)", f"{dynamic_label}-{static_label} 고도차 (m)", "viridis"),
        ("soil_depth_m", "토심 (m)", f"{dynamic_label}-{static_label} 토심차 (m)", "YlOrBr"),
        ("npp", "NPP", f"{dynamic_label}-{static_label} NPP 차이", "Greens"),
        ("eemt", "EEMT", f"{dynamic_label}-{static_label} EEMT 차이", "Blues"),
    ]

    for var, title, diff_title, cmap_name in numeric_specs:
        rasters = {}
        all_base_vals, all_diff_vals = [], []
        for ka in snapshots:
            d = _read_snapshot_tif(dynamic_dir, ka, var)
            s = _read_snapshot_tif(static_dir, ka, var)
            rasters[(ka, "dynamic")] = d
            rasters[(ka, "static")] = s
            for arr in (d, s):
                if arr is not None:
                    vals = arr[np.isfinite(arr)]
                    if vals.size:
                        all_base_vals.append(vals)
            if d is not None and s is not None:
                diff = d - s
                rasters[(ka, "diff")] = diff
                vals = diff[np.isfinite(diff)]
                if vals.size:
                    all_diff_vals.append(vals)
            else:
                rasters[(ka, "diff")] = None

        if not all_base_vals:
            continue
        joined = np.concatenate(all_base_vals)
        vmin = float(np.nanpercentile(joined, 2))
        vmax = float(np.nanpercentile(joined, 98))
        diff_norm = None
        if all_diff_vals:
            djoined = np.concatenate(all_diff_vals)
            lim = float(np.nanpercentile(np.abs(djoined), 98))
            if np.isfinite(lim) and lim > 0:
                diff_norm = TwoSlopeNorm(vcenter=0.0, vmin=-lim, vmax=lim)

        fig, axes = plt.subplots(nrows=len(snapshots), ncols=3, figsize=(9.5, 2.6 * len(snapshots)), squeeze=False)
        im_base = im_diff = None
        for r, ka in enumerate(snapshots):
            for c, key in enumerate(["dynamic", "static", "diff"]):
                ax = axes[r][c]
                arr = rasters.get((ka, key))
                if arr is None:
                    ax.axis("off")
                    continue
                masked = np.ma.masked_invalid(arr)
                if key == "diff":
                    cmap = plt.get_cmap("coolwarm").copy(); cmap.set_bad("white")
                    im_diff = ax.imshow(masked, cmap=cmap, norm=diff_norm, interpolation="nearest")
                    ax.set_title(f"{int(ka)} ka | {diff_title}", fontsize=8)
                else:
                    cmap = plt.get_cmap(cmap_name).copy(); cmap.set_bad("white")
                    im_base = ax.imshow(masked, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
                    label = dynamic_label if key == "dynamic" else static_label
                    ax.set_title(f"{int(ka)} ka | {label}", fontsize=8)
                _plot_basin_outline(ax, arr)
                ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
        fig.suptitle(title, fontsize=14)
        fig.tight_layout(rect=(0, 0.04, 1, 0.96))
        if im_base is not None:
            fig.colorbar(im_base, ax=axes[:, :2].ravel().tolist(), shrink=0.55, location="right")
        if im_diff is not None:
            fig.colorbar(im_diff, ax=axes[:, 2].ravel().tolist(), shrink=0.55, location="right")
        out_path = fig_dir / f"snapshot_dynamic_static_{var}.png"
        fig.savefig(out_path, dpi=300)
        plt.close(fig)
        written.append(out_path)

    # 식생유형: 이산 클래스 색상 + 일치/불일치
    veg_cmap = ListedColormap(["#1f78b4", "#33a02c", "#b2df8a", "#fdbf6f", "#bdbdbd"])
    veg_cmap.set_bad("white")
    veg_norm = BoundaryNorm([-0.5, 0.5, 1.5, 2.5, 3.5, 4.5], veg_cmap.N)
    agree_cmap = ListedColormap(["#d73027", "#1a9850"])
    agree_cmap.set_bad("white")
    agree_norm = BoundaryNorm([-0.5, 0.5, 1.5], agree_cmap.N)

    fig, axes = plt.subplots(nrows=len(snapshots), ncols=3, figsize=(9.5, 2.6 * len(snapshots)), squeeze=False)
    any_veg = False
    for r, ka in enumerate(snapshots):
        d = _read_snapshot_tif(dynamic_dir, ka, "vegetation_code")
        s = _read_snapshot_tif(static_dir, ka, "vegetation_code")
        if d is not None:
            d = np.where(np.isfinite(d) & (d >= 0) & (d <= 4), d, np.nan)
        if s is not None:
            s = np.where(np.isfinite(s) & (s >= 0) & (s <= 4), s, np.nan)
        for c, (arr, label) in enumerate([(d, dynamic_label), (s, static_label)]):
            ax = axes[r][c]
            if arr is None:
                ax.axis("off"); continue
            any_veg = True
            ax.imshow(np.ma.masked_invalid(arr), cmap=veg_cmap, norm=veg_norm, interpolation="nearest")
            _plot_basin_outline(ax, arr)
            ax.set_title(f"{int(ka)} ka | {label}", fontsize=8)
            ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
        ax = axes[r][2]
        if d is None or s is None:
            ax.axis("off")
        else:
            valid = np.isfinite(d) & np.isfinite(s)
            agree = np.full(d.shape, np.nan, dtype="float32")
            agree[valid] = (d[valid].astype(int) == s[valid].astype(int)).astype("float32")
            ax.imshow(np.ma.masked_invalid(agree), cmap=agree_cmap, norm=agree_norm, interpolation="nearest")
            _plot_basin_outline(ax, agree)
            ax.set_title(f"{int(ka)} ka | 일치/불일치", fontsize=8)
            ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
    if any_veg:
        veg_patches = [Patch(facecolor=veg_cmap(i), label=f"{i} {VEG_CODE_LABEL_KO[i]}") for i in range(5)]
        agree_patches = [Patch(facecolor=agree_cmap(1), label="일치"), Patch(facecolor=agree_cmap(0), label="불일치")]
        fig.legend(handles=veg_patches + agree_patches, loc="lower center", ncol=3, fontsize=9, frameon=False)
        fig.suptitle("식생유형", fontsize=14)
        fig.tight_layout(rect=(0, 0.10, 1, 0.96))
        out_path = fig_dir / "snapshot_dynamic_static_vegetation_code.png"
        fig.savefig(out_path, dpi=300)
        written.append(out_path)
    plt.close(fig)

    return written


def parse_vegetation_ratio_long(ts: pd.DataFrame) -> pd.DataFrame:
    """summary_timeseries.csv 형태의 df(yr_bp, n_cells, vegetation_class_counts, case_label 포함)를
    (yr_bp, case_label, vegetation_code, vegetation_label, ratio_pct) 롱포맷으로 변환한다.
    4=무식생·나지를 명시적으로 포함한다. 매핑 실패/비정상 NoData는 class 4로
    강제하지 않으므로, 그런 셀이 있으면 stackplot의 합이 100% 미만으로 남아
    진단 가능한 빈 공간이 된다. GUI와 저장 그림이 동일한 로직을 공유한다."""
    ratio_rows = []
    for _, row in ts.iterrows():
        total = float(row.get("n_cells", np.nan))
        counts = str(row.get("vegetation_class_counts", ""))
        parsed = {0: 0.0, 1: 0.0, 2: 0.0, 3: 0.0, 4: 0.0}
        for token in counts.split(";"):
            token = token.strip()
            if not token or ":" not in token:
                continue
            k, v = token.split(":", 1)
            try:
                kk = int(float(k)); vv = float(v)
            except ValueError:
                continue
            if kk in parsed:
                parsed[kk] = vv
        for code, count in parsed.items():
            ratio_rows.append({
                "yr_bp": float(row["yr_bp"]), "case_label": row["case_label"],
                "vegetation_code": code, "vegetation_label": VEG_CODE_LABEL_KO[code],
                "ratio_pct": 100.0 * count / total if total and np.isfinite(total) else np.nan,
            })
    return pd.DataFrame(ratio_rows)


def make_timeseries_figures(
    static_dir: Path,
    dynamic_dir: Path,
    fig_dir: Path,
    static_label: str = "정적모델",
    dynamic_label: str = "동적모델",
) -> List[Path]:
    """평균 고도/토심/NPP 시계열 + 식생유형 비율 시계열 그래프를 저장한다."""
    setup_korean_matplotlib()
    import matplotlib.pyplot as plt

    fig_dir = Path(fig_dir)
    fig_dir.mkdir(parents=True, exist_ok=True)
    written: List[Path] = []

    frames = []
    for case_dir, label in [(dynamic_dir, dynamic_label), (static_dir, static_label)]:
        path = Path(case_dir) / "summary_timeseries.csv"
        if not path.exists():
            continue
        df = pd.read_csv(path)
        df["case_label"] = label
        frames.append(df)
    if not frames:
        return written
    ts = pd.concat(frames, ignore_index=True)
    ts["yr_bp"] = ts["ka_bp"].astype(float) * 1000.0

    specs = [
        ("mean_elevation_m", "평균 고도 변화", "평균 고도 (m)", "timeseries_mean_elevation.png"),
        ("mean_soil_depth_m", "평균 토심 변화", "평균 토심 (m)", "timeseries_mean_soil_depth.png"),
        ("mean_npp", "평균 NPP 변화", "평균 NPP", "timeseries_mean_npp.png"),
    ]
    for col, title, ylabel, fname in specs:
        if col not in ts.columns:
            continue
        fig, ax = plt.subplots(figsize=(8, 4.5))
        for case_label, sub in ts.groupby("case_label", sort=False):
            sub = sub.sort_values("yr_bp", ascending=False)
            ax.plot(sub["yr_bp"], sub[col], label=str(case_label), linewidth=1.5)
        ax.set_title(title)
        ax.set_xlabel("시간 (yr BP, 1000년 간격)")
        ax.set_ylabel(ylabel)
        ax.invert_xaxis()
        ax.grid(True, alpha=0.3)
        ax.legend()
        fig.tight_layout()
        out_path = fig_dir / fname
        fig.savefig(out_path, dpi=300)
        plt.close(fig)
        written.append(out_path)

    # 식생유형 비율 시계열
    if "vegetation_class_counts" in ts.columns and "n_cells" in ts.columns:
        ratio = parse_vegetation_ratio_long(ts)
        if not ratio.empty:
            class_order = [0, 1, 2, 3, 4]
            colors = ["#1f78b4", "#33a02c", "#b2df8a", "#fdbf6f", "#bdbdbd"]
            case_order = list(dict.fromkeys(ratio["case_label"].tolist()))
            fig, axes = plt.subplots(nrows=len(case_order), ncols=1, figsize=(9, 3.1 * len(case_order)),
                                      sharex=True, squeeze=False)
            for ax, case_label in zip(axes[:, 0], case_order):
                sub_case = ratio[ratio["case_label"] == case_label]
                pivot = sub_case.pivot_table(index="yr_bp", columns="vegetation_code", values="ratio_pct",
                                              aggfunc="mean").sort_index(ascending=False)
                for cls in class_order:
                    if cls not in pivot.columns:
                        pivot[cls] = 0.0
                pivot = pivot[class_order].fillna(0.0)
                ax.stackplot(pivot.index.values, [pivot[cls].values for cls in class_order],
                             labels=[VEG_CODE_LABEL_KO[cls] for cls in class_order], colors=colors, alpha=0.85)
                ax.set_title(str(case_label))
                ax.set_ylabel("면적 비율 (%)")
                ax.set_ylim(0, 100)
                ax.grid(True, alpha=0.25)
                ax.invert_xaxis()
            axes[-1, 0].set_xlabel("시간 (yr BP, 1000년 간격)")
            handles, labels = axes[0, 0].get_legend_handles_labels()
            fig.legend(handles, labels, loc="lower center", ncol=5, fontsize=9, frameon=True)
            fig.suptitle("시간에 따른 식생유형 비율", fontsize=14)
            fig.tight_layout(rect=(0, 0.08, 1, 0.96))
            out_path = fig_dir / "timeseries_vegetation_ratio.png"
            fig.savefig(out_path, dpi=300)
            plt.close(fig)
            written.append(out_path)

    return written
