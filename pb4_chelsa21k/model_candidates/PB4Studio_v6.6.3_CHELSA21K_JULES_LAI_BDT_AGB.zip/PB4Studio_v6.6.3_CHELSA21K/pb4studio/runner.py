# -*- coding: utf-8 -*-
"""
runner.py — 정적/동적/정적+동적 비교 실행 오케스트레이터.

yongneup_dynstat20m의 ``run_one_resolution_worker`` (검증된 시간 루프)를
그대로 따르되, 아래를 새 모듈로 교체했다:

    - grid.py       : DEM 기준 CRS/셀크기 자동감지 + 재투영 (기존: 고정 EPSG:5187)
    - boundary.py   : 다중 open 경계(shp 기반)          (기존: 단일 outlet 좌표)
    - config.py     : TimeConfig(시작/종료/간격)          (기존: cfg.time_slices_ka)

BIOME4 호출과 EEMT/AGB 결합을 유지하면서, 실행 전 기후 연대범위 검사를
강제하고 교정된 지형발달 계산을 호출한다.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json

import numpy as np
import pandas as pd
import rasterio
from rasterio.enums import Resampling

from . import grid
from .boundary import BoundaryConfig, BoundaryType
from .snapshots import map_snapshot_ages_to_output_indices, snapshot_dir_name
from .config import RunConfig, RunMode, TimeConfig
from .climate import (
    load_climate, climate_arrays_for_time, build_soil_arrays,
    run_biome4_dynamic_step, compute_eemt_and_agb, vegetation_array,
    write_geotiff, write_cell_csv, summarize_snapshot,
)
from .pelletier_geomorph import (
    PelletierStrictConfig,
    update_pelletier_strict,
    pelletier_default_stable_dt_kyr,
)
from . import validation as validation_mod
from . import figures as figures_mod
from . import standard_report as standard_report_mod


def default_validation_csv_path() -> Path:
    """소프트웨어에 내장된 전국 고식생 검증 데이터셋 경로.

    RunConfig.inputs.validation_points_csv가 None이면 이 파일을 기본으로
    쓴다. 빈 문자열("")로 명시적으로 지정하면 검증을 완전히 끈다.
    """
    return Path(__file__).resolve().parent / "embedded_data" / "nationwide_validation.csv"


class InitialGrid:
    """한 실행에서 공통으로 쓰는 격자/입력자료 묶음."""

    def __init__(self, transform, shape, crs, resolution_m: float,
                 x, y, lon, lat, land: np.ndarray,
                 dem0: np.ndarray, soil0: np.ndarray, texture0: np.ndarray):
        self.transform = transform
        self.shape = shape
        self.crs = crs
        self.resolution_m = float(resolution_m)
        self.x, self.y, self.lon, self.lat = x, y, lon, lat
        self.land = land
        self.dem0, self.soil0, self.texture0 = dem0, soil0, texture0


def _empty_biome4_result_for_bare_bedrock(shape: Tuple[int, int], land: np.ndarray) -> Dict[str, np.ndarray]:
    """Return a minimal BIOME4-like result when every land cell is bare bedrock.

    BIOME4 is deliberately not called for h≈0 cells. Barren native biome ID 27
    is converted to explicit vegetation-state code 4 (무식생·나지) by
    ``vegetation_array``; NPP and AET are zero so EEMT can retain its
    climate-driven component.
    """
    land = np.asarray(land, dtype=bool)
    zeros = np.where(land, 0.0, np.nan).astype("float32")
    barren = np.where(land, 27.0, np.nan).astype("float32")
    return {
        "npp_node": zeros.copy(),
        "aet_node": zeros.copy(),
        "biome4_full_id_node": barren,
        "vegetation_core_mode": "bare_bedrock_bypass",
        "biome4_backend": "not_called_all_bare",
    }


def _advance_geomorph_interval_adaptive(
    cfg: PelletierStrictConfig,
    z: np.ndarray,
    b: np.ndarray,
    h: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    eemt: np.ndarray,
    agb: np.ndarray,
    interval_kyr: float,
    dx_m: float,
    max_substep_kyr: float,
    min_substep_kyr: float,
    fluvial_max_change_tolerance_m: float = 0.025,
    adaptive: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, object]]:
    """Advance one climate interval with adaptive geomorphic substeps.

    Two independent numerical controls are applied without modifying any
    process rate:

    1. Pelletier et al. (2013)'s conservative explicit hillslope estimate,
       ``0.01 * dx**2 / (2*kd)``.
    2. Pelletier et al. (2013)'s dynamic maximum erosion/deposition control:
       reject a trial and retry it at ``dt/2`` when *any* geomorphic process
       (hillslope change, fluvial erosion, or post-process threshold adjustment)
       exceeds a small numerical depth tolerance.

    The threshold magnitude is not published by Pelletier et al. (2013).  The
    bundled default (0.025 m) is therefore a numerical tolerance selected by a
    T -> T/2 convergence audit, not a physical calibration coefficient.  No
    process amount is capped to this value: rejected trials are discarded and
    recomputed from the unchanged accepted state.  After an accepted trial the
    next candidate dt is allowed to double (up to max_dt); this prevents a brief
    near-critical transient from locking the rest of a kyr-scale interval to a
    minute-scale substep.
    """
    remaining = max(float(interval_kyr), 0.0)
    max_dt = max(float(max_substep_kyr), 1e-12)
    min_dt = max(float(min_substep_kyr), 1e-12)
    stable_dt = pelletier_default_stable_dt_kyr(cfg, eemt, agb, land, dx_m)
    fluvial_tol = float(fluvial_max_change_tolerance_m)
    if not np.isfinite(fluvial_tol) or fluvial_tol < 0.0:
        raise ValueError("geomorph_fluvial_max_change_m must be finite and >= 0")

    accepted = 0
    rejected = 0
    rejected_stability = 0
    rejected_fluvial = 0
    rejected_process_change = 0
    rejected_other = 0
    min_used = float("inf")
    max_used = 0.0
    max_accepted_fluvial_change = 0.0
    max_trial_fluvial_change = 0.0
    max_accepted_process_change = 0.0
    max_trial_process_change = 0.0
    threshold_pre_export_mass_equiv = 0.0
    threshold_post_export_mass_equiv = 0.0
    threshold_pre_adjusted_cell_events = 0
    threshold_post_adjusted_cell_events = 0
    hillslope_supply_limited_cell_events = 0
    last_diag: Dict[str, np.ndarray] = {}

    # Once a smaller substep has been accepted, use it as the next candidate
    # instead of repeatedly retrying the same known-oversized max_dt trial.
    next_dt = max_dt

    while remaining > 1e-12:
        dt = min(next_dt, remaining)
        if adaptive and np.isfinite(stable_dt):
            while dt > stable_dt * (1.0 + 1e-12):
                dt *= 0.5
                rejected += 1
                rejected_stability += 1
                if dt < min_dt:
                    raise RuntimeError(
                        "Pelletier 안정시간 조건을 만족하려면 지형발달 서브스텝이 "
                        f"최소 허용값({min_dt:g} kyr)보다 작아져야 합니다. "
                        f"추정 안정 dt={stable_dt:g} kyr, 격자={dx_m:g} m"
                    )

        while True:
            try:
                z_try, b_try, h_try, diag = update_pelletier_strict(
                    cfg, z, b, h, land, boundary_cfg, eemt, agb, dt, dx_m,
                )
                valid = (
                    np.all(np.isfinite(z_try[land]))
                    and np.all(np.isfinite(b_try[land]))
                    and np.all(np.isfinite(h_try[land]))
                    and float(np.nanmin(h_try[land])) >= -1e-8
                ) if np.any(land) else True
                if not valid:
                    raise FloatingPointError("non-finite or negative geomorphic state")

                # Pelletier et al. (2013) reduced dt dynamically so the
                # maximum erosion/deposition in one explicit step remained
                # small.  Apply that criterion to the complete geomorphic
                # trial, not only to the fluvial sub-process.
                if adaptive and fluvial_tol > 0.0:
                    active = np.asarray(land, dtype=bool)
                    freg = np.asarray(diag.get("fluvial_regolith_erosion_m", 0.0), dtype="float64")
                    fbed = np.asarray(diag.get("fluvial_bedrock_erosion_m", 0.0), dtype="float64")
                    hill = np.asarray(diag.get("hillslope_dz_m", 0.0), dtype="float64")
                    thr = np.asarray(diag.get("threshold_post_surface_lowering_m", 0.0), dtype="float64")
                    max_fluvial_change = (
                        float(np.nanmax((freg + fbed)[active])) if np.any(active) else 0.0
                    )
                    max_hillslope_change = (
                        float(np.nanmax(np.abs(hill[active]))) if np.any(active) else 0.0
                    )
                    max_threshold_change = (
                        float(np.nanmax(thr[active])) if np.any(active) else 0.0
                    )
                    max_process_change = max(
                        max_fluvial_change, max_hillslope_change, max_threshold_change
                    )
                    max_trial_fluvial_change = max(max_trial_fluvial_change, max_fluvial_change)
                    max_trial_process_change = max(max_trial_process_change, max_process_change)
                    if max_process_change > fluvial_tol * (1.0 + 1e-12):
                        rejected += 1
                        rejected_process_change += 1
                        if max_fluvial_change >= max_process_change - 1e-15:
                            rejected_fluvial += 1
                        dt *= 0.5
                        if dt < min_dt:
                            raise RuntimeError(
                                "Geomorphic adaptive tolerance requires a substep below "
                                f"the minimum allowed ({min_dt:g} kyr); trial change="
                                f"{max_process_change:g} m, tolerance={fluvial_tol:g} m"
                            )
                        continue
                    max_accepted_fluvial_change = max(
                        max_accepted_fluvial_change, max_fluvial_change
                    )
                    max_accepted_process_change = max(
                        max_accepted_process_change, max_process_change
                    )
                break
            except (FloatingPointError, OverflowError) as exc:
                if not adaptive:
                    raise
                rejected += 1
                rejected_other += 1
                dt *= 0.5
                if dt < min_dt:
                    raise RuntimeError(
                        "적응형 시간세분화가 최소 허용 서브스텝에 도달했지만 "
                        f"지형발달 계산이 안정화되지 않았습니다: {exc}"
                    ) from exc

        z, b, h = z_try, b_try, h_try
        last_diag = diag
        active = np.asarray(land, dtype=bool)
        pre_exp = np.asarray(diag.get("threshold_pre_export_mass_equivalent_m", 0.0), dtype="float64")
        post_exp = np.asarray(diag.get("threshold_post_export_mass_equivalent_m", 0.0), dtype="float64")
        pre_low = np.asarray(diag.get("threshold_pre_surface_lowering_m", 0.0), dtype="float64")
        post_low = np.asarray(diag.get("threshold_post_surface_lowering_m", 0.0), dtype="float64")
        limited = np.asarray(diag.get("hillslope_supply_limited_mask", False), dtype=bool)
        if np.any(active):
            threshold_pre_export_mass_equiv += float(np.sum(pre_exp[active]))
            threshold_post_export_mass_equiv += float(np.sum(post_exp[active]))
            threshold_pre_adjusted_cell_events += int(np.count_nonzero(pre_low[active] > 1e-12))
            threshold_post_adjusted_cell_events += int(np.count_nonzero(post_low[active] > 1e-12))
            hillslope_supply_limited_cell_events += int(np.count_nonzero(limited[active]))
        remaining = max(0.0, remaining - dt)
        accepted += 1
        min_used = min(min_used, dt)
        max_used = max(max_used, dt)
        # Bidirectional adaptive stepping: a rejected trial halves dt, while a
        # successful trial is allowed to probe a larger dt next time.  The
        # stability and process-change tests above still reject it if needed.
        next_dt = min(dt * 2.0, max_dt) if adaptive else dt

    stats: Dict[str, object] = {
        "accepted_substeps": accepted,
        "rejected_or_halved_substeps": rejected,
        "rejected_stability_halvings": rejected_stability,
        "rejected_fluvial_trials": rejected_fluvial,
        "rejected_process_change_trials": rejected_process_change,
        "rejected_other_trials": rejected_other,
        "min_dt_kyr": (min_used if accepted else 0.0),
        "max_dt_kyr": max_used,
        "pelletier_stable_dt_kyr": stable_dt,
        "fluvial_max_change_tolerance_m": fluvial_tol,
        "max_accepted_fluvial_change_m": max_accepted_fluvial_change,
        "max_trial_fluvial_change_m": max_trial_fluvial_change,
        "max_accepted_process_change_m": max_accepted_process_change,
        "max_trial_process_change_m": max_trial_process_change,
        "threshold_pre_export_mass_equiv_depthsum_m": threshold_pre_export_mass_equiv,
        "threshold_post_export_mass_equiv_depthsum_m": threshold_post_export_mass_equiv,
        "threshold_pre_adjusted_cell_events": threshold_pre_adjusted_cell_events,
        "threshold_post_adjusted_cell_events": threshold_post_adjusted_cell_events,
        "hillslope_supply_limited_cell_events": hillslope_supply_limited_cell_events,
        "last_diagnostics": last_diag,
    }
    return z, b, h, stats


def build_initial_grid(run_config: RunConfig, resolution_m_override: Optional[float] = None) -> InitialGrid:
    """DEM/유역/토심/토성을 읽어 공통 분석격자를 만든다.

    셀 크기는 기본적으로 DEM 네이티브 해상도를 그대로 쓴다 ("셀 크기는
    지형에 맞춘다"는 요구사항). ``resolution_m_override``는 회귀테스트나
    고급 사용자를 위한 예외 경로다.

    hotfix10n8 self-contained Yongneup package: when the selected DEM directory
    contains ``PB4STUDIO_EXACT_GRID.json`` and the selected DEM/soil/texture
    filenames match that manifest, the already validated 20x23 production grid
    is loaded directly.  This avoids silently regridding the archived 298-cell
    production state to a different 20 m mask.  External/user datasets keep the
    ordinary generic grid-building path below.
    """
    inputs = run_config.inputs
    dem_path = Path(inputs.dem_path)

    exact_manifest = dem_path.parent / "PB4STUDIO_EXACT_GRID.json"
    if exact_manifest.exists():
        try:
            meta = json.loads(exact_manifest.read_text(encoding="utf-8"))
            expected_names = (
                str(meta.get("dem_filename", "")),
                str(meta.get("soil_depth_filename", "")),
                str(meta.get("soil_texture_filename", "")),
            )
            selected_names = (
                dem_path.name, Path(inputs.soil_depth_path).name, Path(inputs.soil_texture_path).name,
            )
            model_res = float(meta.get("model_resolution_m", 20.0))
            override_ok = (resolution_m_override is None) or abs(float(resolution_m_override) - model_res) <= 1.0e-9
            if meta.get("marker") == "PB4STUDIO_EXACT_EMBEDDED_GRID_V1" and selected_names == expected_names and override_ok:
                with rasterio.open(dem_path) as dsrc, \
                     rasterio.open(Path(inputs.soil_depth_path)) as hsrc, \
                     rasterio.open(Path(inputs.soil_texture_path)) as tsrc:
                    if dsrc.shape != hsrc.shape or dsrc.shape != tsrc.shape:
                        raise ValueError("Embedded exact-grid DEM/soil/texture shapes differ.")
                    if dsrc.crs != hsrc.crs or dsrc.crs != tsrc.crs:
                        raise ValueError("Embedded exact-grid DEM/soil/texture CRS values differ.")
                    if dsrc.transform != hsrc.transform or dsrc.transform != tsrc.transform:
                        raise ValueError("Embedded exact-grid DEM/soil/texture transforms differ.")
                    transform = dsrc.transform
                    shape = dsrc.shape
                    crs = dsrc.crs
                    dem0 = dsrc.read(1).astype("float32")
                    soil0 = hsrc.read(1).astype("float32")
                    texture0 = tsrc.read(1).astype("float32")
                basin_geom = grid.load_basin_geometry(Path(inputs.basin_polygon_path), target_crs=crs)
                polygon_land = grid.rasterize_basin(basin_geom, transform, shape, all_touched=run_config.basin_all_touched)
                texture_finite = np.isfinite(texture0)
                texture_rounded = np.full(texture0.shape, -9999, dtype="int16")
                texture_rounded[texture_finite] = np.rint(texture0[texture_finite]).astype("int16")
                land = polygon_land & np.isfinite(dem0) & np.isfinite(soil0) & texture_finite & np.isin(texture_rounded, [1, 2, 3])
                expected_shape = tuple(int(v) for v in meta.get("shape", shape))
                expected_cells = int(meta.get("active_cells", int(land.sum())))
                if tuple(shape) != expected_shape or int(land.sum()) != expected_cells:
                    raise ValueError(
                        f"Embedded exact-grid integrity failure: shape={shape}, active={int(land.sum())}; "
                        f"expected shape={expected_shape}, active={expected_cells}."
                    )
                x, y, lon, lat = grid.grid_coordinates(transform, shape, crs)
                return InitialGrid(transform, shape, crs, model_res, x, y, lon, lat, land, dem0, soil0, texture0)
        except Exception as exc:
            raise RuntimeError(f"PB4Studio embedded exact-grid loading failed: {exc}") from exc

    info = grid.detect_target_grid_from_dem(dem_path)
    crs = info["crs"]
    resolution_m = float(resolution_m_override) if resolution_m_override else info["resolution_m"]

    basin_geom = grid.load_basin_geometry(Path(inputs.basin_polygon_path), target_crs=crs)
    transform, shape = grid.build_target_grid_from_dem(dem_path, basin_geom, resolution_m)
    polygon_land = grid.rasterize_basin(basin_geom, transform, shape, all_touched=run_config.basin_all_touched)

    x, y, lon, lat = grid.grid_coordinates(transform, shape, crs)

    dem0 = grid.aggregate_raster_to_grid(dem_path, crs, transform, shape, method=Resampling.average)
    soil0 = grid.aggregate_soil_depth_to_grid(
        Path(inputs.soil_depth_path), crs, transform, shape, unit=inputs.soil_depth_unit,
    )
    texture0 = grid.load_soil_texture_class_grid(
        Path(inputs.soil_texture_path), crs, transform, shape, x, y, lon, lat,
    )

    # 원본 패키지와 동일한 최종 land 정의: 유역폴리곤 ∩ 유효DEM ∩ 유효토심 ∩ 유효토성.
    dem_valid = np.isfinite(dem0)
    soil_valid = np.isfinite(soil0)
    texture_finite = np.isfinite(texture0)
    texture_rounded = np.full(texture0.shape, -9999, dtype="int16")
    texture_rounded[texture_finite] = np.rint(texture0[texture_finite]).astype("int16")
    texture_valid = texture_finite & np.isin(texture_rounded, [1, 2, 3])
    land = polygon_land & dem_valid & soil_valid & texture_valid
    if not np.any(land):
        raise ValueError(
            "유효한 land 셀이 하나도 없습니다 (유역 폴리곤과 DEM/토심/토성 자료가 겹치는 부분이 없음). "
            "입력 자료의 좌표계·범위를 확인하세요."
        )

    return InitialGrid(transform, shape, crs, resolution_m, x, y, lon, lat, land, dem0, soil0, texture0)


def _mask_snapshot_fields(fields: Dict[str, np.ndarray], land: np.ndarray) -> Dict[str, np.ndarray]:
    """Return output arrays with every non-catchment cell set to NaN/NoData.

    Dynamic geomorphic state may use zero-filled cells outside ``land`` as an
    internal numerical convenience.  Those values must never leak into GeoTIFF
    products, including soil depth and the source texture raster.
    """
    mask = np.asarray(land, dtype=bool)
    out: Dict[str, np.ndarray] = {}
    for name, arr in fields.items():
        a = np.asarray(arr, dtype="float32")
        out[name] = np.where(mask, a, np.nan).astype("float32")
    return out


def _snapshot_index_to_labels(times: List[float], requested_ka) -> Dict[int, List[float]]:
    """Map only exact requested snapshot ages to actual model output ages."""
    return map_snapshot_ages_to_output_indices(times, requested_ka)


def _validate_times_with_climate(times: List[float], climate_df: pd.DataFrame, climate_path: Path) -> None:
    """Fail fast when requested model ages exceed the available climate record."""
    if "ka_bp" not in climate_df.columns or climate_df.empty:
        raise ValueError(f"기후 자료({climate_path})에서 유효한 ka_bp 시간축을 찾지 못했습니다.")
    climate_ages = pd.to_numeric(climate_df["ka_bp"], errors="coerce").to_numpy(dtype="float64")
    climate_ages = climate_ages[np.isfinite(climate_ages)]
    if climate_ages.size == 0:
        raise ValueError(f"기후 자료({climate_path})의 ka_bp 시간축에 유효한 값이 없습니다.")
    model_ages = np.asarray([float(t) for t in times], dtype="float64")
    if model_ages.size == 0 or not np.all(np.isfinite(model_ages)):
        raise ValueError("모델 시간축이 비어 있거나 유효하지 않습니다.")

    cmin, cmax = float(np.min(climate_ages)), float(np.max(climate_ages))
    mmin, mmax = float(np.min(model_ages)), float(np.max(model_ages))
    tol = 1e-6
    problems = []
    if mmax > cmax + tol:
        problems.append(f"시작측 모델 시점 {mmax:g} ka BP > 기후자료 최대 {cmax:g} ka BP")
    if mmin < cmin - tol:
        problems.append(f"종료측 모델 시점 {mmin:g} ka BP < 기후자료 최소 {cmin:g} ka BP")
    if problems:
        raise ValueError(
            "요청한 모의기간이 기후자료의 연대 범위를 벗어납니다. "
            + "; ".join(problems)
            + f". 기후자료 범위: {cmin:g}~{cmax:g} ka BP. "
              "모의 시작·종료 시점을 조정하거나 더 긴 기후자료를 사용하세요."
        )


def run_single_case(
    run_config: RunConfig,
    dynamic_on: bool,
    output_subdir: str,
    igrid: Optional[InitialGrid] = None,
    boundary_cfg: Optional[BoundaryConfig] = None,
    resolution_m_override: Optional[float] = None,
    times_override: Optional[List[float]] = None,
    case_label: Optional[str] = None,
    progress_callback: Optional[object] = None,
    force_compile_on_first_step: Optional[bool] = None,
) -> Dict[str, object]:
    """정적(dynamic_on=False) 또는 동적(dynamic_on=True) 케이스 1개를 실행한다.

    ``igrid``/``boundary_cfg``를 미리 만들어서 넘기면(비교 모드에서 정적·동적이
    같은 격자/경계를 공유하도록) 다시 계산하지 않는다.

    ``times_override``는 회귀테스트 전용이다 — 기존 패키지는
    ``time_slices_ka``가 비어 있으면 기후 파일에 실제로 존재하는 ka_bp 값을
    그대로 시간 스텝으로 썼는데(대개 불균등 간격), 이 옵션으로 명시적인
    외부 시간축을 주입할 수 있다. 일반 사용자 워크플로우는
    TimeConfig(start_ka, end_ka, interval_kyr)에서 만든 시간축을 사용하며,
    종료연대를 맞추기 위한 마지막 구간만 interval_kyr보다 짧을 수 있다.

    ``progress_callback``이 주어지면 매 시간 스텝마다
    ``progress_callback(case_label, step_index, n_steps, ka)`` 로 호출된다
    (GUI 진행바 등에서 사용, 없어도 실행에는 지장 없음).
    """
    if igrid is None:
        igrid = build_initial_grid(run_config, resolution_m_override=resolution_m_override)
    if boundary_cfg is None:
        boundary_cfg = BoundaryConfig.from_shapefiles(
            land_mask=igrid.land, transform=igrid.transform, dst_crs=igrid.crs,
            common_slope_percent=run_config.common_slope_percent,
            open_free_shp=run_config.inputs.open_free_shp,
            open_fixed_slope_shp=run_config.inputs.open_fixed_slope_shp,
            snap_to_land_boundary=run_config.snap_open_cells_to_boundary,
        )
    bc_warnings = boundary_cfg.validate(igrid.land, require_component_outlet=bool(dynamic_on))
    if bc_warnings:
        raise ValueError("경계조건 설정에 문제가 있습니다: " + "; ".join(bc_warnings))

    res_dir = Path(run_config.output_dir) / output_subdir
    res_dir.mkdir(parents=True, exist_ok=True)

    geomorph_cfg = run_config.pelletier
    legacy_cfg = run_config.legacy_cfg_shim()
    force_compile_pending = (
        bool(run_config.science.force_compile_biome4)
        if force_compile_on_first_step is None
        else bool(force_compile_on_first_step)
    )

    climate_df = load_climate(
        Path(run_config.inputs.climate_nc_path),
        lon_value=float(np.nanmean(igrid.lon[igrid.land])),
        lat_value=float(np.nanmean(igrid.lat[igrid.land])),
    )

    times = [float(t) for t in (times_override if times_override is not None else run_config.time.snapshot_times_ka())]
    _validate_times_with_climate(times, climate_df, Path(run_config.inputs.climate_nc_path))
    requested_snapshot_ka = run_config.time.snapshot_ka if run_config.time.snapshot_ka else tuple(times)
    snapshot_index_to_labels = _snapshot_index_to_labels(times, requested_snapshot_ka)

    validation_records = []
    if run_config.inputs.validation_points_csv is None:
        validation_csv_path = default_validation_csv_path()
    elif run_config.inputs.validation_points_csv == "":
        validation_csv_path = None  # 사용자가 명시적으로 검증을 껐음
    else:
        validation_csv_path = Path(run_config.inputs.validation_points_csv)
    if validation_csv_path and Path(validation_csv_path).exists():
        nrows, ncols = igrid.shape
        corners_x = [igrid.transform.c, igrid.transform.c + ncols * igrid.transform.a]
        corners_y = [igrid.transform.f, igrid.transform.f + nrows * igrid.transform.e]
        basin_bounds = (min(corners_x), min(corners_y), max(corners_x), max(corners_y))
        validation_records = validation_mod._load_time_aware_validation_records(
            Path(validation_csv_path), times,
            validation_time_step_kyr=run_config.time.interval_kyr,
            target_crs=igrid.crs, basin_bounds_target_crs=basin_bounds,
        )
    validation_step_rows: List[Dict[str, object]] = []
    validation_rows: List[Dict[str, object]] = []
    validation_diagnostic_rows: List[Dict[str, object]] = []

    b = np.where(igrid.land, igrid.dem0 - igrid.soil0, np.nan).astype("float32")
    h = np.where(igrid.land, igrid.soil0, np.nan).astype("float32")
    z = np.where(igrid.land, b + h, np.nan).astype("float32")

    summary_rows: List[Dict[str, object]] = []
    snapshot_rows: List[Dict[str, object]] = []

    for i, ka in enumerate(times):
        if progress_callback is not None:
            progress_callback(case_label or output_subdir, i, len(times), float(ka))
        temp, prec, cloud, tmin, co2 = climate_arrays_for_time(legacy_cfg, climate_df, float(ka), z, igrid.land)
        bare_tol = max(float(run_config.science.bare_bedrock_tolerance_m), 0.0)
        bare_bedrock = igrid.land & (np.asarray(h, dtype="float64") <= bare_tol)
        biome4_land = igrid.land & (~bare_bedrock)
        soil_arrays = build_soil_arrays(legacy_cfg, h, biome4_land, igrid.texture0)
        # ``force_compile_biome4`` means rebuild once at run start, not once per
        # model timestep.  The shim may safely carry this per-call override.
        legacy_cfg.force_compile_biome4 = force_compile_pending
        if np.any(biome4_land):
            veg = run_biome4_dynamic_step(
                legacy_cfg, temp, prec, cloud, tmin, co2, soil_arrays,
                igrid.lat, igrid.lon, z, biome4_land,
            )
            force_compile_pending = False
        else:
            veg = _empty_biome4_result_for_bare_bedrock(igrid.shape, igrid.land)
        eemt, agb = compute_eemt_and_agb(
            legacy_cfg, veg, temp, prec, igrid.land, bare_bedrock=bare_bedrock,
        )
        npp = np.asarray(veg.get("npp_node", np.full(igrid.shape, np.nan)), dtype="float32")
        npp = np.where(bare_bedrock, 0.0, npp)
        npp = np.where(igrid.land & np.isfinite(npp), npp, np.nan).astype("float32")
        eemt = np.where(igrid.land & np.isfinite(eemt), eemt, np.nan).astype("float32")
        veg_code = vegetation_array(veg, igrid.shape, igrid.land, bare_bedrock=bare_bedrock).astype("float32")

        # PFT-specific AGB diagnostics. The candidate AGB above feeds the same
        # geomorphic coupling as the legacy AGB; legacy 0.010*NPP is diagnostic only.
        optpft_agb = np.asarray(
            veg.get("optpft_node", np.full(igrid.shape, np.nan)), dtype="float64"
        )
        lai_agb = np.asarray(
            veg.get("lai_node", np.full(igrid.shape, np.nan)), dtype="float64"
        )
        optpft_round_agb = np.rint(
            np.where(np.isfinite(optpft_agb), optpft_agb, -999.0)
        ).astype("int16")
        agb_pft_ibis = np.where(
            igrid.land & np.isfinite(agb), np.asarray(agb, dtype="float64"), np.nan
        )
        agb_legacy_0010 = np.maximum(np.asarray(npp, dtype="float64"), 0.0) * 0.010
        agb_legacy_0010 = np.where(
            bare_bedrock, 0.0,
            np.where(igrid.land & np.isfinite(agb_legacy_0010), agb_legacy_0010, np.nan)
        )

        if validation_records:
            step_val = validation_mod._sample_validation_records_for_step(
                validation_records, int(round(igrid.resolution_m)), float(ka), veg_code, igrid.transform,
                basin_presence_min_fraction=run_config.science.basin_presence_min_fraction,
                basin_mask=igrid.land,
            )
            for vr in step_val:
                vr.update({"case": output_subdir, "case_label": case_label or output_subdir, "geomorph_dynamic": dynamic_on})
            validation_step_rows.extend(step_val)

        row = summarize_snapshot(int(round(igrid.resolution_m)), float(ka), z, h, veg_code, npp, eemt, igrid.land)
        row.update({
            "case": output_subdir,
            "geomorph_dynamic": dynamic_on,
            "biome4_variant": str(run_config.science.biome4_variant),
        })
        _m = igrid.land & np.isfinite(agb_pft_ibis)
        _new = agb_pft_ibis[_m]
        _old = agb_legacy_0010[_m]
        _ratio_mask = _m & np.isfinite(agb_legacy_0010) & (agb_legacy_0010 > 0.0)
        _ratio = agb_pft_ibis[_ratio_mask] / agb_legacy_0010[_ratio_mask]
        row.update({
            "jules_lai_bdt_agb_mean_kg_m2": float(np.mean(_new)) if _new.size else float("nan"),
            "jules_lai_bdt_agb_median_kg_m2": float(np.median(_new)) if _new.size else float("nan"),
            "jules_lai_bdt_agb_p05_kg_m2": float(np.percentile(_new, 5)) if _new.size else float("nan"),
            "jules_lai_bdt_agb_p95_kg_m2": float(np.percentile(_new, 95)) if _new.size else float("nan"),
            "jules_lai_bdt_agb_max_kg_m2": float(np.max(_new)) if _new.size else float("nan"),
            "legacy_0010_agb_mean_kg_m2": float(np.mean(_old)) if _old.size else float("nan"),
            "legacy_0010_agb_median_kg_m2": float(np.median(_old)) if _old.size else float("nan"),
            "legacy_0010_agb_p95_kg_m2": float(np.percentile(_old, 95)) if _old.size else float("nan"),
            "pft_ibis_to_legacy_ratio_mean": float(np.mean(_ratio)) if _ratio.size else float("nan"),
            "pft_ibis_to_legacy_ratio_median": float(np.median(_ratio)) if _ratio.size else float("nan"),
        })
        for _p in [0, 4, 5, 6, 7, 10]:
            _pm = igrid.land & (optpft_round_agb == _p) & np.isfinite(agb_pft_ibis)
            row[f"pft_ibis_pft{_p:02d}_count"] = int(np.count_nonzero(_pm))
            row[f"pft_ibis_pft{_p:02d}_agb_sum_kg_m2_cells"] = float(
                np.nansum(agb_pft_ibis[_pm])
            ) if np.any(_pm) else 0.0
        summary_rows.append(row)

        if i in snapshot_index_to_labels:
            snapshot_fields = {
                "elevation_m": z, "soil_depth_m": h, "soil_texture_class": igrid.texture0,
                "vegetation_code": veg_code, "npp": npp, "eemt": eemt,
                "agb_pft_ibis": agb_pft_ibis.astype("float32"),
                "agb_legacy_0010": agb_legacy_0010.astype("float32"),
                "optpft": optpft_agb.astype("float32"),
                "bare_bedrock": bare_bedrock.astype("float32"),
            }
            if "lai_node" in veg:
                snapshot_fields["lai"] = np.asarray(veg["lai_node"], dtype="float32")
            if "bgc_rootspace_node" in veg:
                snapshot_fields["bgc_rootspace"] = np.asarray(veg["bgc_rootspace_node"], dtype="float32")
            if "bgc_lai_cap_node" in veg:
                snapshot_fields["bgc_lai_cap"] = np.asarray(veg["bgc_lai_cap_node"], dtype="float32")
            fields = _mask_snapshot_fields(snapshot_fields, igrid.land)
            for requested_ka in snapshot_index_to_labels[i]:
                snap_dir = res_dir / snapshot_dir_name(requested_ka)
                snap_dir.mkdir(parents=True, exist_ok=True)
                for name, arr in fields.items():
                    write_geotiff(snap_dir / f"{name}.tif", arr, igrid.transform, str(igrid.crs))
                write_cell_csv(snap_dir / "cell_values.csv", igrid.x, igrid.y, igrid.lon, igrid.lat, igrid.land, fields)
                snap_row = row.copy()
                snap_row["snapshot_requested_ka"] = float(requested_ka)
                snapshot_rows.append(snap_row)

        if dynamic_on and i < len(times) - 1:
            next_ka = float(times[i + 1])
            interval_kyr = max(float(ka) - next_ka, 0.0)
            z, b, h, geomorph_stats = _advance_geomorph_interval_adaptive(
                geomorph_cfg, z, b, h, igrid.land, boundary_cfg, eemt, agb,
                interval_kyr=interval_kyr,
                dx_m=float(igrid.resolution_m),
                max_substep_kyr=float(run_config.science.geomorph_substep_kyr),
                min_substep_kyr=float(run_config.science.geomorph_min_substep_kyr),
                fluvial_max_change_tolerance_m=float(run_config.science.geomorph_fluvial_max_change_m),
                adaptive=bool(run_config.science.geomorph_adaptive_substeps),
            )
            row["geomorph_accepted_substeps_to_next"] = geomorph_stats["accepted_substeps"]
            row["geomorph_rejected_substeps_to_next"] = geomorph_stats["rejected_or_halved_substeps"]
            row["geomorph_rejected_fluvial_trials_to_next"] = geomorph_stats["rejected_fluvial_trials"]
            row["geomorph_min_dt_kyr_to_next"] = geomorph_stats["min_dt_kyr"]
            row["geomorph_max_dt_kyr_to_next"] = geomorph_stats["max_dt_kyr"]
            row["geomorph_fluvial_tolerance_m"] = geomorph_stats["fluvial_max_change_tolerance_m"]
            row["geomorph_max_accepted_fluvial_change_m_to_next"] = geomorph_stats["max_accepted_fluvial_change_m"]
        # 정적 케이스는 z, b, h를 의도적으로 고정한다.

    # Primary validation: every model output inside each palaeovegetation interval.
    # With the default 0.1-kyr interval these are 100-year time-step evaluations.
    # They are repeated temporal evaluations, not independent palaeo observations.
    validation_rows = validation_mod.finalize_per_output_validation_rows(validation_step_rows)
    # Secondary diagnostic retained from hotfix3: one time-weighted mean row per interval.
    validation_interval_rows = validation_mod.aggregate_interval_validation_rows(validation_step_rows)

    validation_accuracy_rows = []
    if validation_rows:
        rows_by_case = {case_label: validation_rows}
        accuracy_df = validation_mod.compute_selected_accuracy_table(
            rows_by_case,
            method=str(run_config.science.validation_accuracy_method),
            threshold_fraction=float(run_config.science.basin_presence_min_fraction),
        )
        if not accuracy_df.empty:
            accuracy_df.to_csv(res_dir / "validation_accuracy.csv", index=False, encoding="utf-8-sig")
            validation_mod.make_accuracy_bar_chart(accuracy_df, res_dir / "figures" / "validation_accuracy.png")
            validation_accuracy_rows = accuracy_df.to_dict("records")

    pd.DataFrame(summary_rows).to_csv(res_dir / "summary_timeseries.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(snapshot_rows).to_csv(res_dir / "snapshot_summary.csv", index=False, encoding="utf-8-sig")
    if validation_rows:
        pd.DataFrame(validation_rows).to_csv(
            res_dir / "validation_per_output_time.csv", index=False, encoding="utf-8-sig"
        )
        # Historical filename restored to its original per-output-time semantics.
        pd.DataFrame(validation_rows).to_csv(
            res_dir / "validation_buffer0m_time_aware.csv", index=False, encoding="utf-8-sig"
        )
    if validation_interval_rows:
        pd.DataFrame(validation_interval_rows).to_csv(
            res_dir / "validation_interval_area_fraction.csv", index=False, encoding="utf-8-sig"
        )

    return {
        "output_dir": str(res_dir), "geomorph_dynamic": dynamic_on,
        "n_cells": int(np.sum(igrid.land)),
        "resolution_m": igrid.resolution_m,
        "biome4_variant": str(run_config.science.biome4_variant),
        "validation_rows": validation_rows,
        "validation_per_output_rows": validation_rows,
        "validation_interval_rows": validation_interval_rows,
        "validation_accuracy_rows": validation_accuracy_rows,
        "validation_accuracy_method": str(run_config.science.validation_accuracy_method),
        # Compatibility alias for scripts that used the hotfix3 key.
        "validation_diagnostic_rows": validation_rows,
    }


def run(run_config: RunConfig, progress_callback: Optional[object] = None) -> Dict[str, object]:
    """Run the selected static, dynamic, or static+dynamic comparison mode.

    Comparison mode compares the two model configurations at the *single user-selected*
    palaeovegetation occupancy threshold.  It does not automatically generate the old
    1%/5%/10% threshold-sensitivity bundle.
    """
    if run_config.mode not in (RunMode.STATIC, RunMode.DYNAMIC, RunMode.COMPARISON):
        raise ValueError("실행 모드는 정적모델, 동적모델 또는 정적+동적 비교여야 합니다.")

    _variant = str(run_config.science.biome4_variant).strip().lower()
    if _variant not in {"mckenzie2003", "original"}:
        raise ValueError(
            "hotfix10l strict-reference 배포판은 BIOME4-SD McKenzie2003과 원본 BIOME4 비교 기준만 실행합니다. "
            "토심→NPP/LAI/FVC 직접 보정, MuSo/Biome-BGC/Kang 토심 반응은 과학 실행 경로에서 허용하지 않습니다."
        )

    method = str(run_config.science.validation_accuracy_method)
    if method not in {"per_output_time", "interval_any_dt"}:
        raise ValueError(f"알 수 없는 고식생 정확도 측정 방법입니다: {method}")

    igrid = build_initial_grid(run_config, resolution_m_override=run_config.resolution_m_override)
    boundary_cfg = BoundaryConfig.from_shapefiles(
        land_mask=igrid.land, transform=igrid.transform, dst_crs=igrid.crs,
        common_slope_percent=run_config.common_slope_percent,
        open_free_shp=run_config.inputs.open_free_shp,
        open_fixed_slope_shp=run_config.inputs.open_fixed_slope_shp,
        snap_to_land_boundary=run_config.snap_open_cells_to_boundary,
    )

    results: Dict[str, object] = {}
    if run_config.mode in (RunMode.STATIC, RunMode.COMPARISON):
        results["static"] = run_single_case(
            run_config, dynamic_on=False, output_subdir="model_static",
            igrid=igrid, boundary_cfg=boundary_cfg, case_label="정적모델",
            progress_callback=progress_callback,
            force_compile_on_first_step=bool(run_config.science.force_compile_biome4),
        )
    if run_config.mode in (RunMode.DYNAMIC, RunMode.COMPARISON):
        results["dynamic"] = run_single_case(
            run_config, dynamic_on=True, output_subdir="model_dynamic",
            igrid=igrid, boundary_cfg=boundary_cfg, case_label="동적모델",
            progress_callback=progress_callback,
            force_compile_on_first_step=(
                bool(run_config.science.force_compile_biome4)
                if run_config.mode == RunMode.DYNAMIC
                else False
            ),
        )

    results["validation_accuracy_method"] = method

    if run_config.mode == RunMode.COMPARISON:
        out_root = Path(run_config.output_dir)
        out_root.mkdir(parents=True, exist_ok=True)

        # Primary validation: compare static vs dynamic at exactly one configured
        # threshold and the selected accuracy aggregation method.
        rows_by_case = {
            "정적모델": results["static"].get("validation_per_output_rows", []),
            "동적모델": results["dynamic"].get("validation_per_output_rows", []),
        }
        if any(rows_by_case.values()):
            combined = []
            for label, records in rows_by_case.items():
                for raw in records:
                    row = dict(raw)
                    row["case_label"] = label
                    combined.append(row)
            per_output_df = pd.DataFrame(combined)
            per_output_df.to_csv(
                out_root / "validation_per_output_time_static_dynamic.csv",
                index=False, encoding="utf-8-sig",
            )

            configured_threshold = float(run_config.science.basin_presence_min_fraction)
            accuracy_df = validation_mod.compute_selected_accuracy_table(
                rows_by_case,
                method=method,
                threshold_fraction=configured_threshold,
            )
            accuracy_df.to_csv(
                out_root / "validation_accuracy_static_dynamic.csv",
                index=False, encoding="utf-8-sig",
            )
            validation_mod.make_accuracy_bar_chart(
                accuracy_df, out_root / "figures" / "validation_accuracy_static_dynamic.png"
            )
            results["validation_per_output_rows"] = per_output_df.to_dict("records")
            results["validation_accuracy_rows"] = accuracy_df.to_dict("records")

        # Secondary diagnostic: record-level time-weighted mean area fraction.
        interval_rows_by_case = {
            "정적모델": results["static"].get("validation_interval_rows", []),
            "동적모델": results["dynamic"].get("validation_interval_rows", []),
        }
        if any(interval_rows_by_case.values()):
            combined_interval = []
            for label, records in interval_rows_by_case.items():
                for raw in records:
                    row = dict(raw)
                    row["case_label"] = label
                    combined_interval.append(row)
            interval_df = pd.DataFrame(combined_interval)
            interval_df.to_csv(
                out_root / "validation_interval_area_fraction_static_dynamic.csv",
                index=False, encoding="utf-8-sig",
            )
            summary_df = validation_mod.compute_interval_summary_table(interval_rows_by_case)
            summary_df.to_csv(
                out_root / "validation_interval_summary_static_dynamic.csv",
                index=False, encoding="utf-8-sig",
            )
            validation_mod.make_interval_area_fraction_chart(
                interval_rows_by_case, out_root / "figures" / "validation_interval_area_fraction_bar.png"
            )
            results["validation_interval_rows"] = interval_df.to_dict("records")
            results["validation_interval_summary"] = summary_df.to_dict("records")

        # Difference maps (dynamic - static) for each requested snapshot.
        diff_dir = Path(run_config.output_dir) / "model_difference_dynamic_minus_static"
        requested_ka = run_config.time.snapshot_ka if run_config.time.snapshot_ka else run_config.time.snapshot_times_ka()
        diff_written = []
        for ka in requested_ka:
            snap_name = snapshot_dir_name(float(ka))
            static_dir = Path(results["static"]["output_dir"]) / snap_name
            dynamic_dir = Path(results["dynamic"]["output_dir"]) / snap_name
            if not (static_dir.exists() and dynamic_dir.exists()):
                continue
            out_snap_dir = diff_dir / snap_name
            for var in ("elevation_m", "soil_depth_m", "npp", "eemt"):
                sf, df_ = static_dir / f"{var}.tif", dynamic_dir / f"{var}.tif"
                if not (sf.exists() and df_.exists()):
                    continue
                with rasterio.open(sf) as s_ds, rasterio.open(df_) as d_ds:
                    s_arr = s_ds.read(1)
                    d_arr = d_ds.read(1)
                    s_nodata, d_nodata = s_ds.nodata, d_ds.nodata
                    s_valid = s_arr != s_nodata if s_nodata is not None else np.isfinite(s_arr)
                    d_valid = d_arr != d_nodata if d_nodata is not None else np.isfinite(d_arr)
                    diff = np.where(s_valid & d_valid, d_arr - s_arr, np.nan)
                    out_snap_dir.mkdir(parents=True, exist_ok=True)
                    write_geotiff(out_snap_dir / f"{var}_diff.tif", diff, d_ds.transform, str(d_ds.crs))

            # Vegetation code is categorical; write match(1)/mismatch(0), not numeric subtraction.
            sf, df_ = static_dir / "vegetation_code.tif", dynamic_dir / "vegetation_code.tif"
            if sf.exists() and df_.exists():
                with rasterio.open(sf) as s_ds, rasterio.open(df_) as d_ds:
                    s_arr = s_ds.read(1)
                    d_arr = d_ds.read(1)
                    s_nodata, d_nodata = s_ds.nodata, d_ds.nodata
                    s_valid = s_arr != s_nodata if s_nodata is not None else np.isfinite(s_arr)
                    d_valid = d_arr != d_nodata if d_nodata is not None else np.isfinite(d_arr)
                    both_valid = s_valid & d_valid
                    match = np.where(both_valid, (np.rint(s_arr) == np.rint(d_arr)).astype("float32"), np.nan)
                    out_snap_dir.mkdir(parents=True, exist_ok=True)
                    write_geotiff(out_snap_dir / "vegetation_code_match.tif", match, d_ds.transform, str(d_ds.crs))
            diff_written.append(float(ka))
        results["difference_maps_ka"] = diff_written

        # Report figures: paired snapshot figures and time-series comparisons.
        try:
            fig_dir = out_root / "figures"
            snap_figs = figures_mod.make_snapshot_figures(
                static_dir=Path(results["static"]["output_dir"]),
                dynamic_dir=Path(results["dynamic"]["output_dir"]),
                snapshots=requested_ka, fig_dir=fig_dir,
            )
            ts_figs = figures_mod.make_timeseries_figures(
                static_dir=Path(results["static"]["output_dir"]),
                dynamic_dir=Path(results["dynamic"]["output_dir"]),
                fig_dir=fig_dir,
            )
            results["report_figures"] = [str(p) for p in (snap_figs + ts_figs)]
        except Exception as exc:  # noqa: BLE001
            results["report_figures_error"] = str(exc)

        # Compact standard result-board requested for Yongneup reporting.
        # Output-only postprocessing; it does not alter model state or validation.
        try:
            std = standard_report_mod.make_standard_report(out_root, allow_nearest=False)
            results["standard_report_dir"] = std.get("report_dir")
            results["standard_report_figures"] = std.get("figures", [])
        except Exception as exc:  # noqa: BLE001
            results["standard_report_error"] = str(exc)

    else:
        # Top-level aliases keep GUI/result consumers simple for single-model runs.
        case_key = "dynamic" if run_config.mode == RunMode.DYNAMIC else "static"
        case_result = results[case_key]
        if case_result.get("validation_per_output_rows"):
            results["validation_per_output_rows"] = case_result["validation_per_output_rows"]
        if case_result.get("validation_interval_rows"):
            results["validation_interval_rows"] = case_result["validation_interval_rows"]
        if case_result.get("validation_accuracy_rows"):
            results["validation_accuracy_rows"] = case_result["validation_accuracy_rows"]

    return results
