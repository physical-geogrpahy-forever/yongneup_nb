# -*- coding: utf-8 -*-
"""
geomorph.py — Pelletier-process 지형발달 모듈 (다중 open 경계 일반화판)

원본은 yongneup_dynstat20m 패키지의 단일 outlet 버전을 바탕으로 한다. 경계조건은
다중 open 경계로 일반화했으며, 비선형 사면수송은 질량보존식 dz/dt = -div(q)의
부호를 명시적으로 적용해 높은 곳에서 낮은 곳으로 확산되도록 교정했다.

    단일 outlet 우선순위-흐름채움(priority-flood, 단일소스 Dijkstra)
        →  다중 open 경계 우선순위-흐름채움(다중소스 Dijkstra)

각 유역 내부 셀은 "가장 먼저 도달하는" open 셀에 자연스럽게 배정된다
(표준 multi-source priority-flood). 각 open 셀의 유출 방식에 따라 서로 다른
경사-바이어스(eps, m/cell)를 적용한다:

    open_free         : boundary.BoundaryConfig.free_tie_break_eps_m (거의 0,
                         평탄영역 타이브레이크용)
    open_fixed_slope   : boundary.BoundaryConfig.common_slope_percent 로부터
                         유도된 물리적 경사 (eps_m = slope% / 100 * dx_m)

두 open 유형 모두 지형발달 상태(z/b/h)에는 fixed base-level(Dirichlet)
경계로 작동한다. 즉 open 셀 자체는 in-domain receiver가 없으므로 Eq. (16)의
하천침식 경사를 local 2-D slope로 대체하지 않으며, 각 geomorphic substep 뒤
open 셀의 z/b/h를 입력 상태로 정확히 복원한다. open 유형의 차이는 라우팅
표면을 만드는 방식에만 남는다.
"""
from __future__ import annotations

import heapq
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.ndimage import distance_transform_edt, map_coordinates
from rasterio.transform import rowcol, xy

from .boundary import BoundaryConfig


@dataclass
class PelletierStrictConfig:
    """지형발달 계수. 기본값은 모두 본 패키지의 Pelletier-process 모듈 기본값이다.

    GUI에서는 이 dataclass의 각 필드에 대해 "이 계수는 Pelletier-process 모듈의
    기본값입니다"라는 도움말을 노출하고, 사용자가 값을 바꾸면 기본값과 달라졌음을
    표시한다 (pb4studio.config.PARAM_METADATA 참고).
    """

    p0_base_m_per_kyr: float = 0.037
    eemt_to_p0_b: float = 0.030
    h0_m: float = 0.50
    # Pelletier et al. (2013), Table 1 / Eq. (8): direct bedrock/regolith density ratio.
    bedrock_regolith_density_ratio: float = 1.8
    # Legacy serialization-only fields; no longer used in Eq. (8).
    rock_density_kg_m3: float = 2700.0
    soil_bulk_density_kg_m3: float = 1400.0
    uplift_m_per_kyr: float = 0.20
    kd_c_eemt_m_per_kyr_per_mj: float = 0.033
    kd_d_agb_m_per_kyr_per_kgm2: float = 0.050
    # Yongneup real-DEM numerical default selected after the bundled 20 m / 1 kyr
    # convergence audit. Pelletier et al. (2013) used Sc=0.7 and tested 0.9;
    # those values remain sensitivity cases rather than the Yongneup default.
    hillslope_critical_slope: float = 1.50
    # Legacy JSON field only; the active Eq. (20)-(21) path does not use a
    # denominator floor. Supercritical faces are handled before Eq. (20).
    hillslope_denom_min: float = 0.0
    # 하위호환용 필드. v6.1부터 상태변수 h에는 양의 최소토심을 강제하지
    # 않는다. 값이 들어와도 계산에는 사용하지 않으며 h >= 0만 보장한다.
    min_land_soil_m: float = 0.0
    k0_regolith: float = 0.020
    # Legacy field retained for old JSON compatibility only. Eq. (18) uses actual positive EEMT.
    eemt_min_for_erodibility: float = 0.0
    channel_width_coeff: float = 0.005
    channel_width_exp: float = 0.50
    # Legacy field retained for old JSON compatibility only; Eq. (17) has no 1 m floor.
    channel_width_min_m: float = 0.0
    # Legacy serialization fields only. The strict Pelletier (2010) A/w path
    # below does not use a fixed contributing-area threshold or manual
    # cell-size correction. They remain only so older saved JSON still loads.
    valley_area_threshold_m2: float = 10000.0
    cell_size_correction_enabled: bool = False
    cell_size_reference_m: float = 10.0
    # Freeman (1991) MFD exponent used for the Pelletier (2010)
    # grid-resolution-dependence classifier.
    mfd_slope_exponent: float = 1.10
    # Pelletier (2010): f=A_delta/A_delta/2. f<1.2 valley, f>=1.2 hillslope.
    grid_dependence_valley_threshold: float = 1.20
    bedrock_erosion_resistance: float = 10.0
    # 하위호환용 필드. v6.1부터 고도변화량을 사후 비례축소하지 않는다.
    # 수치 안정성은 runner의 적응형 시간세분화로 확보한다.
    max_abs_dz_per_step_m: float = 0.0
    sink_fill_enabled: bool = True

    # 레거시 필드: from_legacy_single_outlet() 하위호환 경로에서만 참조된다.
    # 새 다중경계 워크플로우에서는 BoundaryConfig.common_slope_percent /
    # free_tie_break_eps_m 이 이 값을 대체한다.
    outlet_epsilon_gradient_m: float = 0.001
    outlet_snap_radius_cells: int = 1
    outlet_prefer_boundary_cell: bool = True


def _as_float_array(a) -> np.ndarray:
    return np.asarray(a, dtype="float64").copy()


_NEIGHBOURS = [
    (-1, -1, np.sqrt(2.0)), (-1, 0, 1.0), (-1, 1, np.sqrt(2.0)),
    (0, -1, 1.0),                          (0, 1, 1.0),
    (1, -1, np.sqrt(2.0)),  (1, 0, 1.0),   (1, 1, np.sqrt(2.0)),
]


def snap_outlet_to_grid(
    outlet_x: float,
    outlet_y: float,
    transform,
    land: np.ndarray,
    cfg: PelletierStrictConfig,
) -> Dict[str, float | int]:
    """(레거시) EPSG 좌표를 가장 가까운 유효 셀로 스냅한다.

    새 GUI 경계 편집기에서는 사용자가 직접 셀을 클릭/드래그로 선택하므로 이
    함수는 더 이상 메인 경로에서 쓰이지 않지만, 좌표 기반 outlet을 그대로
    불러와야 하는 하위호환 시나리오(구버전 config.json 임포트 등)를 위해
    유지한다.
    """
    land = np.asarray(land, dtype=bool)
    nrows, ncols = land.shape

    raw_row, raw_col = rowcol(transform, float(outlet_x), float(outlet_y), op=round)
    raw_row = int(np.clip(raw_row, 0, nrows - 1))
    raw_col = int(np.clip(raw_col, 0, ncols - 1))

    boundary = np.zeros_like(land, dtype=bool)
    for r in range(nrows):
        for c in range(ncols):
            if not land[r, c]:
                continue
            if r == 0 or r == nrows - 1 or c == 0 or c == ncols - 1:
                boundary[r, c] = True
                continue
            if not (land[r - 1, c] and land[r + 1, c] and land[r, c - 1] and land[r, c + 1]):
                boundary[r, c] = True

    radius_values = list(range(max(int(cfg.outlet_snap_radius_cells), 0), max(int(cfg.outlet_snap_radius_cells), 0) + 1))
    radius_values.extend([2, 3, 5, 10, max(nrows, ncols)])

    best = None
    for radius in radius_values:
        candidates = []
        r0, r1 = max(0, raw_row - radius), min(nrows - 1, raw_row + radius)
        c0, c1 = max(0, raw_col - radius), min(ncols - 1, raw_col + radius)
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if not land[r, c]:
                    continue
                if bool(cfg.outlet_prefer_boundary_cell) and not boundary[r, c]:
                    continue
                cx, cy = xy(transform, r, c, offset="center")
                dist = float(np.hypot(float(cx) - float(outlet_x), float(cy) - float(outlet_y)))
                candidates.append((dist, r, c, float(cx), float(cy)))
        if candidates:
            best = min(candidates, key=lambda item: item[0])
            break

    if best is None:
        rows, cols = np.where(land)
        if rows.size == 0:
            raise ValueError("No land cells exist in the basin mask; cannot snap outlet.")
        centres = [xy(transform, int(r), int(c), offset="center") for r, c in zip(rows, cols)]
        dists = [float(np.hypot(float(cx) - outlet_x, float(cy) - outlet_y)) for cx, cy in centres]
        k = int(np.argmin(dists))
        best = (dists[k], int(rows[k]), int(cols[k]), float(centres[k][0]), float(centres[k][1]))

    dist, row, col, sx, sy = best
    return {
        "input_outlet_x": float(outlet_x), "input_outlet_y": float(outlet_y),
        "outlet_row": int(row), "outlet_col": int(col),
        "snapped_outlet_x": float(sx), "snapped_outlet_y": float(sy),
        "snap_distance_m": float(dist),
        "raw_outlet_row": int(raw_row), "raw_outlet_col": int(raw_col),
    }


def _land_only_axis_derivative(
    z: np.ndarray, land: np.ndarray, dx_m: float, axis: int,
) -> np.ndarray:
    """Derivative from land-land node pairs only.

    A land/outside pair is not a computational face for local terrain slope.
    If both axial neighbours are land, use a centred difference; if only one
    land neighbour exists, use the one-sided land-land difference; if neither
    exists, that directional component is zero. No elevation is invented
    outside the basin. Closed-boundary sediment flux remains separately zero
    because the face-flux routine already evaluates only land-land faces.
    """
    z = np.asarray(z, dtype="float64")
    land = np.asarray(land, dtype=bool) & np.isfinite(z)
    deriv = np.zeros_like(z, dtype="float64")

    neg = np.zeros_like(land)
    pos = np.zeros_like(land)
    zneg = np.zeros_like(z, dtype="float64")
    zpos = np.zeros_like(z, dtype="float64")

    if axis == 1:
        neg[:, 1:] = land[:, :-1]
        pos[:, :-1] = land[:, 1:]
        zneg[:, 1:] = z[:, :-1]
        zpos[:, :-1] = z[:, 1:]
    elif axis == 0:
        neg[1:, :] = land[:-1, :]
        pos[:-1, :] = land[1:, :]
        zneg[1:, :] = z[:-1, :]
        zpos[:-1, :] = z[1:, :]
    else:
        raise ValueError("axis must be 0 or 1")

    both = land & neg & pos
    pos_only = land & (~neg) & pos
    neg_only = land & neg & (~pos)
    dx = float(dx_m)
    deriv[both] = (zpos[both] - zneg[both]) / (2.0 * dx)
    deriv[pos_only] = (zpos[pos_only] - z[pos_only]) / dx
    deriv[neg_only] = (z[neg_only] - zneg[neg_only]) / dx
    return deriv


def local_slope_and_costheta(z: np.ndarray, dx_m: float, land: np.ndarray | None = None) -> Tuple[np.ndarray, np.ndarray]:
    z = _as_float_array(z)
    if land is None:
        dz_dy, dz_dx = np.gradient(z, float(dx_m), float(dx_m))
        valid = np.isfinite(z)
    else:
        land = np.asarray(land, dtype=bool)
        valid = land & np.isfinite(z)
        dz_dx = _land_only_axis_derivative(z, valid, dx_m, axis=1)
        dz_dy = _land_only_axis_derivative(z, valid, dx_m, axis=0)

    slope = np.sqrt(dz_dx * dz_dx + dz_dy * dz_dy)
    cos_theta = 1.0 / np.sqrt(1.0 + slope * slope)
    slope = np.where(valid & np.isfinite(slope), slope, 0.0)
    cos_theta = np.where(valid & np.isfinite(cos_theta), cos_theta, 1.0)
    return slope, cos_theta


# ---------------------------------------------------------------------------
# 다중 open 경계 우선순위-흐름채움 (기존 단일소스 버전의 다중소스 일반화)
# ---------------------------------------------------------------------------

def _priority_flood_fill_to_boundaries(
    z: np.ndarray,
    land: np.ndarray,
    open_cells: List[Tuple[int, int]],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[Tuple[int, int]]]:
    """모든 open 셀을 동시에 시작점으로 하는 다중소스 우선순위-흐름채움.

    각 내부 셀은 (elevation 기준 Dijkstra 순서로) 가장 먼저 도달한 open 셀에
    배정된다. open 셀이 1개뿐이면 기존 단일소스 알고리즘과 완전히 동일하다.

    Returns
    -------
    filled : 채워진 라우팅 표면
    pathdist_cells : 배정된 open 셀로부터의 경로거리 (셀 단위)
    source_idx : 각 셀이 배정된 open 셀의 valid_open 상 인덱스 (-1 = 미배정)
    valid_open : 실제로 유효한(유역 내부, 유한값) open 셀 목록, 시드 순서
    """
    z = _as_float_array(z)
    land = np.asarray(land, dtype=bool)
    nrows, ncols = z.shape

    valid_open = [
        (int(r), int(c)) for (r, c) in open_cells
        if 0 <= r < nrows and 0 <= c < ncols and land[r, c] and np.isfinite(z[r, c])
    ]

    filled = np.full_like(z, np.nan, dtype="float64")
    pathdist_cells = np.full_like(z, np.nan, dtype="float64")
    source_idx = np.full((nrows, ncols), -1, dtype="int32")
    visited = np.zeros_like(land, dtype=bool)

    if not valid_open:
        return np.where(land, z, np.nan), np.where(land, 0.0, np.nan), source_idx, valid_open

    heap = []
    counter = 0
    for k, (r, c) in enumerate(valid_open):
        start_elev = float(z[r, c])
        filled[r, c] = start_elev
        pathdist_cells[r, c] = 0.0
        source_idx[r, c] = k
        visited[r, c] = True
        heapq.heappush(heap, (start_elev, counter, r, c))
        counter += 1

    while heap:
        elev, _, r, c = heapq.heappop(heap)
        for dr, dc, dist_fac in _NEIGHBOURS:
            rr, cc = r + dr, c + dc
            if rr < 0 or rr >= nrows or cc < 0 or cc >= ncols:
                continue
            if visited[rr, cc] or (not land[rr, cc]) or (not np.isfinite(z[rr, cc])):
                continue
            cell_elev = float(z[rr, cc])
            fill_elev = max(cell_elev, float(elev))
            filled[rr, cc] = fill_elev
            pathdist_cells[rr, cc] = float(pathdist_cells[r, c]) + float(dist_fac)
            source_idx[rr, cc] = source_idx[r, c]
            visited[rr, cc] = True
            counter += 1
            heapq.heappush(heap, (fill_elev, counter, rr, cc))

    missing = land & (~visited) & np.isfinite(z)
    filled[missing] = z[missing]
    pathdist_cells[missing] = 0.0

    filled = np.where(land, filled, np.nan)
    pathdist_cells = np.where(land, pathdist_cells, np.nan)
    return filled, pathdist_cells, source_idx, valid_open


def _routing_surface_to_boundaries(
    z: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    dx_m: float,
    sink_fill_enabled: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[Tuple[int, int]]]:
    """모든 open 경계로 배수되는 라우팅 표면을 만든다 (모델 실제 고도 z는 불변).

    open_free 셀은 거의 0에 가까운 타이브레이크 경사만, open_fixed_slope 셀은
    사용자가 지정한 공통 경사(%)에서 유도된 물리적 경사를 라우팅 표면에만
    더한다.
    """
    z = _as_float_array(z)
    land = np.asarray(land, dtype=bool)
    open_cells = boundary_cfg.all_open_cells()

    if bool(sink_fill_enabled):
        filled_z, pathdist_cells, source_idx, valid_open = _priority_flood_fill_to_boundaries(z, land, open_cells)
    else:
        # 흐름채움을 끈 경우: 각 셀을 가장 가까운(유클리드) open 셀에 배정.
        valid_open = [
            (int(r), int(c)) for (r, c) in open_cells
            if land[r, c] and np.isfinite(z[r, c])
        ]
        rows, cols = np.indices(z.shape)
        filled_z = np.where(land, z, np.nan)
        if valid_open:
            oc_arr = np.array(valid_open)
            d2 = (rows[..., None] - oc_arr[:, 0]) ** 2 + (cols[..., None] - oc_arr[:, 1]) ** 2
            source_idx = np.argmin(d2, axis=-1).astype("int32")
            pathdist_cells = np.sqrt(np.take_along_axis(d2, source_idx[..., None], axis=-1)[..., 0])
            source_idx = np.where(land, source_idx, -1)
            pathdist_cells = np.where(land, pathdist_cells, np.nan)
        else:
            source_idx = np.full(z.shape, -1, dtype="int32")
            pathdist_cells = np.where(land, 0.0, np.nan)

    eps_cellwise = np.zeros_like(z, dtype="float64")
    if valid_open:
        eps_by_source = np.array([boundary_cfg.eps_m_for_cell(oc, dx_m) for oc in valid_open])
        has_src = source_idx >= 0
        eps_cellwise[has_src] = eps_by_source[source_idx[has_src]]

    routing_z = filled_z + eps_cellwise * pathdist_cells
    sink_fill_depth = np.where(land & np.isfinite(filled_z) & np.isfinite(z), np.maximum(filled_z - z, 0.0), np.nan)
    routing_z = np.where(land, routing_z, np.nan)
    return routing_z, filled_z, sink_fill_depth, source_idx, valid_open


def sink_fill_depth_to_boundaries(
    cfg: PelletierStrictConfig,
    z: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    dx_m: float,
) -> np.ndarray:
    """진단/스냅샷용 라우팅 전용 sink-fill 깊이."""
    _, _, sink_fill_depth, _, _ = _routing_surface_to_boundaries(
        z=z, land=land, boundary_cfg=boundary_cfg, dx_m=dx_m,
        sink_fill_enabled=bool(getattr(cfg, "sink_fill_enabled", True)),
    )
    return sink_fill_depth


def d8_flow_accumulation_area_multi_boundary(
    z: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    dx_m: float,
    cfg: PelletierStrictConfig,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """D8 기여면적 계산 — 모든 open 경계 셀에서 유역 밖으로 유출 가능.

    다른 모든 경계 셀은 닫혀 있다(no-flux). open 셀이 1개뿐이면 기존
    d8_flow_accumulation_area_closed_boundary와 완전히 동일한 결과를 낸다.
    """
    land = np.asarray(land, dtype=bool)
    nrows, ncols = land.shape
    z_route, z_filled, sink_fill_depth, source_idx, valid_open = _routing_surface_to_boundaries(
        z=z, land=land, boundary_cfg=boundary_cfg, dx_m=dx_m,
        sink_fill_enabled=bool(getattr(cfg, "sink_fill_enabled", True)),
    )
    open_set = set(valid_open)

    receiver_row = np.tile(np.arange(nrows)[:, None], (1, ncols))
    receiver_col = np.tile(np.arange(ncols)[None, :], (nrows, 1))
    slope_to_receiver = np.zeros((nrows, ncols), dtype="float64")

    for r in range(nrows):
        for c in range(ncols):
            if not land[r, c] or not np.isfinite(z_route[r, c]):
                continue
            if (r, c) in open_set:
                receiver_row[r, c] = -1
                receiver_col[r, c] = -1
                continue
            best_slope = 0.0
            best_r, best_c = r, c
            for dr, dc, dist_fac in _NEIGHBOURS:
                rr, cc = r + dr, c + dc
                if rr < 0 or rr >= nrows or cc < 0 or cc >= ncols:
                    continue
                if not land[rr, cc] or not np.isfinite(z_route[rr, cc]):
                    continue
                slope = (z_route[r, c] - z_route[rr, cc]) / (float(dx_m) * dist_fac)
                if slope > best_slope:
                    best_slope = float(slope)
                    best_r, best_c = rr, cc
            receiver_row[r, c] = best_r
            receiver_col[r, c] = best_c
            slope_to_receiver[r, c] = best_slope

    valid = np.flatnonzero(land.ravel() & np.isfinite(z_route.ravel()))
    order = valid[np.argsort(z_route.ravel()[valid])[::-1]]

    area_m2 = np.zeros((nrows, ncols), dtype="float64")
    area_m2[land] = float(dx_m) * float(dx_m)

    for idx in order:
        r, c = int(idx // ncols), int(idx % ncols)
        rr, cc = int(receiver_row[r, c]), int(receiver_col[r, c])
        if rr < 0 or cc < 0 or (rr == r and cc == c):
            continue
        area_m2[rr, cc] += area_m2[r, c]

    # Open boundary cells are Dirichlet base-level sinks, not ordinary
    # fluvial pixels with an inferred downstream receiver.  They have no
    # in-domain receiver, so Eq. (16) must not be evaluated there using a
    # substitute local 2-D slope.  Their slope_to_receiver therefore remains
    # exactly zero; interior cells immediately upstream still use their real
    # D8 slope to the fixed boundary cell.
    area_m2 = np.where(land & np.isfinite(area_m2), area_m2, 0.0)
    slope_to_receiver = np.where(land & np.isfinite(slope_to_receiver), slope_to_receiver, 0.0)
    return area_m2, receiver_row, receiver_col, slope_to_receiver, z_route, sink_fill_depth


def _fixed_baselevel_mask_from_boundary(
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
) -> np.ndarray:
    """Return active open-boundary cells held at fixed base level."""
    land = np.asarray(land, dtype=bool)
    fixed = np.zeros_like(land, dtype=bool)
    for r, c in boundary_cfg.all_open_cells():
        if 0 <= r < land.shape[0] and 0 <= c < land.shape[1] and land[r, c]:
            fixed[r, c] = True
    return fixed


def threshold_slope_adjustment(
    cfg: PelletierStrictConfig,
    z: np.ndarray,
    b: np.ndarray,
    h: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    dx_m: float,
    block_size: int = 512,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    """Lower excess topography so active-grid slopes do not exceed ``Sc``.

    This is a threshold/excess-topography closure for real DEMs that already
    contain slopes at or above the singular critical gradient of Pelletier
    et al. (2013) Eqs. (20)-(21).  It does *not* clamp the slope inserted into
    Eq. (20).  Instead it changes the actual topographic state before that
    equation is evaluated.

    For each active cell i we compute the greatest surface not exceeding the
    input topography that is Sc-Lipschitz in map distance::

        z_new(i) = min[z(i), min_j(z(j) + Sc * distance(i,j))]

    This is the excess-topography/critical-slope idea used in LEM threshold
    adjustment schemes.  Fixed base-level cells are never altered.  Surface
    lowering consumes mobile regolith first and bedrock only if necessary.
    Removed material is *accounted as threshold export* because this PB4
    Pelletier module has no independent mobile-sediment/runout state; it is
    never deposited immediately in a neighbouring H cell (the previous
    pairwise experiment caused artificial multi-metre piles).

    The all-pairs lower envelope is evaluated in blocks to avoid an O(N^2)
    memory allocation.  This operation introduces no calibrated parameter:
    only the existing Pelletier critical slope is used.
    """
    land = np.asarray(land, dtype=bool)
    z = _as_float_array(z)
    b = _as_float_array(b)
    h = np.where(land, np.maximum(_as_float_array(h), 0.0), 0.0)
    if z.shape != b.shape or z.shape != h.shape or z.shape != land.shape:
        raise ValueError("z, b, h, and land must have matching shapes")
    dx = float(dx_m)
    if not np.isfinite(dx) or dx <= 0.0:
        raise ValueError("dx_m must be finite and > 0")
    sc = float(cfg.hillslope_critical_slope)
    if not np.isfinite(sc) or sc <= 0.0:
        raise ValueError("hillslope_critical_slope must be finite and > 0")

    coords = np.argwhere(land)
    if coords.size == 0:
        zeros = np.zeros_like(z, dtype="float64")
        return z, b, h, {
            "surface_lowering_m": zeros,
            "soil_removed_m": zeros,
            "bedrock_lowered_m": zeros,
            "adjusted_mask": np.zeros_like(land, dtype=bool),
            "threshold_export_mass_equivalent_m": zeros,
        }

    values = z[land].astype("float64", copy=True)
    n = values.size
    lowered_values = values.copy()
    bs = max(int(block_size), 1)
    # Exact Euclidean lower envelope, evaluated in row blocks.
    rr = coords[:, 0].astype("float64")
    cc = coords[:, 1].astype("float64")
    for i0 in range(0, n, bs):
        i1 = min(i0 + bs, n)
        dr = (rr[i0:i1, None] - rr[None, :]) * dx
        dc = (cc[i0:i1, None] - cc[None, :]) * dx
        envelope = np.min(values[None, :] + sc * np.hypot(dr, dc), axis=1)
        lowered_values[i0:i1] = np.minimum(values[i0:i1], envelope)

    fixed = _fixed_baselevel_mask_from_boundary(land, boundary_cfg)
    fixed_flat = fixed[land]
    lowered_values[fixed_flat] = values[fixed_flat]

    lowering_flat = np.maximum(values - lowered_values, 0.0)
    lowering = np.zeros_like(z, dtype="float64")
    lowering[land] = lowering_flat

    h_new = h.copy()
    b_new = b.copy()
    soil_removed = np.zeros_like(z, dtype="float64")
    bedrock_lowered = np.zeros_like(z, dtype="float64")
    soil_take = np.minimum(h_new, lowering)
    soil_removed[land] = soil_take[land]
    h_new[land] -= soil_take[land]
    remainder = np.maximum(lowering - soil_take, 0.0)
    bedrock_lowered[land] = remainder[land]
    b_new[land] -= remainder[land]
    z_new = b_new + h_new

    # Fixed boundaries remain exact Dirichlet states.
    if np.any(fixed):
        z_new[fixed] = z[fixed]
        b_new[fixed] = b[fixed]
        h_new[fixed] = h[fixed]
        lowering[fixed] = 0.0
        soil_removed[fixed] = 0.0
        bedrock_lowered[fixed] = 0.0

    density_ratio = float(cfg.bedrock_regolith_density_ratio)
    mass_equiv = soil_removed + density_ratio * bedrock_lowered
    adjusted = land & (lowering > 1e-12)
    return z_new, b_new, h_new, {
        "surface_lowering_m": lowering,
        "soil_removed_m": soil_removed,
        "bedrock_lowered_m": bedrock_lowered,
        "adjusted_mask": adjusted,
        "threshold_export_mass_equivalent_m": mass_equiv,
    }


def nonlinear_hillslope_change_closed_boundary(
    cfg: PelletierStrictConfig,
    z: np.ndarray,
    h: np.ndarray,
    land: np.ndarray,
    eemt: np.ndarray,
    agb: np.ndarray,
    dt_kyr: float,
    dx_m: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    """Pelletier et al. (2013) Eqs. (20)-(22), on subcritical faces.

    The singular Eqs. (20)-(21) are evaluated only where |S_face| < Sc.
    Faces numerically equal to Sc are handled by ``threshold_slope_adjustment``
    and carry no Eq. (20) flux during that explicit substep.  No 1e-6
    denominator replacement, Sc-epsilon physical cap, or sign reversal is used.

    A finite-volume *supply/positivity* constraint scales a donor's outgoing
    face fluxes only when the finite explicit step would export more mobile
    regolith than exists in that donor.  It is not a substitute for the
    nonlinear stability solver and does not regularize the singular denominator.
    """
    land = np.asarray(land, dtype=bool)
    z = _as_float_array(z)
    h = np.maximum(_as_float_array(h), 0.0)
    eemt = _as_float_array(eemt)
    agb = np.maximum(_as_float_array(agb), 0.0)
    nrows, ncols = z.shape

    slope, cos_theta = local_slope_and_costheta(z, dx_m, land)
    kd = cfg.kd_c_eemt_m_per_kyr_per_mj * eemt + cfg.kd_d_agb_m_per_kyr_per_kgm2 * agb
    kd = np.where(land & np.isfinite(kd), np.maximum(kd, 0.0), 0.0)
    mobile_h = np.where(land, np.maximum(h, 0.0), 0.0)
    sc = float(cfg.hillslope_critical_slope)
    if not np.isfinite(sc) or sc <= 0.0:
        raise ValueError("hillslope_critical_slope must be finite and > 0")

    qx = np.zeros((nrows, max(ncols - 1, 1)), dtype="float64")
    qy = np.zeros((max(nrows - 1, 1), ncols), dtype="float64")
    sx = np.zeros_like(qx)
    sy = np.zeros_like(qy)
    super_x = np.zeros_like(qx, dtype=bool)
    super_y = np.zeros_like(qy, dtype=bool)

    # Equality tolerance is a standard sqrt(machine-epsilon) floating-point
    # comparison, not a physical Sc-epsilon. Threshold adjustment commonly
    # leaves a face at Sc to round-off precision; evaluating the singular Eq.20
    # on 0.899999999999... would otherwise create a purely numerical flux.
    eq_tol = np.sqrt(np.finfo("float64").eps) * max(1.0, abs(sc))

    if ncols > 1:
        both = land[:, :-1] & land[:, 1:]
        sx = (z[:, 1:] - z[:, :-1]) / float(dx_m)
        abs_sx = np.abs(sx)
        super_x = both & (abs_sx > sc + eq_tol)
        at_x = both & (np.abs(abs_sx - sc) <= eq_tol)
        active = both & ~super_x & ~at_x
        denom = 1.0 - np.square(sx / sc)
        kd_f = 0.5 * (kd[:, :-1] + kd[:, 1:])
        h_f = 0.5 * (mobile_h[:, :-1] + mobile_h[:, 1:])
        qx[active] = -kd_f[active] * h_f[active] * sx[active] / denom[active]

    if nrows > 1:
        both = land[:-1, :] & land[1:, :]
        sy = (z[1:, :] - z[:-1, :]) / float(dx_m)
        abs_sy = np.abs(sy)
        super_y = both & (abs_sy > sc + eq_tol)
        at_y = both & (np.abs(abs_sy - sc) <= eq_tol)
        active = both & ~super_y & ~at_y
        denom = 1.0 - np.square(sy / sc)
        kd_f = 0.5 * (kd[:-1, :] + kd[1:, :])
        h_f = 0.5 * (mobile_h[:-1, :] + mobile_h[1:, :])
        qy[active] = -kd_f[active] * h_f[active] * sy[active] / denom[active]

    if np.any(super_x) or np.any(super_y):
        raise FloatingPointError(
            "Pelletier Eq.20/21 received a materially supercritical face after "
            "threshold adjustment"
        )

    flux_to_depth = float(dt_kyr) / float(dx_m)
    outgoing_depth = np.zeros_like(z, dtype="float64")
    if ncols > 1:
        outgoing_depth[:, :-1] += np.maximum(qx, 0.0) * flux_to_depth
        outgoing_depth[:, 1:] += np.maximum(-qx, 0.0) * flux_to_depth
    if nrows > 1:
        outgoing_depth[:-1, :] += np.maximum(qy, 0.0) * flux_to_depth
        outgoing_depth[1:, :] += np.maximum(-qy, 0.0) * flux_to_depth

    donor_scale = np.ones_like(z, dtype="float64")
    needs_limit = land & (outgoing_depth > mobile_h + 1e-15)
    donor_scale[needs_limit] = np.divide(
        mobile_h[needs_limit], outgoing_depth[needs_limit],
        out=np.zeros_like(mobile_h[needs_limit]), where=outgoing_depth[needs_limit] > 0.0,
    )
    donor_scale = np.clip(donor_scale, 0.0, 1.0)
    if ncols > 1:
        qx = np.where(qx >= 0.0, qx * donor_scale[:, :-1], qx * donor_scale[:, 1:])
    if nrows > 1:
        qy = np.where(qy >= 0.0, qy * donor_scale[:-1, :], qy * donor_scale[1:, :])

    div = np.zeros_like(z, dtype="float64")
    if ncols > 1:
        div[:, :-1] += qx
        div[:, 1:] -= qx
    if nrows > 1:
        div[:-1, :] += qy
        div[1:, :] -= qy
    div /= float(dx_m)
    dz_hill = -div * float(dt_kyr)
    dz_hill = np.where(land & np.isfinite(dz_hill), dz_hill, 0.0)
    diag = {
        "hillslope_supply_limited_mask": needs_limit,
        "hillslope_outgoing_depth_before_limit_m": outgoing_depth,
        "hillslope_supercritical_x_mask": super_x,
        "hillslope_supercritical_y_mask": super_y,
    }
    return dz_hill, slope, cos_theta, diag

def _mfd_flow_accumulation_area_on_routing_surface(
    routing_z: np.ndarray,
    land: np.ndarray,
    open_cells: List[Tuple[int, int]],
    dx_m: float,
    slope_exponent: float = 1.10,
) -> np.ndarray:
    """Freeman-style MFD contributing area on an already drainable surface.

    Each active cell contributes dx^2 and partitions its accumulated area to
    all strictly downslope 8-neighbours in proportion to S**p. Open boundary
    cells export their accumulated area and therefore do not route it back into
    the computational domain.
    """
    z = _as_float_array(routing_z)
    land = np.asarray(land, dtype=bool) & np.isfinite(z)
    nrows, ncols = z.shape
    open_set = {(int(r), int(c)) for r, c in open_cells}
    area = np.zeros_like(z, dtype="float64")
    area[land] = float(dx_m) ** 2

    valid = np.flatnonzero(land.ravel())
    # routing_z contains the priority-fill surface plus the existing tiny
    # outlet-directed tie-break gradient, so descending elevation order is a
    # valid topological processing order for strictly downslope MFD links.
    order = valid[np.argsort(z.ravel()[valid], kind="mergesort")[::-1]]
    p = float(slope_exponent)
    if not np.isfinite(p) or p <= 0.0:
        raise ValueError("mfd_slope_exponent must be finite and > 0")

    for idx in order:
        r, c = int(idx // ncols), int(idx % ncols)
        if (r, c) in open_set:
            continue
        z0 = float(z[r, c])
        receivers = []
        weights = []
        for dr, dc, dist_fac in _NEIGHBOURS:
            rr, cc = r + dr, c + dc
            if rr < 0 or rr >= nrows or cc < 0 or cc >= ncols or not land[rr, cc]:
                continue
            slope = (z0 - float(z[rr, cc])) / (float(dx_m) * float(dist_fac))
            if slope > 0.0:
                receivers.append((rr, cc))
                weights.append(slope ** p)
        if not weights:
            continue
        total_w = float(np.sum(weights))
        if not np.isfinite(total_w) or total_w <= 0.0:
            continue
        incoming = float(area[r, c])
        for (rr, cc), weight in zip(receivers, weights):
            area[rr, cc] += incoming * float(weight) / total_w

    return np.where(land & np.isfinite(area), area, 0.0)


def _bilinear_half_cell_dem(z: np.ndarray, land: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Interpolate a cell-centred DEM to pixel width delta/2.

    The computational basin mask is duplicated 2x2. Because the clipped DEM has
    no elevations outside that mask, nearest valid land elevations are used only
    as interpolation support across the outer mask edge; they do not create new
    active land cells.
    """
    z = _as_float_array(z)
    land = np.asarray(land, dtype=bool) & np.isfinite(z)
    nrows, ncols = z.shape
    if not np.any(land):
        return (
            np.full((nrows * 2, ncols * 2), np.nan, dtype="float64"),
            np.zeros((nrows * 2, ncols * 2), dtype=bool),
        )

    _, nearest = distance_transform_edt(~land, return_indices=True)
    support = z[tuple(nearest)]

    # Original coarse centres are 0,1,... in index coordinates. Fine-cell
    # centres over the same raster footprint are -0.25,0.25,0.75,... .
    rf = (np.arange(nrows * 2, dtype="float64") + 0.5) / 2.0 - 0.5
    cf = (np.arange(ncols * 2, dtype="float64") + 0.5) / 2.0 - 0.5
    rr, cc = np.meshgrid(rf, cf, indexing="ij")
    fine_z = map_coordinates(support, [rr, cc], order=1, mode="nearest")
    fine_land = np.repeat(np.repeat(land, 2, axis=0), 2, axis=1)
    return np.where(fine_land, fine_z, np.nan), fine_land


def _half_cell_boundary_config(
    boundary_cfg: BoundaryConfig,
    fine_land: np.ndarray,
) -> BoundaryConfig:
    """Map native open boundary pixels onto the exposed children at delta/2.

    A native boundary pixel represents a finite raster footprint. At half-cell
    resolution only child cells that still touch the outside of the basin are
    opened; opening all four children would incorrectly move the outlet inward
    by half a native pixel. Legacy per-cell tie-break overrides are scaled by
    1/2 so that the represented physical gradient is unchanged.
    """
    from .boundary import BoundaryType

    native_bt = np.asarray(boundary_cfg.boundary_type, dtype=np.uint8)
    fine_land = np.asarray(fine_land, dtype=bool)
    fine_bt = np.full(fine_land.shape, int(BoundaryType.CLOSED), dtype=np.uint8)
    nfr, nfc = fine_land.shape
    fine_overrides = {}

    def touches_outside(rr: int, cc: int) -> bool:
        for dr, dc, _ in _NEIGHBOURS:
            r2, c2 = rr + dr, cc + dc
            if r2 < 0 or r2 >= nfr or c2 < 0 or c2 >= nfc or not fine_land[r2, c2]:
                return True
        return False

    for r, c in boundary_cfg.all_open_cells():
        children = [(2*r+i, 2*c+j) for i in (0, 1) for j in (0, 1)]
        exposed = [(rr, cc) for rr, cc in children if fine_land[rr, cc] and touches_outside(rr, cc)]
        # Preserve drainage for malformed legacy configs whose open cell is not
        # actually on the basin edge; validation will still warn about it.
        chosen = exposed if exposed else [(rr, cc) for rr, cc in children if fine_land[rr, cc]]
        t = int(native_bt[r, c])
        for rr, cc in chosen:
            fine_bt[rr, cc] = t
            if (r, c) in boundary_cfg.legacy_eps_override_m:
                fine_overrides[(rr, cc)] = 0.5 * float(boundary_cfg.legacy_eps_override_m[(r, c)])

    fine_cfg = BoundaryConfig(
        boundary_type=fine_bt,
        common_slope_percent=float(boundary_cfg.common_slope_percent),
        free_tie_break_eps_m=0.5 * float(boundary_cfg.free_tie_break_eps_m),
    )
    fine_cfg.legacy_eps_override_m = fine_overrides
    return fine_cfg


def pelletier2010_unit_contributing_area(
    cfg: PelletierStrictConfig,
    z: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    dx_m: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Pelletier (2010) grid-resolution-independent unit contributing area.

    1. Compute Freeman MFD contributing area A_delta on the native DEM.
    2. Bilinearly interpolate the same DEM to pixel width delta/2 and compute
       A_delta/2 with the same MFD algorithm.
    3. Subsample A_delta/2 back to the native grid by the maximum value in each
       2x2 fine-cell subdomain.
    4. f=A_delta/A_delta/2(max). Pelletier's cutoff is f<1.2 for valley pixels
       and f>=1.2 for hillslopes.
    5. Return a=A/w with w=delta on hillslopes and w=g*A**i in valleys.

    The legacy fixed 1-ha threshold and manual cell-size correction are not
    involved in this calculation.
    """
    land = np.asarray(land, dtype=bool)
    if float(dx_m) <= 0.0:
        raise ValueError("dx_m must be > 0")

    native_route, _, _, _, native_open = _routing_surface_to_boundaries(
        z=z,
        land=land,
        boundary_cfg=boundary_cfg,
        dx_m=dx_m,
        sink_fill_enabled=bool(getattr(cfg, "sink_fill_enabled", True)),
    )
    a_native = _mfd_flow_accumulation_area_on_routing_surface(
        native_route,
        land,
        native_open,
        dx_m,
        slope_exponent=float(getattr(cfg, "mfd_slope_exponent", 1.10)),
    )

    fine_z, fine_land = _bilinear_half_cell_dem(z, land)
    fine_cfg = _half_cell_boundary_config(boundary_cfg, fine_land)
    fine_dx = float(dx_m) / 2.0
    fine_route, _, _, _, fine_open = _routing_surface_to_boundaries(
        z=fine_z,
        land=fine_land,
        boundary_cfg=fine_cfg,
        dx_m=fine_dx,
        sink_fill_enabled=bool(getattr(cfg, "sink_fill_enabled", True)),
    )
    a_fine = _mfd_flow_accumulation_area_on_routing_surface(
        fine_route,
        fine_land,
        fine_open,
        fine_dx,
        slope_exponent=float(getattr(cfg, "mfd_slope_exponent", 1.10)),
    )

    nrows, ncols = land.shape
    a_fine_max = a_fine.reshape(nrows, 2, ncols, 2).max(axis=(1, 3))
    f = np.divide(
        a_native,
        a_fine_max,
        out=np.full_like(a_native, np.nan, dtype="float64"),
        where=land & (a_fine_max > 0.0),
    )

    threshold = float(getattr(cfg, "grid_dependence_valley_threshold", 1.20))
    if not np.isfinite(threshold) or threshold <= 0.0:
        raise ValueError("grid_dependence_valley_threshold must be finite and > 0")
    valley = land & np.isfinite(f) & (f < threshold)

    width_hill = np.full_like(a_native, float(dx_m), dtype="float64")
    width_valley = float(cfg.channel_width_coeff) * np.power(
        np.maximum(a_native, 0.0), float(cfg.channel_width_exp)
    )
    width = np.where(valley, width_valley, width_hill)
    a_over_w = np.divide(
        a_native,
        np.maximum(width, 1e-12),
        out=np.zeros_like(a_native),
        where=land,
    )
    return a_over_w, a_native, a_fine_max, f, valley

def fluvial_erosion_depths_multi_boundary(
    cfg: PelletierStrictConfig,
    z: np.ndarray,
    h: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    eemt: np.ndarray,
    dt_kyr: float,
    dx_m: float,
    available_soil_m: np.ndarray | None = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """흐름 침식 (물리식은 원본과 동일, 경계조건만 다중 open으로 일반화)."""
    land = np.asarray(land, dtype=bool)
    h = np.maximum(_as_float_array(h), 0.0)
    eemt = _as_float_array(eemt)
    nonfinite_eemt = land & ~np.isfinite(eemt)
    if np.any(nonfinite_eemt):
        first = tuple(int(v) for v in np.argwhere(nonfinite_eemt)[0])
        raise ValueError(
            f"Non-finite EEMT on active land in fluvial erosion: "
            f"{int(np.count_nonzero(nonfinite_eemt))} cell(s); first at row={first[0]}, col={first[1]}"
        )

    area_m2, receiver_r, receiver_c, slope_to_recv, routing_z, sink_fill_depth = d8_flow_accumulation_area_multi_boundary(
        z=z, land=land, boundary_cfg=boundary_cfg, dx_m=dx_m, cfg=cfg,
    )

    # Pelletier (2010) Eq. (32) supplies the unit contributing area A/w.
    # Keep the existing D8 result only for receiver slope/routing diagnostics;
    # contributing area for Eq. (16) is the native-grid MFD area used by the
    # resolution-dependence classifier.
    a_over_w, area_m2, area_halfmax_m2, grid_ratio_f, valley = pelletier2010_unit_contributing_area(
        cfg=cfg, z=z, land=land, boundary_cfg=boundary_cfg, dx_m=dx_m,
    )

    # Ablation: retain the legacy D8 receiver slope in Eq. (16) while all other
    # cumulative corrections remain active.
    slope = np.maximum(slope_to_recv, 0.0)
    # Pelletier Eq. (18): K = K0 / EEMT. Do not reuse a project floor.
    bad_eemt = land & (~np.isfinite(eemt) | (eemt <= 0.0))
    if np.any(bad_eemt):
        first = tuple(int(v) for v in np.argwhere(bad_eemt)[0])
        raise ValueError(
            f"Pelletier Eq. (18) requires finite positive EEMT on active land; "
            f"{int(np.count_nonzero(bad_eemt))} bad cell(s), first row={first[0]}, col={first[1]}"
        )
    k_reg = np.divide(
        float(cfg.k0_regolith), eemt,
        out=np.zeros_like(eemt, dtype="float64"),
        where=land & np.isfinite(eemt) & (eemt > 0.0),
    )
    e_potential = k_reg * a_over_w * slope * float(dt_kyr)
    e_potential = np.where(land & np.isfinite(e_potential), np.maximum(e_potential, 0.0), 0.0)

    # 사면수송과 동일한 토양을 이중으로 사용할 수 없도록, 호출자가
    # 토양생산·사면수송 뒤의 실제 가용토심을 넘길 수 있다.
    if available_soil_m is None:
        mobile_soil = np.maximum(h, 0.0)
    else:
        mobile_soil = np.maximum(_as_float_array(available_soil_m), 0.0)
        if mobile_soil.shape != h.shape:
            raise ValueError("available_soil_m shape must match h")
    mobile_soil = np.where(land, mobile_soil, 0.0)
    e_reg = np.minimum(e_potential, mobile_soil)
    excess = np.maximum(e_potential - e_reg, 0.0)
    e_bed = excess / max(float(cfg.bedrock_erosion_resistance), 1e-6)

    return e_reg, e_bed, area_m2, slope, routing_z, sink_fill_depth, area_halfmax_m2, grid_ratio_f, valley


def update_pelletier_strict(
    cfg: PelletierStrictConfig,
    z: np.ndarray,
    b: np.ndarray,
    h: np.ndarray,
    land: np.ndarray,
    boundary_cfg: BoundaryConfig,
    eemt: np.ndarray,
    agb: np.ndarray,
    dt_kyr: float,
    dx_m: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    """z, b, h 상태를 한 geomorphic substep 전진시킨다."""
    land = np.asarray(land, dtype=bool)
    b = _as_float_array(b)
    h = np.maximum(_as_float_array(h), 0.0)
    h = np.where(land, h, 0.0)

    # Every open outlet is a fixed base-level (Dirichlet) geomorphic boundary.
    # The boundary type still controls only the routing-surface tie-break /
    # prescribed routing gradient.  The physical z/b/h state of an open cell
    # is held at its value on entry to this substep.  Because the next substep
    # receives that unchanged state, the boundary remains fixed at its initial
    # model value without inventing an external elevation or slope.
    fixed_baselevel_mask = _fixed_baselevel_mask_from_boundary(land, boundary_cfg)

    z_state = b + h
    eemt_arr = _as_float_array(eemt)
    agb_arr = _as_float_array(agb)
    nonfinite_eemt = land & ~np.isfinite(eemt_arr)
    nonfinite_agb = land & ~np.isfinite(agb_arr)
    if np.any(nonfinite_eemt):
        first = tuple(int(v) for v in np.argwhere(nonfinite_eemt)[0])
        raise ValueError(f"Non-finite EEMT on active land: first at row={first[0]}, col={first[1]}")
    if np.any(nonfinite_agb):
        first = tuple(int(v) for v in np.argwhere(nonfinite_agb)[0])
        raise ValueError(f"Non-finite AGB on active land: first at row={first[0]}, col={first[1]}")

    # Real-DEM threshold closure: remove excess topography before evaluating the
    # singular Pelletier Eq.20/21.  In ordinary accepted states this is a no-op;
    # it is essential for an initially oversteepened measured DEM.
    z_state, b, h, threshold_pre = threshold_slope_adjustment(
        cfg, z_state, b, h, land, boundary_cfg, dx_m
    )

    slope, cos_theta = local_slope_and_costheta(z_state, dx_m, land)
    # Eq. (18)의 0 나눗셈 방지 하한은 하천침식 분모에만 적용한다.
    # Eq. (10) 토양생산과 Eq. (15) 사면수송은 실제 finite EEMT를 사용한다.
    eemt_model = np.where(np.isfinite(eemt_arr), eemt_arr, 0.0)
    eemt_safe = np.maximum(eemt_model, cfg.eemt_min_for_erodibility)
    agb_safe = np.maximum(np.where(np.isfinite(agb_arr), agb_arr, 0.0), 0.0)

    p0 = float(cfg.p0_base_m_per_kyr) * np.exp(float(cfg.eemt_to_p0_b) * eemt_model)
    p_normal = p0 * np.exp(-(h * cos_theta) / max(float(cfg.h0_m), 1e-6))
    weathering_vertical = p_normal / np.maximum(cos_theta, 1e-6) * float(dt_kyr)
    density_ratio = float(cfg.bedrock_regolith_density_ratio)
    if not np.isfinite(density_ratio) or density_ratio <= 0.0:
        raise ValueError("bedrock_regolith_density_ratio must be finite and > 0")
    soil_gain = weathering_vertical * density_ratio
    uplift = float(cfg.uplift_m_per_kyr) * float(dt_kyr)

    # Soil production is available to the mobile layer in this geomorphic
    # substep; the finite-volume supply constraint therefore sees h+soil_gain.
    h_mobile = h + soil_gain
    dz_hill, slope_hill, cos_hill, hill_diag = nonlinear_hillslope_change_closed_boundary(
        cfg=cfg, z=z_state, h=h_mobile, land=land, eemt=eemt_model, agb=agb_safe, dt_kyr=dt_kyr, dx_m=dx_m,
    )

    h_after_hillslope = h_mobile + dz_hill
    min_intermediate = float(np.nanmin(h_after_hillslope[land])) if np.any(land) else 0.0
    if min_intermediate < -1e-8:
        raise FloatingPointError(
            f"Negative soil depth after production+hillslope transport: {min_intermediate:.6g} m"
        )
    h_after_hillslope = np.where(land, np.maximum(h_after_hillslope, 0.0), 0.0)

    e_reg, e_bed, area_m2, slope_flow, routing_z, sink_fill_depth, area_halfmax_m2, grid_ratio_f, valley_mask = fluvial_erosion_depths_multi_boundary(
        cfg=cfg, z=z_state, h=h, land=land, boundary_cfg=boundary_cfg,
        eemt=eemt_safe, dt_kyr=dt_kyr, dx_m=dx_m,
        available_soil_m=h_after_hillslope,
    )

    h_new = h_after_hillslope - e_reg
    min_final = float(np.nanmin(h_new[land])) if np.any(land) else 0.0
    if min_final < -1e-8:
        raise FloatingPointError(f"Negative final soil depth: {min_final:.6g} m")
    h_new = np.where(land, np.maximum(h_new, 0.0), 0.0)
    b_new = b + uplift - weathering_vertical - e_bed
    b_new = np.where(land, b_new, b)
    z_new = b_new + h_new

    # Processes within the trial can create new overcritical faces. Recast the
    # *actual topography* before the next Eq.20/21 evaluation, rather than
    # altering the slope variable or denominator.
    z_new, b_new, h_new, threshold_post = threshold_slope_adjustment(
        cfg, z_new, b_new, h_new, land, boundary_cfg, dx_m
    )

    # Fixed-base-level boundary enforcement.  Save the unconstrained trial
    # changes for audit, then restore z/b/h exactly at open boundary cells.
    # This is a boundary condition, not an erosion cap: no interior process
    # rate or coefficient is altered.
    boundary_trial_dh = np.where(fixed_baselevel_mask, h_new - h, 0.0)
    boundary_trial_db = np.where(fixed_baselevel_mask, b_new - b, 0.0)
    boundary_trial_dz = np.where(fixed_baselevel_mask, z_new - z_state, 0.0)
    if np.any(fixed_baselevel_mask):
        h_new = np.where(fixed_baselevel_mask, h, h_new)
        b_new = np.where(fixed_baselevel_mask, b, b_new)
        z_new = np.where(fixed_baselevel_mask, z_state, z_new)

    # 이전 버전의 ``max_abs_dz_per_step_m`` 사후축소는 제거했다. 그 방식은
    # 물리적 1 kyr를 진행한 뒤 모든 과정량을 임의로 줄여 모의시간과 과정률을
    # 불일치시켰다. 이제는 runner에서 시간간격 자체를 줄여 다시 계산한다.

    if np.any(land):
        for name, arr in (("z", z_new), ("b", b_new), ("h", h_new)):
            if not np.all(np.isfinite(arr[land])):
                raise FloatingPointError(f"Non-finite {name} state after geomorphic step")

    diagnostics = {
        "soil_production_m": np.where(land, soil_gain, 0.0),
        "bedrock_weathering_m": np.where(land, weathering_vertical, 0.0),
        "hillslope_dz_m": np.where(land, dz_hill, 0.0),
        "hillslope_supply_limited_mask": np.where(land, hill_diag["hillslope_supply_limited_mask"], False),
        "threshold_pre_surface_lowering_m": threshold_pre["surface_lowering_m"],
        "threshold_pre_soil_removed_m": threshold_pre["soil_removed_m"],
        "threshold_pre_bedrock_lowered_m": threshold_pre["bedrock_lowered_m"],
        "threshold_pre_export_mass_equivalent_m": threshold_pre["threshold_export_mass_equivalent_m"],
        "threshold_post_surface_lowering_m": threshold_post["surface_lowering_m"],
        "threshold_post_soil_removed_m": threshold_post["soil_removed_m"],
        "threshold_post_bedrock_lowered_m": threshold_post["bedrock_lowered_m"],
        "threshold_post_export_mass_equivalent_m": threshold_post["threshold_export_mass_equivalent_m"],
        "fluvial_regolith_erosion_m": e_reg,
        "fluvial_bedrock_erosion_m": e_bed,
        "contributing_area_m2": area_m2,
        "contributing_area_halfres_max_m2": np.where(land, area_halfmax_m2, 0.0),
        "grid_resolution_ratio_f": np.where(land, grid_ratio_f, np.nan),
        "valley_mask": np.where(land, valley_mask, False),
        "slope_local": slope,
        "slope_flow": slope_flow,
        "routing_z_m": routing_z,
        "sink_fill_depth_m": sink_fill_depth,
        "bare_bedrock_mask": np.where(land, h_new <= 0.0, False),
        "fixed_baselevel_mask": np.where(land, fixed_baselevel_mask, False),
        "boundary_trial_soil_change_m": boundary_trial_dh,
        "boundary_trial_bedrock_change_m": boundary_trial_db,
        "boundary_trial_surface_change_m": boundary_trial_dz,
        "soil_supply_residual_m": np.where(
            land & (~fixed_baselevel_mask),
            h_new - (h + soil_gain + dz_hill - e_reg),
            0.0,
        ),
    }
    # Keep dynamic geomorphic state in float64 across adaptive substeps.
    # Recasting ~1-km elevations to float32 after every accepted dt makes
    # round-off depend on substep count and can destroy T -> T/2 convergence.
    # Output writers may still down-cast at the I/O boundary.
    return z_new.astype("float64"), b_new.astype("float64"), h_new.astype("float64"), diagnostics


def pelletier_default_stable_dt_kyr(
    cfg: PelletierStrictConfig,
    eemt: np.ndarray,
    agb: np.ndarray,
    land: np.ndarray,
    dx_m: float,
) -> float:
    """Return Pelletier et al. (2013)'s conservative explicit-step estimate.

    The paper used ``0.01 * dx^2 / (2 * kd)`` as the default step for its
    depth- and nonlinear-slope-dependent transport implementation, with further
    dynamic reduction when necessary.  We use the maximum active-cell ``kd`` so
    one accepted substep is safe for the whole raster.
    """
    land = np.asarray(land, dtype=bool)
    eemt = np.maximum(_as_float_array(eemt), 0.0)
    agb = np.maximum(_as_float_array(agb), 0.0)
    kd = cfg.kd_c_eemt_m_per_kyr_per_mj * eemt + cfg.kd_d_agb_m_per_kyr_per_kgm2 * agb
    valid = land & np.isfinite(kd) & (kd > 0.0)
    if not np.any(valid):
        return float("inf")
    kd_max = float(np.nanmax(kd[valid]))
    return 0.01 * float(dx_m) ** 2 / (2.0 * kd_max)
