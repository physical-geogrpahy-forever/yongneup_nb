# -*- coding: utf-8 -*-
"""
config.py — 실행 전체를 하나로 묶는 설정.

포함 내용:
    TimeConfig   — 시작/종료 시점(ka BP), 시간 간격. 기후 NetCDF의 실제 시간
                   커버리지와 대조해 범위를 벗어나면 경고한다.
    RunMode      — static / dynamic / comparison
    PARAM_METADATA — PelletierStrictConfig의 모든 계수에 대해 "이 값은 본
                   패키지 Pelletier-process 모듈의 기본값입니다" 같은 도움말과
                   단위를 붙여 GUI 툴팁에 그대로 쓸 수 있게 한다.
    RunConfig    — 위 전부 + 입력 파일 경로 + 경계조건 + 코어수를 묶고,
                   JSON으로 저장/불러오기한다.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field, fields
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

from .boundary import BoundaryConfig
from .snapshots import map_snapshot_ages_to_output_indices
from .pelletier_geomorph import PelletierStrictConfig


class RunMode(str, Enum):
    STATIC = "static"
    DYNAMIC = "dynamic"
    COMPARISON = "comparison"  # static + dynamic 동시 실행 및 비교 산출물 생성


# ---------------------------------------------------------------------------
# Pelletier 계수 메타데이터 (GUI 도움말/툴팁용)
# ---------------------------------------------------------------------------
# 모든 기본값은 PelletierStrictConfig()의 dataclass 기본값과 동일하다
# (본 패키지 Pelletier-process 모듈 기본값). 유저가 값을 바꾸면 GUI는 이
# 메타데이터의 default와 비교해 "기본값과 다름"을 표시할 수 있다.

_PELLETIER_DEFAULT = PelletierStrictConfig()
_HIDDEN_DEPRECATED_FIELDS = {
    "min_land_soil_m", "max_abs_dz_per_step_m", "rock_density_kg_m3",
    "soil_bulk_density_kg_m3", "hillslope_denom_min", "eemt_min_for_erodibility",
    "channel_width_min_m", "valley_area_threshold_m2",
    "cell_size_correction_enabled", "cell_size_reference_m",
}

PARAM_METADATA: Dict[str, Dict[str, object]] = {
    "bedrock_regolith_density_ratio": {
        "unit": "-", "label": "기반암/레골리스 밀도비 (rho_b/rho_s)",
        "help": "Pelletier et al. (2013) Eq. (8) / Table 1의 직접 밀도비 1.8.",
    },
    "p0_base_m_per_kyr": {
        "unit": "m/kyr", "label": "기반암 토양생산 잠재계수 (a)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "나지 기반암에서의 잠재적 토양생산 속도(P0 = a·exp(b·EEMT))의 a항.",
    },
    "eemt_to_p0_b": {
        "unit": "-", "label": "EEMT 민감도 (b)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "토양생산이 EEMT(유효에너지·물질전달)에 얼마나 민감하게 반응하는지.",
    },
    "h0_m": {
        "unit": "m", "label": "토양생산 e-folding 깊이 (h0)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "토심이 깊어질수록 토양생산이 지수적으로 감소하는 특성깊이.",
    },
    "rock_density_kg_m3": {
        "unit": "kg/m^3", "label": "기반암 밀도",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다.",
    },
    "soil_bulk_density_kg_m3": {
        "unit": "kg/m^3", "label": "토양 용적밀도",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다.",
    },
    "uplift_m_per_kyr": {
        "unit": "m/kyr", "label": "융기율",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다 "
                "(동해안 융기율 참고값, 0.2 m/kyr = 0.2 mm/yr). 융기가 없는 "
                "민감도 실험을 하려는 경우에만 0으로 바꾸십시오.",
    },
    "kd_c_eemt_m_per_kyr_per_mj": {
        "unit": "m·kyr^-1 per MJ m^-2 yr^-1", "label": "사면수송계수 EEMT항 (c)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "비선형 사면수송계수 kd = c·EEMT + d·AGB 의 c항.",
    },
    "kd_d_agb_m_per_kyr_per_kgm2": {
        "unit": "m·kyr^-1 per kg m^-2", "label": "사면수송계수 AGB항 (d)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "비선형 사면수송계수 kd = c·EEMT + d·AGB 의 d항 (식생 지상부바이오매스 효과).",
    },
    "hillslope_critical_slope": {
        "unit": "m/m", "label": "임계경사 (Sc)",
        "help": "용늪 실제 DEM용 수치 기본값은 1.5입니다. "
                "Pelletier et al. (2013)의 본 실험값 0.7 및 sensitivity 값 0.9는 "
                "비교용으로 유지합니다. 비선형 사면수송식의 임계경사입니다.",
    },
    "hillslope_denom_min": {
        "unit": "-", "label": "비선형 분모 하한 (사용하지 않음)",
        "help": "하위호환용 필드입니다. 현재 Eq.20-21 경로에서는 분모 하한을 사용하지 않습니다.",
    },
    "min_land_soil_m": {
        "unit": "m", "label": "최소 토심 (사용하지 않음)",
        "help": "하위호환용 필드입니다. 현재 모델은 양의 최소토심을 강제하지 않고 h ≥ 0만 보장합니다.",
    },
    "k0_regolith": {
        "unit": "-", "label": "흐름침식 침식성계수 (K0)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "K = K0 / EEMT 로 정의되는 사면세류·집중류 침식 침식성계수.",
    },
    "eemt_min_for_erodibility": {
        "unit": "MJ m^-2 yr^-1", "label": "침식성계수 분모 EEMT 하한",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다.",
    },
    "channel_width_coeff": {
        "unit": "-", "label": "하도폭 계수 (g)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "하도폭 w = g·A^i 의 g항.",
    },
    "channel_width_exp": {
        "unit": "-", "label": "하도폭 지수 (i)",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "하도폭 w = g·A^i 의 i항.",
    },
    "channel_width_min_m": {
        "unit": "m", "label": "최소 하도폭",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다.",
    },
    "valley_area_threshold_m2": {
        "unit": "m^2", "label": "계곡(집중류) 기여면적 임계값",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "이 값 이상의 기여면적을 가진 셀은 사면류 대신 집중류(하도)로 취급됩니다. "
                "기본값은 1 ha입니다.",
    },
    "grid_dependence_valley_threshold": {
        "unit": "-", "label": "Pelletier 격자의존 valley 판별값 (f*)",
        "help": "Pelletier (2010) Eq. (32)의 f=A_delta/A_delta/2 판별값. "
                "f < 1.2는 valley, f >= 1.2는 hillslope로 분류합니다.",
    },
    "mfd_slope_exponent": {
        "unit": "-", "label": "MFD 경사 지수 (p)",
        "help": "Freeman식 MFD에서 하류 이웃으로 분배하는 가중치 S^p의 지수. "
                "Pelletier (2010)의 MFD 해상도 비교에 사용하는 기본값 1.1입니다.",
    },
    "bedrock_erosion_resistance": {
        "unit": "-", "label": "기반암 침식저항",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "기반암이 토양보다 몇 배 침식되기 어려운지.",
    },
    "max_abs_dz_per_step_m": {
        "unit": "m", "label": "스텝당 최대 고도변화 (사용하지 않음)",
        "help": "하위호환용 필드입니다. 현재 모델은 고도변화를 사후 축소하지 않고 시간간격을 줄여 재계산합니다.",
    },
    "sink_fill_enabled": {
        "unit": "bool", "label": "sink-fill 사용",
        "help": "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다. "
                "라우팅 전용 표면에 대해 open 경계까지의 우선순위-흐름채움을 적용할지 여부. "
                "모델 실제 고도(z)는 이 옵션과 무관하게 변경되지 않습니다.",
    },
}


def parameter_help_rows(cfg: Optional[PelletierStrictConfig] = None) -> List[Dict[str, object]]:
    """GUI 계수 설정 패널에 그대로 뿌릴 수 있는 (필드명, 현재값, 기본값, 도움말) 목록."""
    cfg = cfg or PelletierStrictConfig()
    rows = []
    for f in fields(PelletierStrictConfig):
        if f.name in _HIDDEN_DEPRECATED_FIELDS:
            continue
        meta = PARAM_METADATA.get(f.name, {})
        default_value = getattr(_PELLETIER_DEFAULT, f.name)
        current_value = getattr(cfg, f.name)
        rows.append({
            "name": f.name,
            "label": meta.get("label", f.name),
            "unit": meta.get("unit", ""),
            "help": meta.get("help", "이 계수는 본 패키지 Pelletier-process 모듈의 기본값입니다."),
            "default_value": default_value,
            "current_value": current_value,
            "is_default": bool(current_value == default_value),
        })
    return rows


# ---------------------------------------------------------------------------
# 시간 설정
# ---------------------------------------------------------------------------

@dataclass
class TimeConfig:
    start_ka: float = 21.0    # CHELSA21K: 최대 21 ka BP
    end_ka: float = 0.0       # 시뮬레이션 종료 시점 (ka BP, 현재에 가까움)
    interval_kyr: float = 0.1  # 기본 결합/출력 간격: 0.1 kyr = 100년

    # 기본(None)이면 모든 스텝에서 GeoTIFF/CSV 스냅샷을 저장한다. 특정
    # ka 시점만 저장하고 싶으면(예: 기존 용늪 검증 실행의 120/90/60/30/0)
    # 명시적으로 지정한다 — 내부 계산은 여전히 interval_kyr 간격으로 수행된다.
    snapshot_ka: Optional[Tuple[float, ...]] = None

    def __post_init__(self):
        if self.start_ka <= self.end_ka:
            raise ValueError(
                f"start_ka({self.start_ka})는 end_ka({self.end_ka})보다 커야 합니다 "
                "(start=과거, end=현재에 더 가까운 시점)."
            )
        if self.start_ka > 21.0 + 1e-9 or self.end_ka > 21.0 + 1e-9:
            raise ValueError(
                f"PB4Studio CHELSA21K는 0~21 ka BP만 실행할 수 있습니다: "
                f"start={self.start_ka}, end={self.end_ka}"
            )
        if self.end_ka < -1e-9:
            raise ValueError("PB4Studio CHELSA21K의 종료시점은 0 ka BP보다 미래일 수 없습니다.")
        if self.interval_kyr <= 0:
            raise ValueError(f"interval_kyr는 0보다 커야 합니다: {self.interval_kyr}")
        if self.snapshot_ka is not None:
            map_snapshot_ages_to_output_indices(self.snapshot_times_ka(), self.snapshot_ka)

    @property
    def n_steps(self) -> int:
        """지형 업데이트 구간 수. 마지막 구간은 interval_kyr보다 짧을 수 있다."""
        return max(0, len(self.snapshot_times_ka()) - 1)

    def snapshot_times_ka(self) -> List[float]:
        """start_ka부터 end_ka까지의 모델 시점 목록을 반환한다.

        ``interval_kyr``가 전체 기간을 정확히 나누지 못해도 종료시점은 반드시
        정확히 한 번 포함한다. 예: 5→0 ka, 2 kyr 간격은 [5, 3, 1, 0]이다.
        마지막 지형 업데이트 구간만 1 kyr로 짧아진다.
        """
        start = float(self.start_ka)
        end = float(self.end_ka)
        step = float(self.interval_kyr)
        tol = max(1e-10, step * 1e-10)

        times: List[float] = [round(start, 6)]
        current = start
        while (current - step) > (end + tol):
            current -= step
            times.append(round(current, 6))

        end_rounded = round(end, 6)
        if abs(times[-1] - end_rounded) <= tol:
            times[-1] = end_rounded
        else:
            times.append(end_rounded)
        return times

    def climate_coverage_ka(self, climate_nc_path: Path) -> Dict[str, float]:
        """기후 NetCDF 또는 내장 CSV가 커버하는 ka BP 범위를 반환한다."""
        climate_nc_path = Path(climate_nc_path)
        if climate_nc_path.suffix.lower() == ".csv":
            import pandas as pd
            df = pd.read_csv(climate_nc_path, usecols=["ka_bp"])
            ka = pd.to_numeric(df["ka_bp"], errors="coerce").to_numpy(dtype="float64")
            ka = ka[np.isfinite(ka)]
            if ka.size == 0:
                raise ValueError(f"기후 자료({climate_nc_path})의 ka_bp 열에 유효값이 없습니다.")
        else:
            import xarray as xr
            with xr.open_dataset(climate_nc_path, decode_times=False) as ds:
                time_name = None
                for cand in ("time", "ka_bp", "age_ka", "age", "year", "years", "years_bp"):
                    if cand in ds.coords or cand in ds.dims:
                        time_name = cand
                        break
                if time_name is None:
                    raise ValueError(f"기후 자료({climate_nc_path})에서 시간 좌표를 찾을 수 없습니다.")
                raw = np.asarray(ds[time_name].values, dtype="float64")
                attrs = dict(ds[time_name].attrs)
            ka = _convert_time_to_ka_bp(raw, attrs)
        return {"min_ka": float(np.nanmin(ka)), "max_ka": float(np.nanmax(ka))}

    def validate_against_climate(self, climate_nc_path: Path) -> List[str]:
        """요청한 시간범위가 기후자료 커버리지를 벗어나면 경고 메시지를 반환한다."""
        warnings: List[str] = []
        try:
            coverage = self.climate_coverage_ka(climate_nc_path)
        except Exception as exc:  # noqa: BLE001 - 사용자에게 그대로 보여줄 메시지
            warnings.append(f"기후 자료의 시간 커버리지를 확인하지 못했습니다: {exc}")
            return warnings

        if self.start_ka > coverage["max_ka"] + 1e-9:
            warnings.append(
                f"시작 시점({self.start_ka} ka BP)이 기후 자료 커버리지 "
                f"({coverage['min_ka']:.3f}~{coverage['max_ka']:.3f} ka BP)를 벗어납니다."
            )
        if self.end_ka < coverage["min_ka"] - 1e-9:
            warnings.append(
                f"종료 시점({self.end_ka} ka BP)이 기후 자료 커버리지 "
                f"({coverage['min_ka']:.3f}~{coverage['max_ka']:.3f} ka BP)를 벗어납니다."
            )
        return warnings


def _convert_time_to_ka_bp(values: np.ndarray, attrs: Optional[Dict[str, object]] = None) -> np.ndarray:
    """NetCDF 시간/연대 좌표를 ka BP로 변환한다 (원본 로직과 동일, 변경 없음)."""
    vals = np.asarray(values, dtype="float64")
    attrs = attrs or {}
    units = str(attrs.get("units", "")).lower()
    name = str(attrs.get("long_name", "")).lower()
    standard_name = str(attrs.get("standard_name", "")).lower()
    label = " ".join([units, name, standard_name])

    if "ka" in label or "kyr" in label:
        return np.abs(vals)
    if "since present" in units or "before present" in units or "bp" in label:
        return np.abs(vals) / 1000.0
    if "year" in label or "yr" in label:
        return np.abs(vals) / 1000.0
    if np.nanmax(np.abs(vals)) > 200.0:
        return np.abs(vals) / 1000.0
    return np.abs(vals)


# ---------------------------------------------------------------------------
# 병렬처리 코어 수
# ---------------------------------------------------------------------------

def resolve_core_count(requested: Optional[int]) -> int:
    """유저가 요청한 코어 수를 이 컴퓨터에서 실제 쓸 수 있는 범위로 정리한다."""
    detected = os.cpu_count() or 1
    if requested is None or requested <= 0:
        # 기본값: 전체 논리 코어 중 하나는 UI 응답성을 위해 남겨둔다.
        return max(1, detected - 1) if detected > 1 else 1
    return int(max(1, min(requested, detected)))


# ---------------------------------------------------------------------------
# 최상위 실행 설정
# ---------------------------------------------------------------------------

@dataclass
class InputPaths:
    dem_path: str
    climate_nc_path: str
    soil_depth_path: str
    soil_texture_path: str
    basin_polygon_path: str
    open_free_shp: Optional[str] = None
    open_fixed_slope_shp: Optional[str] = None
    soil_depth_unit: str = "cm"  # 토심 래스터의 단위 (BDRICM 기본값은 cm)
    validation_points_csv: Optional[str] = None  # None=내장 전국 검증 데이터셋 자동 사용, ""=검증 끄기, 경로=그 파일 사용


@dataclass
class ScienceConfig:
    """BIOME4 결합/토양 수리/EEMT/AGB 계수. 기본값은 모두 원본
    yongneup_dynstat20m 패키지(YongneupConfig)와 동일하다.

    Pelletier 지형발달 계수(PelletierStrictConfig)와는 별개로, BIOME4에 넘길
    토양 수리 파라미터 변환, EEMT(유효에너지·물질전달) 계산, AGB(지상부
    바이오매스) 프록시 산출에 쓰이는 상수들이다.
    """

    # hotfix10l default scientific path: BIOME4-SD reference-derived adapter.
    # Soil water storage follows McKenzie et al. (2003): theta(-10 kPa) -
    # theta(-1.5 MPa) integrated through actual soil depth using the Yongneup
    # SoilGrids point values supplied by the user. Root-depth scaling follows
    # McKenzie f(z)=exp(-z/Xi), with Xi analytically fixed from BIOME4's native
    # Jackson-et-al. top-30-cm root fraction. No fitted depth→NPP/LAI/FVC
    # coefficient is used. PFT6 uses the Sitch et al. (2003) BoNE climate sieve; the pre-existing
    # PFT5 TCM=-8 C project setting is retained unchanged in this patch.
    biome4_variant: str = "mckenzie2003"
    light_input_kind: str = "cloud_percent"
    force_compile_biome4: bool = False

    # 토성 3분류 -> BIOME4 수리 파라미터 변환
    use_soil_texture_for_hydraulics: bool = True
    perc_top_mm_hr: float = 20.0
    perc_bottom_mm_hr: float = 5.0
    texture1_perc_top_mm_hr: float = 5.0
    texture2_perc_top_mm_hr: float = 4.0
    texture3_perc_top_mm_hr: float = 3.0
    texture_bottom_mm_hr: float = 4.0
    whc_mm_per_m_top: float = 150.0
    whc_mm_per_m_bottom: float = 150.0
    texture1_whc_mm_per_m: float = 110.0
    texture2_whc_mm_per_m: float = 150.0
    texture3_whc_mm_per_m: float = 120.0
    whc_top_layer_m: float = 0.30
    whc_max_depth_m: float = 1.50

    # EEMT 계산
    eemt_cw_j_kg_k: float = 4186.0
    eemt_hbio_j_kg: float = 22.0e6
    eemt_carbon_fraction: float = 0.50
    eemt_clip_min_mj_m2_yr: float = 1.0
    eemt_clip_max_mj_m2_yr: float = 80.0

    # AGB 프록시 (kd = c*EEMT + d*AGB 의 AGB 입력)
    # NOTE: PelletierStrictConfig currently requires standing AGB. BIOME4 does
    # not prognose standing AGB, so this legacy bridge is retained only to keep
    # the existing Pelletier runner operational. It is NOT part of the claimed
    # pure-BIOME4 vegetation response and remains explicitly unresolved for a
    # future reference-only AGB coupling.
    agb_from_npp_scale: float = 0.010
    agb_min_kg_m2: float = 0.1
    agb_max_kg_m2: float = 100.0

    # 지형발달 최대 서브스텝 (kyr). 기본 0.1 kyr = 100년이다. 실제 dt는
    # Pelletier et al. (2013)의 명시적 안정시간 추정식에 따라 더 작아질 수 있다.
    geomorph_substep_kyr: float = 0.1
    geomorph_min_substep_kyr: float = 1.0e-10
    geomorph_adaptive_substeps: bool = True
    # Pure numerical tolerance, not a Pelletier process coefficient. Pelletier
    # et al. (2013) dynamically reduced dt when a trial produced too much
    # erosion/deposition and verified convergence by halving the threshold, but
    # did not publish its numerical value. The field name is retained for JSON
    # compatibility; hotfix10n2 applies the same 0.025 m tolerance to the maximum
    # hillslope/fluvial/threshold-adjustment change in a trial.
    geomorph_fluvial_max_change_m: float = 0.025

    # 이 값 이하의 토심은 상태변수에서 잘라 올리는 최소토심이 아니라,
    # BIOME4 계산을 우회할 노출 기반암 판정용 부동소수점 허용오차다.
    bare_bedrock_tolerance_m: float = 1.0e-6

    # 레거시 설정 필드. 검증 시간간격은 실제 모의 출력간격(TimeConfig.interval_kyr)을
    # 사용하며, 이 값은 기존 설정 파일을 읽기 위한 호환 목적으로만 남겨 둔다.
    validation_time_step_kyr: float = 1.0

    # 고식생 검증의 점유율 threshold. 각 palaeo record의 연대구간에 포함되는
    # 모델 출력시점에서 관측 식생이 0~3으로 유효하게 분류된 유역 셀의 이 비율
    # 이상이면 해당 dt가 일치로 판정된다.
    basin_presence_min_fraction: float = 0.01

    # 정확도 산정 단위:
    #   per_output_time  = 구간 안의 각 모델 출력시점(dt)을 평가
    #   interval_any_dt  = 구간 안에서 최소 한 번(dt)이라도 threshold 이상이면 구간 일치
    validation_accuracy_method: str = "per_output_time"


class _LegacyCfgShim:
    """climate.py에 있는(원본 그대로 옮긴) 함수들이 기대하는 ``cfg.<field>``
    인터페이스를, 새 ScienceConfig + 코어수로 조립해서 제공하는 얇은 어댑터.

    이렇게 하는 이유: climate.py의 함수 본문은 원본 코드 그대로이며 검증된
    상태를 유지하고 싶다. 그 함수들의 시그니처를 새 dataclass에 맞게 다시
    쓰는 대신, 이 어댑터가 필요한 속성 이름을 그대로 노출한다.
    """

    def __init__(self, science: ScienceConfig, core_count: int):
        self._science = science
        self.biome4_threads_per_resolution = int(core_count)

    def __getattr__(self, name):
        return getattr(self._science, name)


@dataclass
class RunConfig:
    mode: RunMode
    inputs: InputPaths
    time: TimeConfig
    common_slope_percent: float = 0.5
    snap_open_cells_to_boundary: bool = False  # 기본 꺼짐: 입력 shp 좌표를 그대로 신뢰. 켜면 가장 가까운 유역 경계 셀로 자동 이동
    resolution_m_override: Optional[float] = None  # None=DEM 네이티브 해상도 자동사용. 값을 주면 그 해상도로 강제 리샘플링
    requested_core_count: Optional[int] = None
    pelletier: PelletierStrictConfig = field(default_factory=PelletierStrictConfig)
    science: ScienceConfig = field(default_factory=ScienceConfig)
    output_dir: str = "outputs"
    basin_all_touched: bool = False

    @property
    def resolved_core_count(self) -> int:
        return resolve_core_count(self.requested_core_count)

    def legacy_cfg_shim(self) -> _LegacyCfgShim:
        return _LegacyCfgShim(self.science, self.resolved_core_count)

    def to_json(self, path: Path) -> None:
        payload = {
            "mode": self.mode.value,
            "inputs": asdict(self.inputs),
            "time": asdict(self.time),
            "common_slope_percent": self.common_slope_percent,
            "snap_open_cells_to_boundary": self.snap_open_cells_to_boundary,
            "resolution_m_override": self.resolution_m_override,
            "requested_core_count": self.requested_core_count,
            "pelletier": asdict(self.pelletier),
            "science": asdict(self.science),
            "output_dir": self.output_dir,
            "basin_all_touched": self.basin_all_touched,
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def from_json(cls, path: Path) -> "RunConfig":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        raw_mode = str(payload.get("mode", "comparison"))
        return cls(
            mode=RunMode(raw_mode),
            inputs=InputPaths(**payload["inputs"]),
            time=TimeConfig(**payload["time"]),
            common_slope_percent=float(payload.get("common_slope_percent", 0.5)),
            snap_open_cells_to_boundary=bool(payload.get("snap_open_cells_to_boundary", False)),
            resolution_m_override=payload.get("resolution_m_override"),
            requested_core_count=payload.get("requested_core_count"),
            pelletier=PelletierStrictConfig(**payload.get("pelletier", {})),
            science=ScienceConfig(**payload.get("science", {})),
            output_dir=payload.get("output_dir", "outputs"),
            basin_all_touched=bool(payload.get("basin_all_touched", False)),
        )
