# Yongneup hillslope Sc=1.5 audit — 2026-08-17

## Decision

- `PelletierStrictConfig.hillslope_critical_slope` default changed from **0.7 to 1.5**.
- This is a **Yongneup real-DEM numerical default**, not a claim that Pelletier et al. (2013) used 1.5.
- Pelletier et al. (2013) values **0.7** (main) and **0.9** (sensitivity) remain available for explicit sensitivity runs.
- No BIOME4 physiology, McKenzie/Jackson soil-depth response, fluvial K0/F/EEMT logic, Pelletier-2010 A/w classifier, or fixed-base-level outlet logic was changed in this patch.

## 20 m / 1 kyr production-path regression

The test creates `PelletierStrictConfig()` **without overriding Sc** and therefore verifies that the package default itself is 1.5.

### tolerance = 0.025 m

- initial land-land faces: 552
- initial `S > Sc`: 0
- initial threshold adjustment: 0 cells / 0 m
- accepted substeps: 120
- dt range: 6.25–12.5 yr
- final H min / mean / max: 0.104840 / 1.836665 / 3.267830 m
- H = 0 cells: 0
- H > 5 m cells: 0
- final maximum cardinal face slope: 1.182459
- final `S > Sc`: 0
- final-step hillslope supply-limiter cells: 0
- final-step threshold-adjustment cells: 0
- outlet drift: 0 m

### tolerance halving: 0.025 -> 0.0125 m

- max |ΔH|: 0.008139 m
- p99 |ΔH|: 0.002596 m
- mean |ΔH|: 0.000299 m
- max |Δz|: 0.008139 m
- p99 |Δz|: 0.002391 m
- max |Δb|: 0.000602 m
- H=0 mask mismatch: 0 cells

This passes the intended millimetre-to-centimetre-scale timestep-halving convergence check for the 20 m, 1 kyr Yongneup test.

## Interpretation

At 20 m the initial maximum cardinal face slope is about 1.332, so Sc=1.5 leaves the observed starting DEM unchanged. During the 1 kyr test the maximum face slope decreases to about 1.182 and neither threshold adjustment nor supply limiting is needed. Thus the verified 20 m path is effectively Pelletier Eq. 20–22 plus the existing adaptive timestep and fluvial fixes, rather than a run dominated by threshold recasting.

## Scope limitation

This audit verifies **20 m / 1 kyr** only. A 10 m run can still contain faces above Sc=1.5 and therefore must be diagnosed separately; this patch does not claim that Sc=1.5 eliminates overcritical faces at every resolution.
