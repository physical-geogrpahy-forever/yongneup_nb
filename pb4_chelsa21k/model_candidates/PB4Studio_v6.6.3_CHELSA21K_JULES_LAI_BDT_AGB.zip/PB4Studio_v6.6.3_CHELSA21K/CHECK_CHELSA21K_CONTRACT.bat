@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\test_chelsa21k_contract.py
) else (
  python tools\test_chelsa21k_contract.py
)
if errorlevel 1 pause
endlocal
