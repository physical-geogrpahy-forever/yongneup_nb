# Yongneup input-data audit — 2026-08-17

## hotfix10n5 status note
This file records the earlier input-data/depth-sensitivity audit. In hotfix10n5, `basin(1).geojson` is not an allowed scientific input, and the historical PFT6 project cutoff `TWM <= 22 C` is superseded by the Sitch et al. (2003) BoNE sieve (`TCM -32.5..-2 C`, `GDD5 >= 600`, `TWM <= 23 C`). PFT5 `TCM >= -8 C` remains unchanged pending a separate strict-reference decision.

## Uploaded data
- Climate: LateQuaternary_Environment_Korea_bbox(3).nc
- DEM: dem_clip.tif, EPSG:5187, ~10 m
- Texture: soilgrids_texture_biome4_table_3class_korea(1).tif
- Depth-to-bedrock: BDRICM_M_1km_ll(1).tif
- Basin/outlet: basin(1).geojson + yongneup_outlet.shp family

## Spatial audit
- DEM valid cells: 1,105
- DEM valid elevation: 1136.14–1227.08 m; mean 1162.08 m
- All 1,105 valid DEM cells sample BIOME4 texture class 2 (medium)
- BDRICM samples: 1,103 cells = 194 cm; 2 cells = 197 cm
- Outlet lies inside DEM and is EPSG:5187

## Climate audit
- Exact nearest grid: 128.25 E, 38.25 N
- Time: 120 ka to 0 ka; 2-kyr spacing to 22 ka, then 1-kyr spacing
- Required monthly variables present: temperature, precipitation, cloudiness; annual min_temperature present
- 0–6 ka MAT approx 7.09–7.88 C; MAP approx 1155–1344 mm/yr

## Pure BIOME4 depth sensitivity
- Texture fixed to observed class 2.
- Elevation fixed to DEM valid-cell mean 1162.08 m.
- Depth changed only through original BIOME4 WHC stores.
- No Kang/MuSo/Biome-BGC depth response.
- Historical setting during this audit: PFT5 TCM lower bound -8 C and PFT6 TWM upper bound 22 C; the PFT6 setting is superseded in hotfix10n5.
- Tested 0.05–1.50 m by 0.05 m plus 1.94 and 2.00 m, for 6,5,4,3,2,1,0 ka.
- Final biome class did not change with soil depth at any tested age.
- At 4 ka NPP changes only ~612 to 613 gC m-2 yr-1; LAI remains 3.20.
- At 1 ka NPP changes ~657 to 661; at 0 ka ~674 to 676.
- PFT5/PFT6 can show an abrupt 0.30->0.35 m jump where original BIOME4 fire-days fall to zero; this is native BIOME4 hydrology/fire behavior, not a fitted soil-depth coefficient.
- WHC saturates at 1.5 m in the original BIOME4 0.3 + 1.2 m profile, so 1.94 m and 2.0 m are identical to 1.5 m for vegetation hydrology.
