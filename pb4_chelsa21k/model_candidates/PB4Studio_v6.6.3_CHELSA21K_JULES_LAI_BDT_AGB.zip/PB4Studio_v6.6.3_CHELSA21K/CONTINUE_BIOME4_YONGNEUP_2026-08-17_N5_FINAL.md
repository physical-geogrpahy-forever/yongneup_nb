# 다음 채팅 이어받기 — Yongneup hotfix10n5 final state (2026-08-17)

## 1. 현재 production 기준
`hotfix10n5`를 현재 안정판으로 사용한다. 기반 geomorph는 hotfix10n3의 **20 m + Sc=1.5**이며 핵심 geomorph 소스(`pelletier_geomorph.py`, `runner.py`, `boundary.py`)는 n3와 SHA256이 동일하다. hillslope/하천 코드를 다시 뜯지 않는다.

## 2. BIOME4 토심 원칙
`mckenzie2003`만 사용한다. 토심 H는 McKenzie 2003 profile AWC + Jackson 1996 PFT별 finite-depth root accessibility를 통해 BIOME4 hydrology/competition에 들어간다. 직접 NPP/LAI/FVC multiplier, physiology tuning, DEM smoothing은 금지한다. `basin(1).geojson`도 사용 금지다.

## 3. PFT6 최종 수정
이전 handoff에는 Sitch 2003 BoNE를 `TCM -32.5~-2`, `GDD5>=600`, TWM ceiling 없음으로 적었으나 **원문 표 재확인 결과 TWM upper=23 C가 맞다.** 따라서 hotfix10n5는:
- TCM: -32.5 <= TCM < -2 C
- GDD5 >= 600
- TWM <= 23 C

를 사용한다. n3의 22 C cutoff는 제거되었다.

6/5/4/3 ka raw Beyer fine-depth에서 PFT6은 모든 420개 토심에서 양의 NPP를 보였다. optPFT6 토심대는 각각 약 0.091–0.154, 0.104–0.190, 0.097–0.136, 0.100–0.136 m이다. GDD5는 모두 약 2056–2093이므로 Dallmeyer-style GDD350과 Sitch GDD600의 PFT6 결과 차이는 이 네 시점에서 정확히 0이다. 기존 PFT6=0의 직접 원인은 22 C TWM cutoff였다.

## 4. PFT5는 미해결, 임의 수정 금지
PFT5 `TCM>=-8 C, GDD5>=900`은 n3 상태를 그대로 유지했다. raw Beyer 6–3 ka TCM이 -8.26~-8.91 C이므로 PFT5 NPP는 전 토심에서 0이다. 이전 handoff에서도 -8 C의 개별 문헌근거가 강하지 않다고 기록되어 있다. n4의 `TCM>=-19 C`는 reference trial일 뿐이며 production에 병합하지 않았다. 다음에 PFT5를 건드리려면 원본 BIOME4 복귀 vs 동아시아 reference를 별도 문헌판정해야 한다.

## 5. climate.py에서 새로 고친 숨은 오류
n3 계열은 NetCDF 추출 뒤 `-0.0065 C/m`를 자동 삽입하고 reference elevation이 없으면 basin mean elevation을 대신 넣었다. 이 숨은 보정을 n5에서 제거했다.
- raw Beyer default lapse = 0
- nonzero lapse를 쓰려면 `reference_elevation_m` 필수
- 월별 lapse를 월별로 적용
- reference elevation 없이 nonzero lapse를 주면 명시적 오류

`tools/test_climate_downscaling_contract.py` PASS.

## 6. 한국 seasonal-lapse 진단
기존 공식 `Gamma_i=-(0.00688+0.0015*cos(0.0172*(DOY-60))) C/m`과 ref 360/500/630 m를 corrected PFT6으로 다시 돌린 diagnostic 파일이 있다. 하지만 이 세 reference elevation은 sensitivity bracket일 뿐 최종값이 아니다. 360 m를 쓰면 TCM이 약 -15 C까지 떨어지고 PFT4까지 climate-excluded되는 시기가 생기므로 reference elevation 선택에 매우 민감하다.

## 7. 왜 최종 downscaled sweep을 아직 확정하지 않았는가
Beyer 2020 자체가 이미 0.5-degree observational climate와 Delta Method로 bias-correct/downscale된 제품이다. 현재 복구된 point climate에는 temperature의 scientific `reference_elevation_m`이 없다. Beyer 논문이 사용한 elevation/bathymetry는 land configuration 설명이지 temperature cell의 유효 기준고도라고 곧바로 볼 근거가 없다. 따라서 360/500/630 또는 basin mean을 임의로 production reference로 박지 않는다.

다음 climate 작업은 **Beyer 0.5-degree 온도를 20 m DEM에 추가 downscale할 때 어떤 명시적 baseline/reference를 사용할지 문헌·자료 provenance로 확정**하는 것이다. 그 뒤에만 6/5/4/3 ka final fine-depth downscaled sweep을 실행한다.

## 8. 핵심 산출물
- `PB4Studio_v6.6.3-corrected_FINAL_hotfix10n5_SITCH2003_BONE_TW23_SC15_20M_STABLE.zip`
- `PFT6_SITCH2003_BONE_AUDIT_2026-08-17.md`
- `HOTFIX10N5_FINAL_AUDIT_2026-08-17.md`
- `diagnostics/N5_REGRESSION_SUMMARY.json`
- `diagnostics/N4_VS_N5_PFT6_COMPARISON.csv`
- `diagnostics/YONGNEUP_SITCH2003_BONE_PFT456_DEPTH_FINE.csv`
- `diagnostics/YONGNEUP_SITCH2003_BONE_PFT456_DEPTH_SUMMARY.csv`
- `diagnostics/YONGNEUP_N5_KOREA_LAPSE_REFERENCE_BRACKET_DIAGNOSTIC_FINE.csv`
- `diagnostics/YONGNEUP_N5_KOREA_LAPSE_REFERENCE_BRACKET_DIAGNOSTIC_SUMMARY.csv`

## 9. 회귀시험
- Python compileall PASS
- McKenzie2003 reference contract PASS
- explicit climate downscaling contract PASS
- PFT6 exact Sitch markers PASS
- core geomorph source hash identity vs n3 PASS
