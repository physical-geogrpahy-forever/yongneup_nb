# BIOME4 optLAI to JULES/TRIFFID dry AGB candidate (BDT PFT7 scenario)

Experimental candidate only. Canonical production package is not overwritten.

AGB_dry [kg dry m-2] = LMA*Lbal + 0.75*awl*Lbal^(5/3)/0.5

PFT4 -> BDT: LMA=0.0823, awl=0.78
PFT5 -> NET: LMA=0.2263, awl=0.65
PFT6 -> NET: LMA=0.2263, awl=0.65
PFT7 -> BDT: LMA=0.0823, awl=0.78
PFT10 -> ESH: LMA=0.1515, awl=0.13

Lbal is BIOME4 dominant-PFT optLAI (lai_node). The 0.75 factor is the
Wolf et al. (2011) stem:coarse-root split applied to the integrated woody pool.
fC_wood=0.5 is an explicit dry-mass conversion assumption.
Unsupported vegetated PFTs abort rather than being approximated.
