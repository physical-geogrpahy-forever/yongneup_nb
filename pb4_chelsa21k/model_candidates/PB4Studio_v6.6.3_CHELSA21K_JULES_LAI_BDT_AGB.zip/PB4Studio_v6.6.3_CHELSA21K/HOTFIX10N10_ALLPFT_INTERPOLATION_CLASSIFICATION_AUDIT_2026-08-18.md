# PB4Studio hotfix10n10 — all-PFT + interpolated forcing + reduced-class audit

## Scope

This release starts from hotfix10n9 and changes only the vegetation/climate items agreed in the Yongneup workflow:

1. Restore the native BIOME4 v4.2b2 competition set for the 120 ka production path. The original source still disables PFT1 itself; PB4Studio no longer force-disables PFT2/3/7/9/10/11/12/13. Thus PFT2–13 may compete when their climate constraints pass.
2. Retain the PFT5 reference trial sieve `TCM >= -19 C, GDD5 >= 900`.
3. Retain the PFT6 Sitch-2003 BoNE sieve `-32.5 <= TCM < -2 C, GDD5 >= 600, TWM <= 23 C`.
4. Replace nearest-time climate forcing with linear interpolation between bracketing Beyer ages for monthly temperature, precipitation, cloudiness and annual Tmin. CO2 is interpolated directly at each requested age from the packaged Bereiter-2015 record.
5. Generalize the reduced vegetation classification for all restored PFTs while keeping the existing 51% mixed-forest dominance rule.

No Pelletier geomorphic coefficient, WHC equation, McKenzie/Jackson root parameter, NPP/LAI physiology coefficient, validation threshold, or 100-year validation unit is changed here.

## Reduced classification

Final output/validation codes remain:

- `0`: conifer forest
- `1`: broadleaf forest
- `2`: mixed forest
- `3`: herbaceous/open vegetation
- `4`: truly non-vegetated/bare

PFT groups:

- Broadleaf-tree group: PFT2, PFT3, PFT4
- Conifer/taiga-tree group: PFT5, PFT6, PFT7
- Open group: PFT8, PFT9, PFT10, PFT11, PFT12, PFT13

Native mixed BIOME4 biomes 6/7/9 compare the strongest broadleaf-group potential NPP against the strongest conifer-group potential NPP. Conifer share >= 51% -> code 0; broadleaf share >= 51% -> code 1; otherwise code 2.

Savanna/woodland, grassland, xerophytic shrubland, parkland and tundra biomes are code 3. Native BIOME4 Desert (21) is also code 3 when BIOME4 reports a real PFT and positive NPP or LAI. It is code 4 only if genuinely vegetation-free. BIOME4 Barren (27), Land ice (28), and PB4 exposed-bedrock cells are code 4.

The detailed table is `PFT_REDUCED_CLASSIFICATION_HOTFIX10N10.csv`.

## Contracts run

- Explicit panel-590 temperature downscaling: PASS
- McKenzie2003/Jackson root + SoilGrids AWC contract: PASS
- User-supplied BIOME4 source SHA-256: `23b5194b7b2ca25439f9a97e4f55c147c78ee9198c5f953ca2fac8c4ce689968`
- All-PFT source patch: PASS; no PB4 force-disable statements for PFT2/3/7/9/10/11/12/13
- 22/24 -> 23 ka monthly climate midpoint interpolation: PASS
- Reduced classification edge cases (mixed 51%, vegetated desert, barren, tundra, deciduous taiga): PASS

At 24 ka on the embedded 298-cell Yongneup grid, climate-constraint pass counts were:

`PFT1=0, PFT2=0, PFT3=0, PFT4=0, PFT5=0, PFT6=0, PFT7=298, PFT8=0, PFT9=0, PFT10=296, PFT11=298, PFT12=298, PFT13=298`.

A static LGM smoke test at 26–19 ka produced BIOME4 biome 11 (Deciduous taiga/montane forest) over all 298 cells; at 18 ka the grid contained biome 10 (192 cells) + biome 11 (106 cells). Therefore the former artificial LGM Barren interval caused by the PFT4/5/6/8 scope restriction is removed in this smoke test.

This is not a replacement for the final 120 ka dynamic rerun: restoring PFTs changes vegetation -> NPP/EEMT -> geomorphic feedback, so final accuracy must be recomputed from a fresh full run.
