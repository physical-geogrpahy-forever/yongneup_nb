# hotfix10n5 final audit — Yongneup BIOME4-SD + Pelletier (2026-08-17)

## Stable scope
- Base: `hotfix10n3`, 20 m, `Sc=1.5` geomorph.
- `pelletier_geomorph.py`, `runner.py`, and `boundary.py` are byte-identical to hotfix10n3.
- Therefore the already-audited 20 m / 1 kyr geomorph result is inherited unchanged: no initial/final `S>Sc`, no threshold adjustment, final H about 0.105–3.268 m, no H=0 or H>5 m cells, outlet drift 0, and max H difference about 8.14 mm under tolerance halving.

## PFT6 correction
The hotfix10n3 project-specific PFT6 `TWM<=22 C` setting is replaced with the Sitch et al. (2003) LPJ BoNE bioclimatic limits:
- `-32.5 <= TCM < -2 C`
- `GDD5 >= 600`
- `TWM <= 23 C`

The earlier handoff statement that Sitch BoNE has no TWM ceiling was corrected after rechecking the source table. At 6–3 ka, raw Beyer TWM is 21.859–22.529 C, so the scientifically important change for Yongneup is removal of the obsolete 22 C cutoff; the correct 23 C ceiling does not exclude PFT6 at those test ages.

PFT5 is deliberately unchanged (`TCM >= -8 C`, `GDD5 >= 900`). The earlier handoff already records that the -8 C lower bound has weak individual literature provenance; the `hotfix10n4` -19 C setting remains a separate reference trial rather than being silently promoted into the stable model.

## Soil-depth mechanism
- `mckenzie2003` remains the only scientific variable-depth path.
- McKenzie profile AWC + Jackson-derived finite-depth PFT root accessibility feed BIOME4 hydrology/competition.
- No direct soil-depth NPP/LAI/FVC multiplier or physiology tuning was added.
- `tools/test_mckenzie2003_reference_contract.py`: PASS.

## Climate downscaling safety correction
The inherited code silently inserted `-0.0065 C/m` and substituted basin-mean elevation if no source-grid reference elevation was present. That behavior is removed.
- Raw Beyer extraction: implicit lapse = 0.
- Non-zero lapse requires explicit `reference_elevation_m`.
- Monthly lapse values can be supplied and are applied month by month.
- `tools/test_climate_downscaling_contract.py`: PASS.

This is a numerical/provenance safety fix, not a claim that a final Beyer source-grid reference elevation has been established.

## Raw Beyer fine-depth result after exact Sitch patch
Depth grid: 0.001–0.300 m every 0.001 m, then 0.31–1.50 m every 0.01 m (420 depths per age).

| age | TCM C | TWM C | GDD5 | PFT6 positive | PFT6 optPFT depth | PFT5 positive |
|---:|---:|---:|---:|---:|---|---:|
| 6 ka | -8.808 | 22.529 | 2060.85 | 420/420 | 0.091–0.154 m | 0/420 |
| 5 ka | -8.667 | 22.186 | 2055.75 | 420/420 | 0.104–0.190 m | 0/420 |
| 4 ka | -8.260 | 22.178 | 2092.59 | 420/420 | 0.097–0.136 m | 0/420 |
| 3 ka | -8.909 | 21.859 | 2066.12 | 420/420 | 0.100–0.136 m | 0/420 |

PFT6 NPP/LAI/wetness is numerically identical between the earlier Dallmeyer-style `GDD5=350` trial and this Sitch `GDD5=600` run at 6–3 ka, because local GDD5 is >2000 in all four slices. The old PFT6 zero-result was therefore caused by the 22 C TWM cutoff, not by the 350-vs-600 GDD threshold.

PFT5 remains zero because the retained `TCM>=-8 C` project setting excludes all four raw test climates (TCM roughly -8.26 to -8.91 C). This is now a separate, clearly isolated PFT5 provenance question.

## Korean seasonal-lapse reference-bracket diagnostic (not final forcing)
The previously used 360/500/630 m reference elevations were rerun only as a sensitivity diagnostic using the corrected PFT6 sieve. These are **not** promoted to final reference elevations.
- At 360 m: corrected TCM roughly -14.64 to -15.29 C; PFT6 dominates most depths; PFT4 can be climate-excluded.
- At 500 m: corrected TCM roughly -13.53 to -14.18 C; PFT6 is optPFT over most medium/deep tested soils.
- At 630 m: corrected TCM roughly -12.49 to -13.14 C; the same broad PFT6 dominance persists.

This extreme sensitivity is exactly why a guessed reference elevation must not be embedded in the production model.

## Unresolved before a final elevation-downscaled palaeo sweep
Beyer et al. (2020) is already a 0.5-degree bias-corrected Delta-Method climate product. The recovered point climate table does not contain a scientifically established effective/source-grid elevation for temperature. The previous 360/500/630 m values were brackets only. Therefore a final `T_local = T_Beyer + Gamma*(z_local-z_reference)` run is intentionally not labelled as final until the reference-elevation provenance is established or a better explicitly defined downscaling baseline is chosen.

## Regression status
- Python compileall: PASS
- McKenzie/Jackson contract: PASS
- Explicit climate-downscaling contract: PASS
- PFT6 exact Sitch markers: PASS
- Core geomorph SHA256 identity with n3: PASS
