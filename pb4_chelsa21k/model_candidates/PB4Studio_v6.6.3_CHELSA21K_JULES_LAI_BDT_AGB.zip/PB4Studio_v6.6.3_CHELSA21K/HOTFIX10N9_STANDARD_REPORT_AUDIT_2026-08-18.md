# PB4Studio hotfix10n9 — standard result-board audit

Date: 2026-08-18

## Scope

hotfix10n9 keeps the hotfix10n8 scientific model unchanged and adds an output-only standard result-board module. The requested report layout is generated automatically after a completed static/dynamic comparison run and can also be regenerated later with `MAKE_STANDARD_RESULT_FIGURES.bat`.

## Scientific model unchanged from hotfix10n8

- 590.4 m Beyer panel reference elevation and Korean monthly lapse-rate downscaling
- PFT5 climate sieve: TCM >= -19 C, GDD5 >= 900
- Sitch et al. (2003) BoNE constraints for PFT6
- Yongneup production PFT scope: PFT4, PFT5, PFT6, PFT8 only
- McKenzie/SoilGrids WHC and Jackson/BIOME4 root architecture
- Pelletier geomorphology and S_c = 1.5
- mixed-forest dominance threshold: conifer >=51% or broadleaf >=51%; otherwise mixed forest

No geomorphic, hydrologic, physiological, PFT competition, or validation classification equations were changed for hotfix10n9.

## Standard result figures

A completed comparison run writes these files under `<output_dir>/standard_report/`:

1. `01_soil_depth_maps.png` — dynamic/static/difference at 100, 50, 10, 1 ka
2. `02_mean_soil_depth.png` — mean soil-depth time series
3. `03_vegetation_maps.png` — dynamic/static/match-mismatch at 100, 50, 10, 1 ka
4. `04_vegetation_ratio.png` — vegetation-class area ratios through time
5. `05_paleovegetation_accuracy.png` — current primary palaeovegetation validation accuracy
6. `06_elevation_maps.png` — dynamic/static/difference at 100, 50, 10, 1 ka
7. `07_mean_elevation.png` — mean elevation time series

The 120 ka self-contained runner now saves 50 ka explicitly so the standard report never has to substitute 40 or 60 ka in a fresh hotfix10n9 run.

## Accuracy method — corrected after user review

The example image's 7-record majority score (e.g. 6/7 or 3/7) is **not used**.

The report uses the existing PB4Studio production validation method without modification:

- evaluation unit: palaeovegetation record × 100-year model output time
- temporal matching: every 0.1 kyr output lying inside each palaeovegetation interval
- presence rule: the expected vegetation class must occupy at least 1% of mapped basin vegetation cells
- final accuracy: number of correct output-time evaluations / total output-time evaluations

The per-record breakdown is written only as a diagnostic CSV and is not converted to a majority vote.

Regression with the user's completed hotfix10n8 run produced:

- dynamic: 81 / 86 = 94.186% (94.2% in figure)
- static: 36 / 86 = 41.860% (41.9% in figure)

This matches the established current accuracy calculation.

## Regeneration

- `RUN_YONGNEUP_120KA_SELFCONTAINED.bat`: runs the full self-contained comparison; standard figures are generated automatically after completion.
- `MAKE_STANDARD_RESULT_FIGURES.bat [output_dir]`: regenerates the seven standard figures from an already completed output folder.
- GUI `결과 -> 표준 결과판`: displays/regenerates the same report set.
