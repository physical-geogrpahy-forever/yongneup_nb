# CO2 restoration audit — hotfix10k

- Restores the project-specified atmospheric CO2 forcing: Bereiter et al. (2015) revised Antarctic composite.
- Source file packaged from NOAA/NCEI dataset DOI 10.25921/n8y4-bp27.
- Gas age is calendar yr BP (present = 1950).
- CO2 is linearly interpolated to each BIOME4 ka time slice, matching the documented project method.
- The former silent 280 ppm fallback has been removed from the scientific climate-loading path.
- Pure BIOME4 + Pelletier rollback remains unchanged; soil depth affects vegetation only through native BIOME4 WHC.
- PFT5/PFT6 m80_t22 temperature changes remain the only explicit PFT climate-limit modification.
- The user-supplied basin(1).geojson is not used in the soil-depth sensitivity diagnostic.
