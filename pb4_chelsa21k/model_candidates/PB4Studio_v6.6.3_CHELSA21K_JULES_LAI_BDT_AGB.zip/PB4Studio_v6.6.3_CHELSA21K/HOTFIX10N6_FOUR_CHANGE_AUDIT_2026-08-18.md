# PB4Studio hotfix10n6 — four-change audit (2026-08-18)

Baseline: `hotfix10n5_SITCH2003_BONE_TW23_SC15_20M_STABLE`.

Only the following scientific/validation changes are intended:

1. **Beyer reference elevation**: fixed to **590.4 m** for the Yongneup 128.0–128.5°E, 38.0–38.5°N panel (FABDEM land-only mean). Monthly Korean lapse rates are evaluated on the 15th of each month with `Gamma = -(0.00688 + 0.0015*cos(0.0172*(DOY-60))) C m-1`. Local monthly temperature is `T_local = T_Beyer + Gamma_month*(z_DEM - 590.4)`.
2. **PFT5 climate sieve**: `TCM >= -19 C` and `GDD5 >= 900`; all PFT5 physiology, competition, soil-depth, WHC and root parameters are unchanged.
3. **Conifer-dominant mixed forest**: native BIOME4 mixed biomes 6/7/9 with dominant `optPFT` 5/6 are reduced to project class `conifer_forest` for mapping/validation.
4. **Broadleaf-dominant mixed forest**: native BIOME4 mixed biomes 6/7/9 with dominant `optPFT` 4 are reduced to project class `deciduous_broadleaf_forest` for mapping/validation. Mixed biomes with another/undefined dominant PFT remain `mixed_forest`.

Unchanged by this patch: PFT6 Sitch-2003 BoNE sieve, McKenzie/Jackson root system, SoilGrids/BIOME4 WHC logic, NPP/LAI/FVC equations, competition2, geomorphic equations, SC=1.5, 20 m workflow, validation presence threshold logic, and original BIOME4 native biome output.

## Verification performed

- Python syntax/import contract: PASS.
- Yongneup 6 ka reference check at 1162.08 m: corrected cold-month mean ≈ -13.35 °C and warm-month mean ≈ 19.42 °C: PASS.
- Dominant mixed-forest reduced classes: `biome 7 + optPFT 5/6 -> conifer`, `biome 7 + optPFT 4 -> broadleaf`: PASS.
- McKenzie2003 reference/root contract: PASS; PFT4/5/6 Xi values unchanged.
- Recompiled Fortran source contains PFT5 `TCM >= -19 C, GDD5 >= 900`: PASS.
- Runtime smoke at 4 ka / 1162.08 m: PFT5 NPP positive at 0.05, 0.10, 0.20, 0.50 m soil depth: PASS.
- 101 common baseline files checked byte-for-byte with no unexpected differences (excluding derived build artifacts and the intentionally modified files): PASS.
