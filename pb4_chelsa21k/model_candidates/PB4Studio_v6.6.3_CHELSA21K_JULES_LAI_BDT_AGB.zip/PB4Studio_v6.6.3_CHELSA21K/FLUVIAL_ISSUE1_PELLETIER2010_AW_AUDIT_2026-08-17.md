# Fluvial issue 1 audit — Pelletier (2010) grid-resolution-dependent A/w

Date: 2026-08-17
Scope: **issue 1 only**. Outlet boundary handling (issue 2) and adaptive fluvial timestep (issue 3) are intentionally unchanged.

## Implemented change

The strict fluvial `A/w` path no longer classifies valleys with the legacy fixed `A >= 10,000 m2` threshold and no longer applies the legacy manual cell-size correction. Those fields remain serialization-compatible but are hidden/deprecated and inert in the strict calculation.

The replacement follows the Pelletier (2010) grid-resolution-dependence construction:

1. Run Freeman-style MFD on the native grid (`delta`) with slope exponent `p=1.1`.
2. Bilinearly interpolate the same cell-centred DEM to `delta/2` and run the same MFD.
3. Return the fine-grid result to the native grid with the maximum contributing area in each 2x2 fine-cell block.
4. Compute `f = A_delta / A_delta/2(max)`.
5. Classify `f < 1.2` as valley and `f >= 1.2` as hillslope.
6. Use `w = delta` on hillslopes and `w = 0.005 * A^0.5` in valleys, then pass `A/w` to the existing fluvial Eq. 16 path.

The existing D8 routing remains in place for receiver slope. This is deliberate because changing receiver/outlet slope belongs to issue 2.

## Tests

### Synthetic planar slope

- median f: 2.00002849
- 5th percentile f: 1.99992346
- 95th percentile f: 2.02160001
- core cells classified as valley: 0

### Yongneup DEM

- shape: 40 x 46
- valid cells: 1105
- cell width: 9.98917609 m
- legacy fixed-1-ha valley cells: 63
- Pelletier-2010 classifier valley cells: 359
- overlap: 28
- legacy-only: 35
- new-only: 331

These counts are an implementation diagnostic only; they are not a claim about real-world channel extent.

### MFD area conservation

Native grid:
- total active-cell area: 110260.92098032653 m2
- exported through open boundary: 110260.92098032648 m2
- absolute residual: 4.37e-11 m2

Half-cell grid:
- total active-cell area: 110260.92098032653 m2
- exported through open boundary: 110260.92098032651 m2
- absolute residual: 1.46e-11 m2

### Legacy-control ablation

Two configurations were compared with deliberately extreme legacy values:
- `valley_area_threshold_m2 = 1` vs `1e12`
- manual cell-size correction disabled vs enabled
- reference cell size `1` vs `1000`

Maximum numerical difference in new `A/w`, `A_delta`, `A_half`, and `f`: **0.0**. Valley masks were identical.

### Regression/smoke tests

- all Python files compile: PASS
- existing `test_mckenzie2003_reference_contract.py`: PASS
- `update_pelletier_strict()` end-to-end synthetic smoke test: PASS
- `runner.py` is byte-identical to hotfix10l baseline: issue 3 unchanged
- outlet `slope_local -> slope_to_receiver` fallback remains: issue 2 unchanged

## Reproduction

Run:

```bash
python tools/test_pelletier2010_grid_dependence.py \
  --dem /path/to/dem_clip.tif \
  --outlet /path/to/yongneup_outlet.shp \
  --json diagnostics/pelletier2010_grid_dependence_audit.json \
  --csv diagnostics/pelletier2010_yongneup_cell_diagnostic.csv
```

## Reference scope

- Pelletier, J. D. (2010), *Minimizing the grid-resolution dependence of flow-routing algorithms for geomorphic applications*, Geomorphology 122, 91–98, DOI: 10.1016/j.geomorph.2010.06.001.
- Freeman, T. G. (1991), MFD flow partitioning; exponent 1.1 used by the reference workflow.
- Pelletier et al. (2013) uses the grid-resolution-dependence distinction between hillslopes and valleys in the fluvial-width calculation.

No erosion cap, K0 tuning, EEMT tuning, F tuning, DEM smoothing, or minimum-soil-depth floor was added.
