# PFT6 Sitch et al. (2003) BoNE climate-sieve audit — 2026-08-17

## Decision
- Base package: hotfix10n3 20 m / Sc=1.5 stable geomorph.
- PFT6 only: replace the obsolete project `TWM <= 22 C` relaxation with Sitch et al. (2003) BoNE limits.
- Active PFT6 limits: `-32.5 <= TCM < -2 C`, `GDD5 >= 600`, TWM upper limit 23 C.
- PFT5 `TCM >= -8 C, GDD5 >= 900` is retained unchanged from hotfix10n3 and is **not** re-justified by this patch.
- No NPP/LAI/FVC depth multiplier, physiology tuning, temperature forcing offset, or geomorph change.

## Source recheck correction
The previous handoff recorded Sitch (2003) BoNE as having no warmest-month ceiling. A source-table recheck found that Sitch et al. (2003) uses a **23 C warmest-month upper limit** for BoNE. This release therefore uses 23 C, not an unlimited TWM. For the Yongneup 6–3 ka test slices the largest raw Beyer TWM is about 22.529 C, so this source-fidelity correction does not alter the new PFT6 fine-depth result relative to a no-ceiling trial; it only removes the obsolete project-specific 22 C cutoff.

## Reference distinction
Sitch et al. (2003) LPJ uses BoNE GDD5=600. Dallmeyer et al. (2017) used a modified Asia/Holocene BIOME4 setup with GDD5=350 (500 under their high-orography option). The latter remains a separate reference trial and does not override the user's recorded Sitch-2003 final choice.

## Required regression
1. Generated Fortran PFT6 row must contain `TCM=-32.5..-2 C`, `GDD5=600`, and `TWM<=23 C`.
2. McKenzie2003 reference contract must pass.
3. 20 m / Sc=1.5 hillslope regression must remain unchanged.
4. 6/5/4/3 ka fine-depth PFT4/5/6 response must be rerun before interpreting earlier TWM-limited sweeps.


## Climate downscaling safety correction

The inherited climate path silently used a generic -0.0065 C m-1 lapse rate and substituted the basin mean elevation whenever the Beyer table lacked a source-grid reference elevation. That behavior is disabled in this release. Raw Beyer forcing now has zero implicit lapse. A non-zero lapse requires an explicit `reference_elevation_m`, and monthly `lapse_rate_C_per_m` values are applied month by month. This does not choose a final Yongneup source-grid reference elevation; it prevents an arbitrary value from being silently substituted while that provenance remains unresolved.
