PB4Studio hotfix10n10

핵심 변경
1) 원본 BIOME4 활성 PFT 전체(PFT2-13) 경쟁 복원. PFT1은 원본 v4.2b2 자체가 비활성화.
2) PFT5: TCM >= -19 C, GDD5 >= 900 유지.
3) PFT6: Sitch-2003 BoNE (-32.5 <= TCM < -2 C, GDD5 >= 600, TWM <= 23 C) 유지.
4) Beyer 기후 forcing: 가장 가까운 시점 선택 대신 시간 선형보간.
5) 전체 PFT를 5개 출력/검증 식생군으로 재분류. mixed forest의 51% 규칙 유지.

실행
- START_PB4Studio.bat : GUI
- CHECK_HOTFIX10N10_SELFCONTAINED.bat : 핵심 contract 검사
- RUN_YONGNEUP_120KA_SELFCONTAINED.bat : 내장 입력으로 120 ka 정적/동적 비교
- MAKE_STANDARD_RESULT_FIGURES.bat : 표준 7개 결과 그림 재생성

결과 기본 폴더
outputs_hotfix10n10_selfcontained

상세 변경사항
HOTFIX10N10_ALLPFT_INTERPOLATION_CLASSIFICATION_AUDIT_2026-08-18.md
PFT_REDUCED_CLASSIFICATION_HOTFIX10N10.csv


[STANDARD REPORT LAYOUT FIX]
This package includes layoutfix1 for the seven standard-report figures. Scientific-model and validation calculations are unchanged. Map colorbars use dedicated far-right axes; map columns and legends use fixed non-overlapping report margins.
