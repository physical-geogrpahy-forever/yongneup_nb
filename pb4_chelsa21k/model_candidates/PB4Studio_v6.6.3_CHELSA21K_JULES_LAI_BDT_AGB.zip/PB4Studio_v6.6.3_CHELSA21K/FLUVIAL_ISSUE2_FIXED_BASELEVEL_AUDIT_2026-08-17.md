# Fluvial issue 2 audit — fixed base-level outlet (2026-08-17)

## Scope

This patch starts from `hotfix10m1_FLUVIAL_VALLEY_REFERENCE_ONLY` and changes only issue 2:

- remove the substitution of local 2-D slope for `slope_to_receiver` at open outlet cells;
- treat every open geomorphic boundary cell as a fixed base-level (Dirichlet) state for `z`, `b`, and `h`;
- retain the real D8 receiver slopes of interior cells that drain into the outlet;
- do not change the Pelletier-2010 A/w classifier from issue 1;
- do not change `runner.py` or the adaptive timestep logic (issue 3 remains untouched).

## Code change

### `pb4studio/pelletier_geomorph.py`

Old behavior after D8 routing:

```python
slope_local, _ = local_slope_and_costheta(z, dx_m, land)
for (r, c) in valid_open:
    slope_to_receiver[r, c] = max(float(slope_local[r, c]), 0.0)
```

This was removed. Open cells have no in-domain receiver, so their initialized `slope_to_receiver = 0` is retained. Interior cells immediately upstream still use the D8 slope to the outlet cell.

`update_pelletier_strict()` now builds `fixed_baselevel_mask` from `boundary_cfg.all_open_cells()`. After the unconstrained trial process calculation, it records the trial changes and restores the boundary state exactly:

```python
h_new = np.where(fixed_baselevel_mask, h, h_new)
b_new = np.where(fixed_baselevel_mask, b, b_new)
z_new = np.where(fixed_baselevel_mask, z_state, z_new)
```

This is a boundary-condition reset, not an erosion-rate cap. Interior coefficients and process rates are not rescaled.

### `pb4studio/boundary.py`

Only the documentation of `open_free` and `open_fixed_slope` semantics was updated. Their difference still controls the routing surface; both are fixed-base-level cells for geomorphic state.

## Yongneup direct diagnostic

Initial 6 ka outlet cell: `(row=5, col=33)`.

Before (hotfix10m1):

- outlet D8 contributing area = 110260.92098032651 m2
- outlet slope_flow = 0.1319163870627711
- outlet fluvial regolith erosion in 0.1 kyr = 0.038926346509967506 m

After (hotfix10m2):

- outlet D8 contributing area = 110260.92098032651 m2 (unchanged)
- outlet slope_flow = 0.0
- outlet fluvial regolith erosion = 0.0
- outlet fluvial bedrock erosion = 0.0

Five interior cells still route directly to the outlet. Their slopes remain:

- 0.046109892804801086
- 0.07594669623109232
- 0.07867792563362708
- 0.10787823130323904
- 0.1376097335117362

Thus the patch removes only the outlet's artificial local-slope erosion; it does not suppress the real upstream-to-outlet receiver slopes.

## One-step isolation test

Starting from the identical float32 6 ka geomorphic state and integrating 0.1 kyr once, the m1-vs-m2 differences outside the outlet are exactly zero for:

- z
- b
- h
- slope_flow
- fluvial regolith erosion
- fluvial bedrock erosion

Only the single outlet cell changes between m1 and m2.

## Repeated boundary-state test

Ten consecutive 0.01 kyr updates (total 0.1 kyr) give:

- max |outlet z drift| = 0.0 m
- max |outlet b drift| = 0.0 m
- max |outlet h drift| = 0.0 m
- max outlet fluvial regolith erosion per step = 0.0 m
- max outlet fluvial bedrock erosion per step = 0.0 m

## Issue-1 regression

The Pelletier-2010 A/w test was rerun after the issue-2 patch. The results are unchanged from hotfix10m1:

- synthetic planar median f = 2.0000284923753515
- Yongneup Pelletier-2010 valley cells = 359
- native MFD mass-balance error = 4.3655745685100555e-11 m2
- half-resolution MFD mass-balance error = 1.4551915228366852e-11 m2

Direct array comparison of issue-1 quantities from identical input gives zero difference in A/w, native MFD A, f, and valley mask.

## Issue-3 isolation

`pb4studio/runner.py` SHA256 is identical between hotfix10m1 and hotfix10m2:

`b1e11200d8f4fc7caa906ef704f2bbc680ba06ee99f863f47d38b4e03206bd1a`

Therefore adaptive fluvial timestep behavior has not been changed in this patch.

## Regression checks

- all 27 Python files compile: PASS
- BIOME4-SD McKenzie2003 strict-reference contract: PASS
- issue-1 Pelletier-2010 grid-dependence diagnostic: PASS / numerically unchanged
- issue-2 outlet direct diagnostic: PASS
- issue-2 repeated fixed-base-level state test: PASS

## Remaining issue

Issue 3 remains intentionally unresolved in this package: the adaptive runner still constrains timestep from the hillslope stability estimate and finite/non-negative state checks, but does not yet enforce a fluvial erosion/deposition convergence criterion.
