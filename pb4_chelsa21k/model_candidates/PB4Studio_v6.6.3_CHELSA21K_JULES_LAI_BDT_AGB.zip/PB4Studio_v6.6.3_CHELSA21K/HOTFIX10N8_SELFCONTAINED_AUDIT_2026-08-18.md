# PB4Studio hotfix10n8 self-contained audit — 2026-08-18

## Basis
- Parent package: `PB4Studio_v6.6.3-corrected_FINAL_hotfix10n7_PANEL590_PFT5REF_MIXBAND51`
- Production vegetation path: BIOME4-SD `mckenzie2003`
- Time configuration intended for Yongneup production check: 120.0 → 0.0 ka BP, 0.1 kyr interval.
- Mixed-forest validation rule retained from hotfix10n7: conifer share >= 51% → conifer forest; broadleaf share >= 51% → broadleaf forest; otherwise native mixed forest remains mixed.

## User-reprovided BIOME4 source
The file uploaded on 2026-08-18 as `biome4(1).f` was copied to:
`fortran_src/biome4_original_4_2b2.f`.

SHA-256:
`23b5194b7b2ca25439f9a97e4f55c147c78ee9198c5f953ca2fac8c4ce689968`

This hash is byte-for-byte identical to the BIOME4 original source already present in hotfix10n7. Therefore the original source had not been corrupted or replaced.

## Scientific change in hotfix10n8
The missing Yongneup production PFT scope is now implemented in the compiled `mckenzie2003` path.
After the native BIOME4 `constraints()` sieve and the original `pfts(1)=0` rule, the following out-of-scope PFTs are disabled before NPP optimization and `competition2()`:

- disabled: PFT 2, 3, 7, 9, 10, 11, 12, 13
- retained for Yongneup production competition: **PFT 4, 5, 6, 8**

The `original` comparison variant does not receive this production-scope restriction.
No new NPP, LAI, FVC, WHC, root, fire, or competition coefficient was introduced.

## Unchanged scientific rules
- Beyer/FABDEM reference elevation: 590.4 m
- Korean monthly lapse-rate correction
- PFT5 climate sieve: TCM >= -19 C and GDD5 >= 900
- PFT6 Sitch et al. (2003) BoNE sieve including TWM <= 23 C
- McKenzie 2003 AWC / actual-soil-depth integration
- Jackson/BIOME4 PFT root fractions and derived Xi
- BIOME4 0–30 cm / 30–150 cm hydrological structure
- Pelletier geomorphic process code and S_c = 1.5
- 1% basin-presence validation threshold
- 51% symmetric mixed-forest dominance threshold

## Self-contained model inputs
The exact archived Yongneup production grid is in:
`embedded_inputs/yongneup_exact20m/`

It contains:
- `dem_20m_exact.tif`
- `soil_depth_20m_exact_m.tif`
- `soil_texture_20m_exact.tif`
- `basin_exact20m.geojson`
- `outlet_open_free_exact20m.geojson`
- `climate_yongneup_128.25E_38.25N.csv`
- `yongneup_initial_grid_20m_exact.npz`
- `PB4STUDIO_EXACT_GRID.json`

Exact-grid contract:
- shape: 20 x 23
- active cells: 298
- geomorphic model resolution: 20.0 m
- archived raster x pixel spacing: 19.9783521739 m
- archived raster y pixel spacing: 19.9740400000 m
- initial mean soil depth: 1.9403876763 m
- outlet cell: row 2, col 16
- CRS: EPSG:5187

The slight difference between raster pixel spacing and the geomorphic 20.0 m model resolution is retained intentionally because that is how the validated production state was constructed.

The older reconstructed 10 m inputs are also retained under `embedded_inputs/yongneup/` for provenance, but the exact 20 m folder above is the production reproduction path.

## Self-contained execution
- GUI: `START_PB4Studio.bat` starts with the exact embedded Yongneup inputs prefilled.
- Exact headless 120 ka comparison run: `RUN_YONGNEUP_120KA_SELFCONTAINED.bat`
- Quick integrity/Fortran PFT-scope check: `CHECK_HOTFIX10N8_SELFCONTAINED.bat`

The package contains all **model input data** needed for the Yongneup run. Python packages and a 64-bit `gfortran` compiler remain runtime dependencies and are not vendored; `FIRST_RUN_SETUP.bat` installs the Python dependencies.

## Contract tests performed before packaging
1. Exact embedded grid loads as 20 x 23 / 298 active cells.
2. Mean initial soil depth reproduces 1.940388 m.
3. Embedded climate CSV covers 0–120 ka BP.
4. User-reprovided BIOME4 original source SHA matches the archived source exactly.
5. Compiled McKenzie2003 production path at 4 ka reports constraint-pass counts:
   - PFT4 = 298
   - PFT5 = 298
   - PFT6 = 298
   - PFT8 = 298
   - every out-of-scope PFT = 0
6. Climate-downscaling contract: PASS.
7. McKenzie/Jackson reference contract: PASS.
8. Symmetric 51% mixed-forest classifier: PASS.

## 92_02 diagnostic status
The previous hotfix10n7 counterfactual using the same dynamic state showed that restricting competition to PFT4/5/6/8 restores PFT8 to >=1% of the basin at all five 92_02 output ages (2.7–2.3 ka), i.e. diagnostic 0/5 → 5/5.
This is included only as a diagnostic in `diagnostics/hotfix10n8_pft_scope/`.
Because changing PFT competition changes NPP/EEMT and therefore long-term geomorphic feedback, the final hotfix10n8 accuracy must be obtained from a fresh 120 ka run rather than by reusing the hotfix10n7 trajectory.
