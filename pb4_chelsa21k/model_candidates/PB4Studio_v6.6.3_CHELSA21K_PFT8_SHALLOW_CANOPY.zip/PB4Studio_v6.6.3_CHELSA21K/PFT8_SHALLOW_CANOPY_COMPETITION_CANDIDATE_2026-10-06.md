# PFT8 shallow-canopy competition candidate

Status: experimental candidate, not canonical.

Change:
Within the original BIOME4 competition2 branch for wdom=7
(boreal deciduous tree), select PFT8 temperate grass when
grasspft=8 and woody LAI < 3.0.

The LAI=3.0 threshold is not fitted to Park et al. (2021).
It reuses a tree-grass competition threshold already present
in the original BIOME4 PFT4 branch. No climate limits, NPP,
LAI, McKenzie/Jackson hydrology, AGB*, or Pelletier coefficients
are changed.
