# PB4Studio CHELSA21K final integrated model

Status: FINAL production science configuration.

Core:
- BIOME4 v4.2b2 native PFT climate limits
- McKenzie soil-depth/AWC coupling
- finite-depth PFT root accessibility
- 51% reduced-class rule for Jang validation
- dynamic Pelletier geomorphic coupling

Final vegetation biomass proxy:
AGB*_dry,p = LAI_p [ S_p + 0.03630780547701014 L_m,p^0.43 ]

The leaf term follows Reich et al. (1992) SLA-life-span regression.
The sapwood relation follows Haxeltine & Prentice (1996) Eq. 34,
with BIOME4 v4.2b2 stemcarbon=0.5 and explicit fC=0.50 dry-mass conversion.

Final hillslope coupling:
kd = 0.033 EEMT + 0.05 AGB*

Pelletier et al. (2013) direct exponential EEMT-to-AGB Eq. (5)
is not used for Yongneup.

Primary validation:
Jang et al. (2011), corrected reduced mapping, n=62,
1% basin-presence criterion.

Park et al. (2021):
independent holdout validation only. It is not included in the Jang
62-item score and is not used to retune model parameters.
Sample-level Supplementary pollen data are required for that evaluation.
