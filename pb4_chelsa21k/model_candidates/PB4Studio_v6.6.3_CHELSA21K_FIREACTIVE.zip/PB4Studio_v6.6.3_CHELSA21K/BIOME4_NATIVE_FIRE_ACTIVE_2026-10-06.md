# BIOME4 native fire activation/audit

Base canonical ZIP SHA-256: 4b7be121d6d427a5378eb1aab491781f20a1557ee7d646acbef512d230356fd8

The native BIOME4 v4.2b2 fire calculation was already present and active in the
science core. This candidate does not retune or replace it. It makes the native
fire diagnostics visible in normal PB4 outputs so the late-Holocene fire signal
can be audited directly against CHELSA-TraCE21k forcing and Park et al. (2021).

Unchanged native science:
- PFT-dependent soil-moisture fire thresholds in subroutine fire
- NPP scaling of potential fire days
- competition2 fire rules, including PFT6 firedays > 90 d
- all current PB4-McKenzie-nativeClimate and BIOME4-derived AGB* coupling

New diagnostics only:
- summary_timeseries.csv: mean/max dominant firedays and PFT01-PFT13 firedays
- snapshots/cell_values: firedays, pft06_firedays, pft07_firedays

No climate values, fire thresholds, PFT climate limits, NPP equations, AGB*
equations, or geomorphic parameters are changed by this diagnostic candidate.
