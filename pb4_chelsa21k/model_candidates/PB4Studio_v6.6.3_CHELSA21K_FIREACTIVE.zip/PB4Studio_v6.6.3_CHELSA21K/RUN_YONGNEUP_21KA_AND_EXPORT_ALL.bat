@echo off
setlocal
cd /d %~dp0
echo [1/2] Running PB4 Yongneup 21 ka, all 211 time steps...
python tools\run_yongneup_21ka_chelsa_selfcontained.py
if errorlevel 1 goto :fail
echo [2/2] Exporting Excel, CSV and figures...
python tools\export_all_outputs.py --root . --outputs outputs_CHELSA21K
if errorlevel 1 goto :fail
echo DONE. See outputs_CHELSA21K\FULL_EXPORT
pause
exit /b 0
:fail
echo FAILED. Check the console output.
pause
exit /b 1
