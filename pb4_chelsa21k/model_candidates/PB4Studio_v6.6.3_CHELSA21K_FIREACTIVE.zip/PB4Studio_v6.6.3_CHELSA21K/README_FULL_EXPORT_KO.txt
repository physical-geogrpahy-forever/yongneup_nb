PB4Studio CHELSA21K U008 CLEAN FULL EXPORT
=============================================

버전
- 6.6.3-CHELSA21K-FINAL-nativeClimate-BIOME4AGB-U008
- regional uplift U = 0.08 m/kyr

실행
1. FIRST_RUN_SETUP.bat 최초 1회
2. START_PB4Studio.bat: GUI
3. RUN_YONGNEUP_21KA_AND_EXPORT_ALL.bat: 21 ka 전체 실행 및 전체 출력

시간축
- 21.0 ka BP에서 시작
- 0.0 ka BP까지
- 0.1 kyr 간격
- 총 211 시점

고도, 토심, NPP 시계열 그림
- pb4_chelsa21k/plots/plot_chelsa_climate.py와 동일한 시각 형식
- figsize 8.2 x 4.8
- x축 21 -> 0 ka BP
- x 눈금 21, 18, 15, 12, 9, 6, 3, 0
- 동적모델 firebrick, linewidth 1.6
- 정적모델 royalblue, linewidth 1.4
- 제목 없음, grid 없음, 범례 좌상단 frame 없음
- PNG 600 dpi
- 고도 matplotlib offset 표기 비활성화

불필요한 과거 audit, diagnostics, reference output, bytecode, 테스트 스크립트는 배포 ZIP에서 제거합니다.
