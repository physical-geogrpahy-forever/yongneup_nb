# -*- coding: utf-8 -*-
"""PB4Studio engine layer (GUI-independent, CLI-compatible)."""

__version__ = '6.6.3-CHELSA21K-FINAL-nativeClimate-BIOME4AGB-U008-FIREWRN'
