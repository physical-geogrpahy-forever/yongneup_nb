# Final uplift setting

- Production uplift: U = 0.08 m kyr^-1 = 80 mm kyr^-1.
- Lee et al. (2024), Earth Surface Dynamics 12, 1091-1120, used 80 mm kyr^-1 as a regional uplift forcing chosen to equal the ca. 22 Ma-to-present Taebaek Mountain exhumation rate.
- This is a regional model forcing, not a direct Yongneup uplift measurement.
- Previous canonical U=0.20 m kyr^-1 is archived for provenance.
