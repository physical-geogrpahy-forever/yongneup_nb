from pathlib import Path
import csv, sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
import pb4studio
from pb4studio.pelletier_geomorph import PelletierStrictConfig
from pb4studio.standard_report import REPORT_AGES_KA
EXPECTED='6.6.3-CHELSA21K-FINAL-nativeClimate-BIOME4AGB-U008-FIREWRN-EEMT0-FAB30'
assert pb4studio.__version__ == EXPECTED, (pb4studio.__version__, EXPECTED)
assert abs(PelletierStrictConfig().uplift_m_per_kyr-0.08)<1e-15
assert abs(PelletierStrictConfig().hillslope_critical_slope-0.70)<1e-15
assert tuple(REPORT_AGES_KA)==(21.0,10.0,5.0,0.0), REPORT_AGES_KA
p=ROOT/'pb4studio/embedded_data/yongneup_jang2011_primary_validation.csv'
rows=list(csv.DictReader(p.open(encoding='utf-8-sig')))
assert [r['record_id'] for r in rows]==['95_01','95_02','95_03','95_04']
assert [int(float(r['expected_vegetation_code'])) for r in rows]==[1,2,1,2]
assert not any(str(r['record_id']).startswith('92_') for r in rows)
runner=(ROOT/'pb4studio/runner.py').read_text(encoding='utf-8')
assert 'yongneup_jang2011_primary_validation.csv' in runner
backend=(ROOT/'pb4studio/biome4_backend.py').read_text(encoding='utf-8')
assert 'wr_n=wr/max(rtop_eff+rbot_eff,1.0e-6)' in backend
assert '"       wet(d)=wr_n\\n"' in backend
clim=(ROOT/'pb4studio/climate.py').read_text(encoding='utf-8')
assert 'dT = np.maximum(np.asarray(temp_monthly_C, dtype="float64"), 0.0)' in clim
assert 'peff_mm = np.maximum(np.asarray(prec_monthly_mm, dtype="float64") - aet_monthly, 0.0)' in clim
import json as _json
_m=_json.loads((ROOT/'embedded_inputs/yongneup_exact20m/PB4STUDIO_EXACT_GRID.json').read_text(encoding='utf-8'))
assert abs(float(_m['model_resolution_m'])-30.0)<1e-9 and int(_m['active_cells'])==656, (_m['model_resolution_m'],_m['active_cells'])
fig=(ROOT/'pb4studio/figures.py').read_text(encoding='utf-8')
for token in ['set_xlim(21, 0)','color="firebrick", linewidth=1.6','color="royalblue", linewidth=1.4','frameon=False']:
    assert token in fig, token
for target in ['tools/run_yongneup_21ka_chelsa_selfcontained.py','tools/export_all_outputs.py','tools/make_standard_result_figures.py']:
    assert (ROOT/target).is_file(), target
print('PASS PB4 PACKAGE CONTRACT')
print('VERSION',EXPECTED)
print('FIRE_WETNESS','wet(d)=wr_n (root weights normalized to sum 1)')
print('EEMT','monthly; EPPT uses max(T,0) and max(P-AET,0)')
print('GRID','FABDEM V1-2 30 m, 656 cells')
print('PRIMARY_VALIDATION','Jang2011 corrected mapping n=62; Park2021 excluded')
print('REPORT_AGES_KA',REPORT_AGES_KA)
