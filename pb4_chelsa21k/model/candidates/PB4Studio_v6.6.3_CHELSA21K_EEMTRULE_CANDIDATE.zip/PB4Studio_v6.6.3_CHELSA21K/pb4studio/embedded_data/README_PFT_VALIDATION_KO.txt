PB4 보조 검증: 유역 PFT 출현/비출현 (Park et al. 2021)
=====================================================
주 검증(Jang et al. 2011, 활엽수림/혼효림 범주, 62 평가)과 별개이며 주 점수에 합치지 않는다.

관측 자료
- yongneup_park2021_ync_pollen_counts.csv : Park et al. (2021) 보충자료 mmc1 시트 1(계수)을 긴 형식으로 옮긴 것.
  YN-C 코어, 72 시료, 3181–515 cal BP. https://doi.org/10.1016/j.palaeo.2021.110705
- pft_taxon_map_yongneup.csv : 분류군 -> PFT 그룹 배정. 근거는 basis 열.
  EXCLUDE_LOCAL(Alnus, 산형과, 오이풀, 터리풀)과 EXCLUDE_NONTERRESTRIAL(수생, 사초과, 포자)은 육상 화분 합에서 뺀다.
  UNSCORED_PINUS: 아속 미분류 Pinus. 합에는 넣되 채점하지 않는다.
- pft_groups_yongneup.csv : 그룹별 BIOME4 PFT, 관측 출현 문턱(%), 채점 여부.
  TBE(PFT3)와 DWD(PFT10) 5% 문턱은 이 기록의 원거리 유입 상한(최대 약 4%)보다 높게 잡은 잠정값이다.
  같은 자료로 문턱을 정했으므로 독립 근거(현생 표층 화분 등)로 다시 정해야 한다.

모델 출현 정의 (ScienceConfig.pft_presence_method)
- optpft    : BIOME4 선택 PFT
- top2_npp  : NPP 1, 2위 PFT 중 NPP > 0
- potential : 기후 제약 통과 및 NPP > 0. BIOME4 원본의 present(pft) = optnpp(pft) > 0 과 같다.
유역(나지 제외)에서 그룹 PFT 셀 수 >= pft_presence_min_cells 이면 출현.
pft_groups_yongneup.csv의 model_method 열이 채워진 그룹은 그 정의를 쓴다.
기본값: 침엽수(CON)만 potential. BIOME4는 optpft=4 이고 present(6)이면 cool mixed forest(7)로 배정하므로,
optpft만 세면 혼효림 안의 침엽수가 빠진다. 민감도표(pft_validation_sensitivity.csv)는 그룹별 지정을 무시하고
세 정의를 모든 그룹에 똑같이 적용한다.

화분 시료 깊이 범위: pft_obs_depth_min_cm, pft_obs_depth_max_cm (기본 전체, 기존 holdout과 맞추려면 16, 69).

시간 대응
- 출력시점 t마다 [t - dt/2, t + dt/2) 화분 시료의 계수를 합산해 백분율을 계산한다.
- pft_validation_min_age_ka 보다 젊은 출력시점은 제외한다.

출력 (결과 폴더)
- pft_model_cells_per_output_time.csv : 출력시점별 PFT 1–13 셀 수 (세 정의)
- pft_validation_per_output_time.csv  : 출력시점 x 그룹 TP/FP/FN/TN
- pft_validation_summary.csv          : 그룹별 민감도, 특이도, TSS
- pft_validation_sensitivity.csv      : 세 정의 x 문턱(그룹 기본, 0.5/1/2/5/10%) 민감도표
출력시점은 독립 관측이 아니다. 인접 시점은 같은 화분 시료를 공유할 수 있다.

같이 바뀐 점 (validation.py)
- basin_presence_min_fraction = 0 은 "유역에 한 셀이라도 등장"으로 해석한다.
  이전에는 >= 0 비교 때문에 관측 유형이 없어도 일치로 셌다.
- compute_accuracy_sensitivity_table 기본 문턱: 0, 1, 5, 10, 25, 50%.
