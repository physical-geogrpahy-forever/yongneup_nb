# -*- coding: utf-8 -*-
"""
pft_validation.py — 유역 단위 PFT 출현/비출현 보조 검증.

관측: Park et al. (2021) YN-C 코어 화분 계수 자료(용늪, 3181–515 cal BP).
  1. 육상 화분 합 = Park group A(목본) + B(초본), 단 국지 습원 분류군(EXCLUDE_LOCAL) 제외.
  2. 분류군을 PFT 그룹에 배정한다(pft_taxon_map_yongneup.csv).
  3. 모델 출력시점 t마다 [t - dt/2, t + dt/2) 안의 시료 계수를 합산해 그룹 백분율을 구한다.
  4. 그룹 백분율 >= 그룹별 문턱(pft_groups_yongneup.csv)이면 관측 출현.

모델: BIOME4 출력의 셀별 PFT를 유역(나지 제외) 안에서 센다. 그룹에 속한 PFT가
  min_cells 셀 이상에 나타나면 모델 출현. 출현 정의(method)는 세 가지다.
    optpft    : BIOME4가 선택한 PFT(optpft)
    top2_npp  : NPP 기준 1, 2위 PFT 중 NPP > 0인 것
    potential : 기후 제약 통과(constraint_pass) 이면서 NPP > 0.
                BIOME4 v4.2b2의 present(pft) = optnpp(pft) > 0 과 같다(원본 409–417행).
                원본은 present(12)를 항상 참으로 두지만 PFT12는 채점 그룹에 없다.
                바이옴 규칙도 이 값을 쓴다: optpft=4 이고 present(6)이면 cool mixed forest(7).
  그룹별로 pft_groups_yongneup.csv의 model_method 열을 채우면 그 그룹만 다른 정의를 쓴다.
  기본 설정에서 침엽수(CON)는 potential을 쓴다. optpft로는 cool mixed forest 안의 PFT6가 잡히지 않기 때문이다.

평가: 출력시점 x PFT 그룹마다 TP/FP/FN/TN을 매기고 민감도, 특이도, TSS를 낸다.
출력시점은 서로 독립된 관측이 아니다(인접 시점이 같은 화분 시료를 공유할 수 있다).
이 검증은 Jang (2011) 범주형 주 검증과 별개의 보조 검증이며 주 점수에 합치지 않는다.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Optional

import numpy as np
import pandas as pd

EMBEDDED = Path(__file__).resolve().parent / "embedded_data"
DEFAULT_COUNTS = EMBEDDED / "yongneup_park2021_ync_pollen_counts.csv"
DEFAULT_TAXON_MAP = EMBEDDED / "pft_taxon_map_yongneup.csv"
DEFAULT_GROUPS = EMBEDDED / "pft_groups_yongneup.csv"

PRESENCE_METHODS = ("optpft", "top2_npp", "potential")
SWEEP_THRESHOLDS_PCT = (0.5, 1.0, 2.0, 5.0, 10.0)


# ---------------------------------------------------------------- observations
def load_observations(
    counts_csv: Path = DEFAULT_COUNTS,
    taxon_map_csv: Path = DEFAULT_TAXON_MAP,
    groups_csv: Path = DEFAULT_GROUPS,
    depth_min_cm: Optional[float] = None,
    depth_max_cm: Optional[float] = None,
) -> Dict[str, object]:
    """Load pollen counts, taxon->group map and group table.

    depth_min_cm/depth_max_cm (inclusive) restrict the samples, e.g. 16-69 cm to match
    the existing Park (2021) holdout's main quantitative interval.
    """
    counts = pd.read_csv(counts_csv, encoding="utf-8-sig")
    dep = counts["depth_cm"].astype(float)
    if depth_min_cm is not None:
        counts = counts[dep >= float(depth_min_cm)]
        dep = counts["depth_cm"].astype(float)
    if depth_max_cm is not None:
        counts = counts[dep <= float(depth_max_cm)]
    if counts.empty:
        raise ValueError("no pollen samples left after the depth restriction")
    tmap = pd.read_csv(taxon_map_csv, encoding="utf-8-sig")
    groups = pd.read_csv(groups_csv, encoding="utf-8-sig")
    missing = sorted(set(counts["taxon_code"]) - set(tmap["taxon_code"]))
    if missing:
        raise ValueError(f"taxa without a pft_group entry in {taxon_map_csv.name}: {missing}")
    groups["biome4_pfts"] = groups["biome4_pfts"].astype(str).map(
        lambda s: tuple(int(float(v)) for v in s.replace(",", ";").split(";") if v.strip())
    )
    groups["scored"] = groups["scored"].astype(int).astype(bool)
    if "model_method" not in groups.columns:
        groups["model_method"] = ""
    groups["model_method"] = groups["model_method"].fillna("").astype(str).str.strip()
    bad = sorted(set(groups["model_method"]) - set(PRESENCE_METHODS) - {""})
    if bad:
        raise ValueError(f"unknown model_method in {groups_csv.name}: {bad}")
    df = counts.merge(tmap[["taxon_code", "pft_group"]], on="taxon_code", how="left")
    in_sum = df["park2021_group"].isin(["A", "B"]) & ~df["pft_group"].isin(
        ["EXCLUDE_LOCAL", "EXCLUDE_NONTERRESTRIAL"]
    )
    df["in_terrestrial_sum"] = in_sum
    return {"counts": df, "groups": groups}


def observed_group_percent_for_window(obs: Dict[str, object], t_lo_ka: float, t_hi_ka: float) -> Optional[Dict[str, object]]:
    """Pool counts of all samples with t_lo <= age < t_hi and return group percentages."""
    df = obs["counts"]
    age_ka = df["age_cal_bp"].astype(float) / 1000.0
    win = df[(age_ka >= t_lo_ka) & (age_ka < t_hi_ka)]
    if win.empty:
        return None
    total = float(win.loc[win["in_terrestrial_sum"], "count"].sum())
    if total <= 0:
        return None
    pct = win.loc[win["in_terrestrial_sum"]].groupby("pft_group")["count"].sum() / total * 100.0
    return {
        "n_samples": int(win[["depth_cm"]].drop_duplicates().shape[0]),
        "terrestrial_sum": int(total),
        "pct": {str(k): float(v) for k, v in pct.items()},
    }


# ---------------------------------------------------------------- model side
def model_pft_cells_for_step(veg: Dict[str, np.ndarray], mask: np.ndarray, ka_bp: float) -> Dict[str, object]:
    """Count cells per BIOME4 PFT (1-13) inside ``mask`` for the three presence definitions.

    Missing keys (e.g. the all-bare-bedrock bypass result) give zero counts.
    """
    mask = np.asarray(mask, dtype=bool)
    row: Dict[str, object] = {"ka_bp": float(ka_bp), "n_cells": int(mask.sum())}

    def _int(key):
        a = veg.get(key)
        if a is None:
            return None
        a = np.asarray(a, dtype="float64")
        return np.rint(np.where(np.isfinite(a), a, -1)).astype(int)

    opt = _int("optpft_node")
    dom = _int("dominant_pft_by_npp_node")
    sec = _int("second_pft_by_npp_node")
    for p in range(1, 14):
        npp = veg.get(f"pft{p:02d}_mod_npp_node")
        npp = None if npp is None else np.asarray(npp, dtype="float64")
        npp_pos = np.zeros(mask.shape, bool) if npp is None else (np.isfinite(npp) & (npp > 0.0))
        passed = veg.get(f"pft{p:02d}_constraint_pass_node")
        passed = np.zeros(mask.shape, bool) if passed is None else (np.asarray(passed) == 1)
        row[f"optpft_p{p:02d}"] = 0 if opt is None else int(np.sum(mask & (opt == p)))
        if dom is None or sec is None:
            row[f"top2_npp_p{p:02d}"] = 0
        else:
            row[f"top2_npp_p{p:02d}"] = int(np.sum(mask & npp_pos & ((dom == p) | (sec == p))))
        row[f"potential_p{p:02d}"] = int(np.sum(mask & passed & npp_pos))
    return row


def _model_group_present(step: Dict[str, object], pfts: Iterable[int], method: str, min_cells: int) -> bool:
    if method not in PRESENCE_METHODS:
        raise ValueError(f"unknown PFT presence method {method!r}; use one of {PRESENCE_METHODS}")
    n = sum(int(step.get(f"{method}_p{p:02d}", 0)) for p in pfts)
    return n >= max(1, int(min_cells))


# ---------------------------------------------------------------- scoring
def _classify(obs_present: bool, model_present: bool) -> str:
    if obs_present and model_present:
        return "TP"
    if obs_present:
        return "FN"
    if model_present:
        return "FP"
    return "TN"


def build_comparison_rows(
    step_rows: List[Dict[str, object]],
    obs: Dict[str, object],
    dt_kyr: float,
    method: str = "optpft",
    min_cells: int = 1,
    min_age_ka: float = 0.0,
    threshold_override_pct: Optional[float] = None,
    ignore_group_methods: bool = False,
) -> pd.DataFrame:
    groups = obs["groups"].copy()
    if ignore_group_methods:
        groups["model_method"] = ""
    out = []
    for step in step_rows:
        t = float(step["ka_bp"])
        if t < float(min_age_ka):
            continue
        w = observed_group_percent_for_window(obs, t - dt_kyr / 2.0, t + dt_kyr / 2.0)
        if w is None:
            continue
        for g in groups.itertuples(index=False):
            if not g.scored:
                continue
            thr = float(g.presence_threshold_pct if threshold_override_pct is None else threshold_override_pct)
            pct = float(w["pct"].get(g.pft_group, 0.0))
            o = pct >= thr
            gm = g.model_method or method
            m = _model_group_present(step, g.biome4_pfts, gm, min_cells)
            out.append({
                "ka_bp": t, "pft_group": g.pft_group, "label": g.label,
                "biome4_pfts": ";".join(str(p) for p in g.biome4_pfts),
                "obs_pct": round(pct, 3), "threshold_pct": thr, "obs_present": int(o),
                "model_method": gm, "model_cells": int(sum(int(step.get(f"{gm}_p{p:02d}", 0)) for p in g.biome4_pfts)),
                "model_min_cells": int(min_cells), "model_present": int(m),
                "outcome": _classify(o, m),
                "n_pollen_samples": w["n_samples"], "terrestrial_sum": w["terrestrial_sum"],
            })
    return pd.DataFrame(out)


def summarize(comp: pd.DataFrame, by: Iterable[str] = ("pft_group",)) -> pd.DataFrame:
    if comp.empty:
        return pd.DataFrame()

    def _one(df: pd.DataFrame) -> Dict[str, float]:
        c = df["outcome"].value_counts()
        tp, fp, fn, tn = (int(c.get(k, 0)) for k in ("TP", "FP", "FN", "TN"))
        sens = tp / (tp + fn) if (tp + fn) else np.nan
        spec = tn / (tn + fp) if (tn + fp) else np.nan
        return {
            "n": tp + fp + fn + tn, "TP": tp, "FP": fp, "FN": fn, "TN": tn,
            "accuracy": (tp + tn) / (tp + fp + fn + tn),
            "sensitivity": sens, "specificity": spec,
            # TSS is undefined when the observations contain only presences or only absences.
            "TSS": sens + spec - 1.0 if np.isfinite(sens) and np.isfinite(spec) else np.nan,
            "obs_prevalence": (tp + fn) / (tp + fp + fn + tn),
            "model_prevalence": (tp + fp) / (tp + fp + fn + tn),
        }

    rows = []
    for key, df in comp.groupby(list(by), sort=False):
        key = key if isinstance(key, tuple) else (key,)
        rows.append({**dict(zip(by, key)), **_one(df)})
    pooled = _one(comp)
    rows.append({**{b: "ALL" for b in by}, **pooled})
    return pd.DataFrame(rows)


def write_outputs(
    step_rows: List[Dict[str, object]],
    res_dir: Path,
    dt_kyr: float,
    method: str = "optpft",
    min_cells: int = 1,
    min_age_ka: float = 0.0,
    case_label: str = "",
    obs: Optional[Dict[str, object]] = None,
) -> Dict[str, Path]:
    """Write per-step model counts, comparison rows, summaries and a threshold sweep."""
    res_dir = Path(res_dir)
    res_dir.mkdir(parents=True, exist_ok=True)
    obs = obs or load_observations()
    paths = {}
    p = res_dir / "pft_model_cells_per_output_time.csv"
    pd.DataFrame(step_rows).to_csv(p, index=False, encoding="utf-8-sig"); paths["model_cells"] = p

    comp = build_comparison_rows(step_rows, obs, dt_kyr, method, min_cells, min_age_ka)
    comp.insert(0, "case_label", case_label)
    p = res_dir / "pft_validation_per_output_time.csv"
    comp.to_csv(p, index=False, encoding="utf-8-sig"); paths["comparison"] = p

    summ = summarize(comp)
    summ.insert(0, "case_label", case_label)
    summ.insert(1, "model_method", method)
    summ.insert(2, "min_age_ka", float(min_age_ka))
    p = res_dir / "pft_validation_summary.csv"
    summ.to_csv(p, index=False, encoding="utf-8-sig"); paths["summary"] = p

    sweep = []
    for m in PRESENCE_METHODS:
        for thr in (None,) + SWEEP_THRESHOLDS_PCT:
            c = build_comparison_rows(step_rows, obs, dt_kyr, m, min_cells, min_age_ka, thr,
                                      ignore_group_methods=True)
            s = summarize(c)
            if s.empty:
                continue
            s.insert(0, "model_method", m)
            s.insert(1, "obs_threshold", "group_default" if thr is None else f"{thr:g}%")
            sweep.append(s)
    if sweep:
        p = res_dir / "pft_validation_sensitivity.csv"
        sw = pd.concat(sweep, ignore_index=True)
        sw.insert(0, "case_label", case_label)
        sw.to_csv(p, index=False, encoding="utf-8-sig"); paths["sensitivity"] = p
    return paths
