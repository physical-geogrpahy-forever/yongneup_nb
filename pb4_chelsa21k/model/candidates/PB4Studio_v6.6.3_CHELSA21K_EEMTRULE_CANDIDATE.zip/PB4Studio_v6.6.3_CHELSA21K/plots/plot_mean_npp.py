from pathlib import Path

import matplotlib.font_manager as fm
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
STATIC_PATH = ROOT / "outputs_CHELSA21K" / "model_static" / "summary_timeseries.csv"
DYNAMIC_PATH = ROOT / "outputs_CHELSA21K" / "model_dynamic" / "summary_timeseries.csv"
OUT_DIR = Path(__file__).resolve().parent

PNG_PATH = OUT_DIR / "YONGNEUP_U008_mean_npp_CHELSA_style.png"
SVG_PATH = OUT_DIR / "YONGNEUP_U008_mean_npp_CHELSA_style.svg"


def set_korean_font() -> None:
    candidates = ["Noto Sans CJK KR", "Noto Sans KR", "NanumGothic", "Malgun Gothic"]
    available = {f.name for f in fm.fontManager.ttflist}
    for name in candidates:
        if name in available:
            plt.rcParams["font.family"] = name
            break
    plt.rcParams["axes.unicode_minus"] = False


def main() -> None:
    static = pd.read_csv(STATIC_PATH, encoding="utf-8-sig").sort_values("ka_bp", ascending=False)
    dynamic = pd.read_csv(DYNAMIC_PATH, encoding="utf-8-sig").sort_values("ka_bp", ascending=False)
    set_korean_font()

    fig, ax1 = plt.subplots(figsize=(8.2, 4.8))

    dynamic_line, = ax1.plot(
        dynamic["ka_bp"], dynamic["mean_npp"],
        color="firebrick", linewidth=1.6, linestyle="-", label="동적모델"
    )
    ax1.set_xlabel("연대 (ka BP)")
    ax1.set_ylabel(r"평균 NPP (g C m$^{-2}$ yr$^{-1}$)")
    ax1.set_xlim(21, 0)
    ax1.set_xticks(np.arange(21, -0.1, -3))

    static_line, = ax1.plot(
        static["ka_bp"], static["mean_npp"],
        color="royalblue", linewidth=1.4, linestyle="-", label="정적모델"
    )

    # No figure title by design, matching plot_chelsa_climate.py.
    ax1.legend(
        [dynamic_line, static_line],
        ["동적모델", "정적모델"],
        loc="upper left", frameon=False
    )

    fig.tight_layout()
    fig.savefig(PNG_PATH, dpi=600, bbox_inches="tight")
    fig.savefig(SVG_PATH, bbox_inches="tight")
    plt.close(fig)

    print(PNG_PATH)
    print(SVG_PATH)


if __name__ == "__main__":
    main()
