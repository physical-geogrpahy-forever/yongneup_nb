@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\run_yongneup_21ka_chelsa_selfcontained.py
) else (
  python tools\run_yongneup_21ka_chelsa_selfcontained.py
)
if errorlevel 1 pause
endlocal
