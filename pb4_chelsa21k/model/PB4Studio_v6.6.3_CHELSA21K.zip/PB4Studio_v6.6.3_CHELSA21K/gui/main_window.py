# -*- coding: utf-8 -*-
"""gui/main_window.py — PB4Studio 메인 윈도우."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QMainWindow, QTabWidget, QMessageBox

from gui.state import GuiState
from gui.tab_input import InputTab
from gui.tab_boundary import BoundaryTab
from gui.tab_time_mode import TimeModeTab
from gui.tab_coefficients import CoefficientsTab
from gui.tab_run import RunTab
from gui.tab_results import ResultsTab
from gui.worker import RunWorker
from pb4studio import __version__


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"PB4Studio CHELSA21K {__version__} — Pelletier–BIOME4")
        self.resize(1000, 700)

        self.state = GuiState()
        self._worker: RunWorker | None = None

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self.input_tab = InputTab()
        self.boundary_tab = BoundaryTab(get_grid_info_callback=lambda: self.input_tab._last_grid_info)
        self.time_mode_tab = TimeModeTab(get_climate_path_callback=lambda: self.input_tab.climate_row.path())
        self.coefficients_tab = CoefficientsTab()
        self.run_tab = RunTab(on_run_clicked=self.start_run)
        self.results_tab = ResultsTab()

        self.tabs.addTab(self.input_tab, "1. 입력 자료")
        self.tabs.addTab(self.boundary_tab, "2. 경계 조건")
        self.tabs.addTab(self.time_mode_tab, "3. 시간·모드·자원")
        self.tabs.addTab(self.coefficients_tab, "4. 계수 설정")
        self.tabs.addTab(self.run_tab, "5. 실행")
        self.tabs.addTab(self.results_tab, "6. 결과")

        # hotfix10n10 self-contained preset.  All paths are package-relative so
        # the ZIP can be extracted anywhere.  Users may still replace them in
        # the GUI; the exact-grid runner path only activates for this manifest.
        embedded = Path(__file__).resolve().parent.parent / "embedded_inputs" / "yongneup_exact20m"
        manifest = embedded / "PB4STUDIO_EXACT_GRID.json"
        if manifest.exists():
            self.state.biome4_variant = "mckenzie2003"
            self.state.dem_path = str(embedded / "dem_20m_exact.tif")
            self.state.basin_path = str(embedded / "basin_exact20m.geojson")
            self.state.climate_path = str(embedded / "YONGNEUP_CHELSA_TRACE21k_ENVICLOUD_RAW_WIDE.csv")
            self.state.soil_depth_path = str(embedded / "soil_depth_20m_exact_m.tif")
            self.state.soil_depth_unit = "m"
            self.state.soil_texture_path = str(embedded / "soil_texture_20m_exact.tif")
            self.state.open_free_shp = str(embedded / "outlet_open_free_exact20m.geojson")
            self.state.resolution_m_override = 20.0
            self.state.output_dir = "outputs_CHELSA21K"
            self.input_tab.apply_state(self.state)
            self.boundary_tab.apply_state(self.state)
            self.time_mode_tab.apply_state(self.state)
            self.coefficients_tab.apply_state(self.state)

    # ------------------------------------------------------------------
    def collect_state(self) -> GuiState:
        self.input_tab.collect_into(self.state)
        self.boundary_tab.collect_into(self.state)
        self.time_mode_tab.collect_into(self.state)
        self.coefficients_tab.collect_into(self.state)
        return self.state

    def start_run(self) -> None:
        state = self.collect_state()
        missing = state.missing_required_fields()
        if missing:
            QMessageBox.warning(self, "입력 필요", "다음 입력이 비어 있습니다: " + ", ".join(missing))
            return

        if state.resolution_m_override is None:
            if not self._confirm_native_resolution(state):
                self.tabs.setCurrentWidget(self.input_tab)
                return

        try:
            run_config = state.to_run_config()
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "설정 오류", str(exc))
            return

        self.run_tab.set_running(True)
        self.run_tab.progress_bar.setValue(0)
        self.run_tab.append_log("실행을 시작합니다…")

        self._worker = RunWorker(run_config)
        self._worker.progress.connect(self.run_tab.on_progress)
        self._worker.log.connect(self.run_tab.append_log)
        self._worker.finished_ok.connect(self._on_finished)
        self._worker.failed.connect(self._on_failed)
        self._worker.start()

    def _confirm_native_resolution(self, state: GuiState) -> bool:
        """해상도를 직접 지정하지 않았을 때, DEM 원본 해상도로 그냥 진행할지 명시적으로 확인받는다.
        체크박스를 깜빡 잊고 다른 해상도로 도는 실수를 방지하기 위함 — 이 확인창은 매번 뜬다."""
        native_res_msg = "확인 실패"
        try:
            from pb4studio import grid as grid_mod
            info = grid_mod.detect_target_grid_from_dem(Path(state.dem_path))
            native_res_msg = f"약 {info['resolution_m']:.2f} m"
        except Exception:  # noqa: BLE001
            pass

        reply = QMessageBox.question(
            self, "해상도 확인",
            f"'해상도 직접 지정'을 켜지 않아서 DEM 원본 해상도({native_res_msg})로 실행합니다.\n\n"
            "지형발달 계수(사면폭·계곡 임계면적 등)는 특정 해상도를 기준으로 검증되는 경우가 많습니다. "
            "이전에 검증된 해상도(예: 20 m)가 있다면 그 값으로 맞추지 않으면 침식/퇴적 균형과 "
            "정확도가 달라질 수 있습니다.\n\n"
            "그래도 DEM 원본 해상도로 계속 진행할까요?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        return reply == QMessageBox.Yes

    def _on_finished(self, results: dict) -> None:
        self.run_tab.set_running(False)
        self.run_tab.append_log("완료. '결과' 탭에서 확인하세요.")
        self.results_tab.set_results(results)
        self.tabs.setCurrentWidget(self.results_tab)

    def _on_failed(self, message: str) -> None:
        self.run_tab.set_running(False)
        QMessageBox.critical(self, "실행 오류", message)
