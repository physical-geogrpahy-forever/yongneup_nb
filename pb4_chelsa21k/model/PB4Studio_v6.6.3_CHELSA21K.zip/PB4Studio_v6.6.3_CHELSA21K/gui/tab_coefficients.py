# -*- coding: utf-8 -*-
"""gui/tab_coefficients.py — Pelletier-process 계수 편집 (기본값 도움말 포함)."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QLabel, QHeaderView,
)

from pb4studio.config import parameter_help_rows
from pb4studio.pelletier_geomorph import PelletierStrictConfig

COL_LABEL, COL_VALUE, COL_UNIT, COL_DEFAULT, COL_HELP = range(5)


class CoefficientsTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        note = QLabel(
            "모든 계수의 기본값은 본 패키지에 내장된 Pelletier-process 지형발달 모듈의 기본값입니다. "
            "값을 바꾸면 '기본값' 열의 표시가 사라집니다. 각 셀 위에 마우스를 올리면 도움말이 뜹니다. "
            "최소토심과 스텝당 고도변화 제한은 제거되어 더 이상 설정 항목으로 표시되지 않습니다."
        )
        note.setWordWrap(True)
        layout.addWidget(note)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["계수", "값", "단위", "기본값", "도움말"])
        self.table.horizontalHeader().setSectionResizeMode(COL_HELP, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        layout.addWidget(self.table)

        self.reset_button = QPushButton("전체 기본값으로 재설정")
        self.reset_button.clicked.connect(self.reset_to_defaults)
        layout.addWidget(self.reset_button)

        self._rows_meta = []  # field name per row index
        self._populate(PelletierStrictConfig())

    def _populate(self, cfg: PelletierStrictConfig) -> None:
        rows = parameter_help_rows(cfg)
        self.table.setRowCount(len(rows))
        self._rows_meta = []
        for r, row in enumerate(rows):
            label_item = QTableWidgetItem(row["label"])
            label_item.setFlags(label_item.flags() & ~Qt.ItemIsEditable)
            label_item.setToolTip(row["help"])
            self.table.setItem(r, COL_LABEL, label_item)

            value_item = QTableWidgetItem(str(row["current_value"]))
            value_item.setToolTip(row["help"])
            self.table.setItem(r, COL_VALUE, value_item)

            unit_item = QTableWidgetItem(str(row["unit"]))
            unit_item.setFlags(unit_item.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(r, COL_UNIT, unit_item)

            default_item = QTableWidgetItem("기본값" if row["is_default"] else "")
            default_item.setFlags(default_item.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(r, COL_DEFAULT, default_item)

            help_item = QTableWidgetItem(row["help"])
            help_item.setFlags(help_item.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(r, COL_HELP, help_item)

            self._rows_meta.append(row["name"])

    def reset_to_defaults(self) -> None:
        self._populate(PelletierStrictConfig())

    def current_overrides(self) -> dict:
        """기본값에서 바뀐 계수만 {필드명: 값} 형태로 반환."""
        defaults = PelletierStrictConfig()
        overrides = {}
        for r, name in enumerate(self._rows_meta):
            raw = self.table.item(r, COL_VALUE).text().strip()
            default_val = getattr(defaults, name)
            try:
                if isinstance(default_val, bool):
                    val = raw.lower() in ("true", "1", "yes")
                elif isinstance(default_val, int):
                    val = int(float(raw))
                else:
                    val = float(raw)
            except ValueError:
                continue  # 잘못 입력된 값은 무시하고 기본값 유지
            if val != default_val:
                overrides[name] = val
        return overrides

    def apply_state(self, state) -> None:
        cfg = PelletierStrictConfig(**state.pelletier_overrides)
        self._populate(cfg)

    def collect_into(self, state) -> None:
        state.pelletier_overrides = self.current_overrides()
