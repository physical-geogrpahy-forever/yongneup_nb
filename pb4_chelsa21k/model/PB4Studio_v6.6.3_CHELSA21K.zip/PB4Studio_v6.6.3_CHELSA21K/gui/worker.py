# -*- coding: utf-8 -*-
"""gui/worker.py — 무거운 runner.run() 호출을 UI 스레드 밖에서 실행."""
from __future__ import annotations

import traceback

from PySide6.QtCore import QThread, Signal

from pb4studio import runner
from pb4studio.config import RunConfig


class RunWorker(QThread):
    progress = Signal(str, int, int, float)  # case_label, step_index, n_steps, ka
    log = Signal(str)
    finished_ok = Signal(dict)
    failed = Signal(str)

    def __init__(self, run_config: RunConfig, parent=None):
        super().__init__(parent)
        self.run_config = run_config

    def run(self) -> None:  # QThread override
        try:
            variant_label = (
                "BIOME4-SD McKenzie2003 + SoilGrids AWC (PFT6 Sitch2003 BoNE)"
                if self.run_config.science.biome4_variant == "mckenzie2003"
                else "원본 BIOME4 v4.2b2 비교 기준"
            )
            self.log.emit(f"식생모델: {variant_label}")
            self.log.emit("격자/유역/입력자료를 불러오는 중...")

            def _on_progress(case_label, step_index, n_steps, ka):
                self.progress.emit(case_label, step_index, n_steps, ka)

            results = runner.run(self.run_config, progress_callback=_on_progress)
            self.log.emit("실행 완료.")
            self.finished_ok.emit(results)
        except Exception as exc:  # noqa: BLE001 - UI에 그대로 보여주기 위함
            trace = traceback.format_exc()
            self.log.emit("오류 발생:\n" + trace)
            try:
                from pathlib import Path
                Path("pb4studio_last_error.log").write_text(trace, encoding="utf-8")
            except Exception:
                pass
            try:
                import pb4studio
                engine_version = getattr(pb4studio, "__version__", "<unknown>")
                runner_path = getattr(runner, "__file__", "<unknown>")
            except Exception:
                engine_version = "<unknown>"
                runner_path = "<unknown>"
            self.failed.emit(
                f"{exc}\n\nPB4Studio engine: {engine_version}\nrunner: {runner_path}\n"
                "상세 traceback은 실행 탭 로그에서 확인할 수 있습니다."
            )
