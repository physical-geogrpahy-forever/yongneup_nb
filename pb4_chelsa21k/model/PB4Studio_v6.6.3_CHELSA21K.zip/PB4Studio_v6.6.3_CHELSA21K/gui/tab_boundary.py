# -*- coding: utf-8 -*-
"""gui/tab_boundary.py — 경계 조건 탭."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout, QDoubleSpinBox, QPushButton,
    QLabel, QCheckBox,
)

from gui.widgets_common import PathPickerRow
from pb4studio.boundary import BoundaryConfig

VECTOR_FILTER = "벡터 (*.geojson *.json *.shp);;모든 파일 (*)"


class BoundaryTab(QWidget):
    def __init__(self, get_grid_info_callback, parent=None):
        """``get_grid_info_callback``은 InputTab에서 마지막으로 확인한
        격자 정보(dict, {'info':..., 'transform':..., 'shape':..., 'polygon_land':...})를
        반환하는 콜러블이다. 아직 확인 전이면 None을 반환해야 한다.
        """
        super().__init__(parent)
        self._get_grid_info = get_grid_info_callback

        layout = QVBoxLayout(self)
        group = QGroupBox("경계 조건 (open 경계를 나타내는 점/선 shp)")
        form = QFormLayout(group)

        self.free_shp_row = PathPickerRow("자유유출 shp", mode="file", filter_str=VECTOR_FILTER, optional=True)
        self.fixed_shp_row = PathPickerRow("일정경사유지 shp", mode="file", filter_str=VECTOR_FILTER, optional=True)
        self.slope_spin = QDoubleSpinBox()
        self.slope_spin.setRange(0.0, 90.0)
        self.slope_spin.setDecimals(3)
        self.slope_spin.setSingleStep(0.1)
        self.slope_spin.setValue(0.5)
        self.slope_spin.setSuffix(" %")

        form.addRow(self.free_shp_row)
        form.addRow(self.fixed_shp_row)
        form.addRow("공통 경사값 (일정경사유지 경계에 적용)", self.slope_spin)
        layout.addWidget(group)

        self.snap_checkbox = QCheckBox("shp 지점이 유역 내부 셀이면 가장 가까운 경계 셀로 자동 이동 (기본 꺼짐)")
        self.snap_checkbox.setChecked(False)
        layout.addWidget(self.snap_checkbox)

        note = QLabel(
            "지정한 shp(점 또는 선)와 겹치는 셀만 open(유출)으로 처리되고, 나머지 모든 셀은 closed(반사경계)입니다.\n"
            "두 shp 모두 비워두면 오류가 납니다 — 최소 1개 이상의 open 경계가 필요합니다.\n"
            "기본적으로는 shp 좌표를 그대로 씁니다 — outlet이 유역 경계에서 벗어나 있다면, 그건 보통 입력 shp 자체를 "
            "고쳐야 하는 문제이기 때문입니다(아래 미리보기가 정확히 얼마나/어느 셀 쪽으로 벗어났는지 알려줍니다). "
            "편의상 자동으로 옮기고 싶다면 위 체크박스를 켜세요."
        )
        note.setWordWrap(True)
        layout.addWidget(note)

        self.preview_button = QPushButton("경계 미리보기 (입력 자료 탭에서 먼저 '격자 정보 확인'을 눌러야 합니다)")
        self.preview_button.clicked.connect(self._on_preview)
        layout.addWidget(self.preview_button)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)
        layout.addStretch(1)

    def _on_preview(self) -> None:
        grid_info = self._get_grid_info()
        if not grid_info or "transform" not in grid_info:
            self.status_label.setText("⚠ 먼저 '입력 자료' 탭에서 DEM과 유역 폴리곤으로 '격자 정보 확인'을 눌러주세요.")
            return

        land = grid_info["polygon_land"]
        transform = grid_info["transform"]
        crs = grid_info["info"]["crs"]

        try:
            bc = BoundaryConfig.from_shapefiles(
                land_mask=land, transform=transform, dst_crs=crs,
                common_slope_percent=self.slope_spin.value(),
                open_free_shp=self.free_shp_row.path() or None,
                open_fixed_slope_shp=self.fixed_shp_row.path() or None,
                snap_to_land_boundary=self.snap_checkbox.isChecked(),
            )
        except Exception as exc:  # noqa: BLE001
            self.status_label.setText(f"⚠ 경계 처리 중 오류: {exc}")
            return

        warnings = bc.validate(land)
        n_free = len(bc.open_free_cells())
        n_fixed = len(bc.open_fixed_slope_cells())
        lines = [f"자유유출 셀: {n_free}개", f"일정경사유지 셀: {n_fixed}개"]
        if bc.snap_report:
            lines.append("자동 보정된 셀:")
            for s in bc.snap_report:
                lines.append(f"  - {s['from']} → {s['to']} ({s['distance_cells']:.1f}셀 이동)")
        if warnings:
            lines.append("경고:")
            lines.extend(f"  - {w}" for w in warnings)
        else:
            lines.append("✓ 문제 없음")
        self.status_label.setText("\n".join(lines))

    def apply_state(self, state) -> None:
        self.free_shp_row.set_path(state.open_free_shp)
        self.fixed_shp_row.set_path(state.open_fixed_slope_shp)
        self.slope_spin.setValue(state.common_slope_percent)
        self.snap_checkbox.setChecked(state.snap_open_cells_to_boundary)

    def collect_into(self, state) -> None:
        state.open_free_shp = self.free_shp_row.path()
        state.open_fixed_slope_shp = self.fixed_shp_row.path()
        state.common_slope_percent = self.slope_spin.value()
        state.snap_open_cells_to_boundary = self.snap_checkbox.isChecked()
