# -*- coding: utf-8 -*-
"""gui/tab_input.py — 입력 자료 탭."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout, QComboBox, QPushButton,
    QLabel, QTextEdit, QDoubleSpinBox, QCheckBox,
)

from gui.widgets_common import PathPickerRow
from pb4studio import grid as grid_mod
from pb4studio import runner as runner_mod
from pb4studio.config import RunConfig, RunMode, InputPaths, TimeConfig, ScienceConfig
from pb4studio.pelletier_geomorph import PelletierStrictConfig


RASTER_FILTER = "래스터 (*.tif *.tiff *.img);;모든 파일 (*)"
VECTOR_FILTER = "벡터 (*.geojson *.json *.shp);;모든 파일 (*)"
NC_FILTER = "CHELSA RAW WIDE CSV (*.csv);;CSV (*.csv);;모든 파일 (*)"


class InputTab(QWidget):
    grid_checked = Signal(dict)  # detect_target_grid_from_dem() 결과 dict 전달

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        model_group = QGroupBox("식생-토양 결합 모델")
        model_form = QFormLayout(model_group)
        self.biome4_variant_combo = QComboBox()
        self.biome4_variant_combo.addItem(
            "BIOME4-SD — McKenzie 2003 + SoilGrids 용늪 AWC + Pelletier", "mckenzie2003"
        )
        self.biome4_variant_combo.addItem(
            "원본 BIOME4 v4.2b2 (비교 기준)", "original"
        )
        model_form.addRow("식생모델", self.biome4_variant_combo)
        self.biome4_variant_note = QLabel("")
        self.biome4_variant_note.setWordWrap(True)
        model_form.addRow(self.biome4_variant_note)
        self.biome4_variant_combo.currentIndexChanged.connect(self._update_biome4_variant_note)
        self._update_biome4_variant_note()
        layout.addWidget(model_group)

        group = QGroupBox("입력 자료 (지형 · 기후 · 토심 · 토성)")
        form = QFormLayout(group)

        self.dem_row = PathPickerRow("DEM (지형)", mode="file", filter_str=RASTER_FILTER)
        self.basin_row = PathPickerRow("유역 폴리곤", mode="file", filter_str=VECTOR_FILTER)
        self.climate_row = PathPickerRow("CHELSA-TraCE21k RAW WIDE CSV", mode="file", filter_str=NC_FILTER)
        self.soil_depth_row = PathPickerRow("토심 자료", mode="file", filter_str=RASTER_FILTER)
        self.soil_unit_combo = QComboBox()
        self.soil_unit_combo.addItems(["cm", "mm", "m", "auto"])
        self.soil_texture_row = PathPickerRow("토성 자료", mode="file",
                                               filter_str="래스터/CSV (*.tif *.tiff *.img *.csv);;모든 파일 (*)")

        form.addRow(self.dem_row)
        form.addRow(self.basin_row)
        form.addRow(self.climate_row)
        climate_note = QLabel(
            "CHELSA21K 전용: EnviCloud Kelvin 온도를 실행 시 자동으로 섭씨로 변환하고, "
            "0~21 ka BP만 허용하며, DEM 고도감률 보정은 적용하지 않습니다. "
            "BIOME4에 필요한 cloud는 내장 Beyer cloud-only 보조자료를 사용합니다."
        )
        climate_note.setWordWrap(True)
        form.addRow(climate_note)
        form.addRow(self.soil_depth_row)
        form.addRow("토심 단위", self.soil_unit_combo)
        form.addRow(self.soil_texture_row)

        layout.addWidget(group)

        res_group = QGroupBox("해상도")
        res_form = QFormLayout(res_group)
        self.res_override_checkbox = QCheckBox("해상도 직접 지정 (끄면 DEM 원본 해상도를 그대로 씁니다)")
        self.res_override_checkbox.toggled.connect(lambda on: self.res_override_spin.setEnabled(on))
        self.res_override_spin = QDoubleSpinBox()
        self.res_override_spin.setRange(0.1, 10000.0)
        self.res_override_spin.setDecimals(2)
        self.res_override_spin.setValue(20.0)
        self.res_override_spin.setSuffix(" m")
        self.res_override_spin.setEnabled(False)
        res_form.addRow(self.res_override_checkbox)
        res_form.addRow("지정 해상도", self.res_override_spin)
        note2 = QLabel(
            "지형발달 계수(사면폭·계곡 임계면적 등)는 특정 해상도를 기준으로 만들어져 있어서, "
            "DEM 네이티브 해상도가 그 기준과 크게 다르면 침식/퇴적 균형이 달라질 수 있습니다. "
            "예전에 검증된 해상도(예: 20 m)로 맞추고 싶으면 여기서 지정하세요."
        )
        note2.setWordWrap(True)
        res_form.addRow(note2)
        layout.addWidget(res_group)

        check_row = QVBoxLayout()
        self.check_button = QPushButton("격자 정보 확인 (DEM 기준 CRS/해상도 자동감지 + 유역 교집합 계산)")
        self.check_button.clicked.connect(self._on_check_grid)
        check_row.addWidget(self.check_button)
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        check_row.addWidget(self.status_label)
        layout.addLayout(check_row)

        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setMaximumHeight(140)
        layout.addWidget(self.log_area)
        layout.addStretch(1)

        self._last_grid_info = None

    def _update_biome4_variant_note(self) -> None:
        variant = self.biome4_variant_combo.currentData()
        if variant == "mckenzie2003":
            self.biome4_variant_note.setText(
                "McKenzie et al. (2003)의 -10 kPa~-1.5 MPa profile AWC와 exponential root-depth scaling, "
                "SoilGrids 용늪 지점 수분보유값, BIOME4 원본의 Jackson et al. 상부 30 cm root fraction을 사용합니다. "
                "토심→NPP/LAI/FVC 직접 보정은 없습니다. BIOME4 고유 수문 프로파일의 최대 깊이 1.5 m는 유지합니다."
            )
        else:
            self.biome4_variant_note.setText(
                "원본 BIOME4 v4.2b2 비교 기준입니다. 고정 0-30 cm/30-150 cm root 구조와 원본 수문식을 그대로 사용합니다."
            )

    # ------------------------------------------------------------------
    def _on_check_grid(self) -> None:
        dem_path = self.dem_row.path()
        basin_path = self.basin_row.path()
        if not dem_path:
            self.status_label.setText("⚠ DEM 파일을 먼저 선택하세요.")
            return
        try:
            info = grid_mod.detect_target_grid_from_dem(Path(dem_path))
        except Exception as exc:  # noqa: BLE001
            self.status_label.setText(f"⚠ DEM을 읽는 중 오류: {exc}")
            return

        msg = [f"CRS: {info['crs']}", f"DEM 원본 해상도: {info['resolution_m']:.3f} m"]
        for w in info["warnings"]:
            msg.append(f"⚠ {w}")

        res_override = self.res_override_spin.value() if self.res_override_checkbox.isChecked() else None
        effective_res = res_override if res_override else info["resolution_m"]
        if res_override:
            msg.append(f"➜ 해상도 직접 지정됨: {res_override:.3f} m 로 리샘플링해서 계산합니다.")

        soil_depth_path = self.soil_depth_row.path()
        soil_texture_path = self.soil_texture_row.path()

        if basin_path and soil_depth_path and soil_texture_path:
            # 실제 실행(runner.run)과 완전히 동일한 로직으로 최종 land 마스크까지 계산.
            # (경계 미리보기 등 다른 화면에서 이 결과를 그대로 재사용해야 서로 다른
            # land 마스크로 인한 혼란이 없다.)
            try:
                dummy_cfg = RunConfig(
                    mode=RunMode.STATIC,
                    inputs=InputPaths(
                        dem_path=dem_path, climate_nc_path=self.climate_row.path() or dem_path,
                        soil_depth_path=soil_depth_path, soil_texture_path=soil_texture_path,
                        basin_polygon_path=basin_path, soil_depth_unit=self.soil_unit_combo.currentText(),
                    ),
                    time=TimeConfig(start_ka=1.0, end_ka=0.0, interval_kyr=1.0),
                    pelletier=PelletierStrictConfig(), science=ScienceConfig(),
                )
                igrid = runner_mod.build_initial_grid(dummy_cfg, resolution_m_override=res_override)
                n_cells = int(igrid.land.sum())
                msg.append(f"격자 크기: {igrid.shape[0]} x {igrid.shape[1]} (해상도 {igrid.resolution_m:.3f} m)")
                msg.append(f"최종 land 셀 수(유역∩DEM∩토심∩토성 유효값): {n_cells} "
                           f"(≈{n_cells * igrid.resolution_m**2:,.0f} m²)")
                self._last_grid_info = {
                    "info": info, "transform": igrid.transform, "shape": igrid.shape,
                    "polygon_land": igrid.land, "land": igrid.land,
                }
            except Exception as exc:  # noqa: BLE001
                msg.append(f"⚠ 최종 land 마스크 계산 중 오류(폴리곤만으로 대체): {exc}")
                self._last_grid_info = self._polygon_only_preview(info, dem_path, basin_path, msg, effective_res)
        elif basin_path:
            msg.append("(토심·토성 자료까지 선택하면 최종 land 셀 수까지 정확히 계산합니다 — "
                       "지금은 유역 폴리곤만으로 근사 계산합니다)")
            self._last_grid_info = self._polygon_only_preview(info, dem_path, basin_path, msg, effective_res)
        else:
            msg.append("(유역 폴리곤을 선택하면 셀 수까지 계산합니다)")
            self._last_grid_info = {"info": info}

        text = "\n".join(msg)
        self.status_label.setText(text)
        self.log_area.append(text)
        self.grid_checked.emit(self._last_grid_info)

    @staticmethod
    def _polygon_only_preview(info, dem_path, basin_path, msg, resolution_m=None) -> dict:
        res = resolution_m or info["resolution_m"]
        try:
            basin_geom = grid_mod.load_basin_geometry(Path(basin_path), target_crs=info["crs"])
            transform, shape = grid_mod.build_target_grid_from_dem(Path(dem_path), basin_geom, res)
            polygon_land = grid_mod.rasterize_basin(basin_geom, transform, shape, all_touched=False)
            n_polygon_cells = int(polygon_land.sum())
            msg.append(f"격자 크기: {shape[0]} x {shape[1]} (해상도 {res:.3f} m)")
            msg.append(f"유역 폴리곤 내 셀 수(근사): {n_polygon_cells} "
                       f"(≈{n_polygon_cells * res**2:,.0f} m²)")
            return {"info": info, "transform": transform, "shape": shape, "polygon_land": polygon_land}
        except Exception as exc:  # noqa: BLE001
            msg.append(f"⚠ 유역 폴리곤 처리 중 오류: {exc}")
            return {"info": info}

    # ------------------------------------------------------------------
    def apply_state(self, state) -> None:
        idx_variant = self.biome4_variant_combo.findData(state.biome4_variant)
        if idx_variant >= 0:
            self.biome4_variant_combo.setCurrentIndex(idx_variant)
        self.dem_row.set_path(state.dem_path)
        self.basin_row.set_path(state.basin_path)
        self.climate_row.set_path(state.climate_path)
        self.soil_depth_row.set_path(state.soil_depth_path)
        idx = self.soil_unit_combo.findText(state.soil_depth_unit)
        if idx >= 0:
            self.soil_unit_combo.setCurrentIndex(idx)
        self.soil_texture_row.set_path(state.soil_texture_path)
        if state.resolution_m_override:
            self.res_override_checkbox.setChecked(True)
            self.res_override_spin.setValue(state.resolution_m_override)
        else:
            self.res_override_checkbox.setChecked(False)

    def collect_into(self, state) -> None:
        state.biome4_variant = str(self.biome4_variant_combo.currentData())
        state.dem_path = self.dem_row.path()
        state.basin_path = self.basin_row.path()
        state.climate_path = self.climate_row.path()
        state.soil_depth_path = self.soil_depth_row.path()
        state.soil_depth_unit = self.soil_unit_combo.currentText()
        state.soil_texture_path = self.soil_texture_row.path()
        state.resolution_m_override = self.res_override_spin.value() if self.res_override_checkbox.isChecked() else None
