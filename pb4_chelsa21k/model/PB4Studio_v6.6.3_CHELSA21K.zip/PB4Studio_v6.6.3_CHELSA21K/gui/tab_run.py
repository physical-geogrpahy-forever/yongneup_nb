# -*- coding: utf-8 -*-
"""gui/tab_run.py — 실행 버튼, 진행바, 로그."""
from __future__ import annotations

from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QProgressBar, QTextEdit, QLabel


class RunTab(QWidget):
    def __init__(self, on_run_clicked, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        self.run_button = QPushButton("실행")
        self.run_button.clicked.connect(on_run_clicked)
        layout.addWidget(self.run_button)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        layout.addWidget(self.progress_bar)

        self.status_label = QLabel("대기 중")
        layout.addWidget(self.status_label)

        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        layout.addWidget(self.log_area)

    def append_log(self, text: str) -> None:
        self.log_area.append(text)

    def on_progress(self, case_label: str, step_index: int, n_steps: int, ka: float) -> None:
        pct = int(100 * (step_index + 1) / max(n_steps, 1))
        self.progress_bar.setValue(pct)
        self.status_label.setText(f"{case_label}: {step_index + 1}/{n_steps} 스텝 (현재 {ka:.2f} ka BP)")

    def set_running(self, running: bool) -> None:
        self.run_button.setEnabled(not running)
        self.run_button.setText("실행 중…" if running else "실행")
