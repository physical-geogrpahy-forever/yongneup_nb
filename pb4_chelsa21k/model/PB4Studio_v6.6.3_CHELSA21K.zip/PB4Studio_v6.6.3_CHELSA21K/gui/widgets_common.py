# -*- coding: utf-8 -*-
"""gui/widgets_common.py — 여러 탭에서 재사용하는 작은 위젯들."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QWidget, QHBoxLayout, QLineEdit, QPushButton, QFileDialog, QLabel


class PathPickerRow(QWidget):
    """라벨 + 읽기전용 경로 표시 + '찾아보기' 버튼. 파일 또는 폴더 선택 지원."""

    changed = Signal(str)

    def __init__(self, label: str, mode: str = "file", filter_str: str = "모든 파일 (*)",
                 optional: bool = False, parent=None):
        super().__init__(parent)
        self._mode = mode
        self._filter = filter_str
        self._optional = optional

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(label)
        self.label.setMinimumWidth(140)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("(선택 안 함)" if optional else "필수")
        self.button = QPushButton("찾아보기…")
        self.button.clicked.connect(self._on_browse)
        self.clear_button = QPushButton("지우기")
        self.clear_button.setVisible(optional)
        self.clear_button.clicked.connect(lambda: self.set_path(""))

        layout.addWidget(self.label)
        layout.addWidget(self.edit, stretch=1)
        layout.addWidget(self.button)
        if optional:
            layout.addWidget(self.clear_button)

        self.edit.textChanged.connect(self.changed.emit)

    def _on_browse(self) -> None:
        if self._mode == "file":
            path, _ = QFileDialog.getOpenFileName(self, self.label.text(), "", self._filter)
        elif self._mode == "save_dir":
            path = QFileDialog.getExistingDirectory(self, self.label.text())
        else:
            raise ValueError(f"unknown mode: {self._mode}")
        if path:
            self.set_path(path)

    def path(self) -> str:
        return self.edit.text().strip()

    def set_path(self, value: str) -> None:
        self.edit.setText(value)
