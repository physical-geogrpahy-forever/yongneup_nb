# -*- coding: utf-8 -*-
"""gui/tab_results.py — 결과 뷰어 (지도 / 그래프 / 정확도)."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd
import rasterio

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QComboBox, QPushButton,
    QLabel, QTableWidget, QTableWidgetItem, QScrollArea,
)

from pb4studio.figures import parse_vegetation_ratio_long, VEG_CODE_LABEL_KO
from pb4studio.standard_report import make_standard_report
from pb4studio.snapshots import parse_snapshot_dir_name, snapshot_dir_name

VARIABLES = ["elevation_m", "soil_depth_m", "vegetation_code", "npp", "eemt"]
VAR_LABELS = {
    "elevation_m": "고도 (m)", "soil_depth_m": "토심 (m)", "vegetation_code": "식생유형 코드",
    "npp": "NPP", "eemt": "EEMT",
}


VEG_CLASS_NAMES = {0: "침엽수림", 1: "활엽수림", 2: "혼효림", 3: "초본·개방식생", 4: "무식생·나지"}
VEG_CLASS_COLORS = ["#1f78b4", "#33a02c", "#b2df8a", "#fdbf6f", "#bdbdbd"]  # 0~3 기존 팔레트 + 4 무식생·나지


class MapSubTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._results: Optional[Dict[str, object]] = None
        layout = QVBoxLayout(self)

        controls = QHBoxLayout()
        self.case_combo = QComboBox()
        self.var_combo = QComboBox()
        for v in VARIABLES:
            self.var_combo.addItem(VAR_LABELS[v], userData=v)
        self.snapshot_combo = QComboBox()
        self.show_button = QPushButton("표시")
        self.show_button.clicked.connect(self.render)
        self.overview_button = QPushButton("전체 시점 한눈에 보기")
        self.overview_button.clicked.connect(self.render_overview)
        controls.addWidget(QLabel("모델"))
        controls.addWidget(self.case_combo)
        controls.addWidget(QLabel("변수"))
        controls.addWidget(self.var_combo)
        controls.addWidget(QLabel("시점"))
        controls.addWidget(self.snapshot_combo)
        controls.addWidget(self.show_button)
        controls.addWidget(self.overview_button)
        layout.addLayout(controls)

        self.figure = Figure(figsize=(5, 4))
        self.canvas = FigureCanvasQTAgg(self.figure)
        layout.addWidget(self.canvas)

    def set_results(self, results: Dict[str, object]) -> None:
        self._results = results
        self.case_combo.clear()
        for key, label in [("static", "정적모델"), ("dynamic", "동적모델")]:
            if key in results:
                self.case_combo.addItem(label, userData=key)
        if results.get("difference_maps_ka"):
            self.case_combo.addItem("차이(동적-정적)", userData="difference")

        # 스냅샷 ka 목록: static 또는 dynamic 결과 폴더에서 실제 존재하는 snapshot_*ka 폴더를 스캔.
        self.snapshot_combo.clear()
        for key in ("static", "dynamic"):
            if key in results:
                out_dir = Path(results[key]["output_dir"])
                kas = []
                for pth in out_dir.glob("snapshot_*ka"):
                    try:
                        kas.append(parse_snapshot_dir_name(pth.name))
                    except ValueError:
                        continue
                for ka in sorted(kas, reverse=True):
                    label = f"{ka:g} ka BP"
                    self.snapshot_combo.addItem(label, userData=ka)
                break

    def render(self) -> None:
        if not self._results:
            return
        case_key = self.case_combo.currentData()
        var = self.var_combo.currentData()
        ka = self.snapshot_combo.currentData()
        if case_key is None or var is None or ka is None:
            return

        is_veg = (var == "vegetation_code")
        if case_key == "difference":
            fname = "vegetation_code_match.tif" if is_veg else f"{var}_diff.tif"
            tif_path = (Path(self._results["dynamic"]["output_dir"]).parent
                        / "model_difference_dynamic_minus_static" / snapshot_dir_name(ka) / fname)
            title = (f"식생유형 일치 여부 (동적 vs 정적), {ka} ka BP" if is_veg
                     else f"{VAR_LABELS[var]} 차이 (동적-정적), {ka} ka BP")
        else:
            tif_path = Path(self._results[case_key]["output_dir"]) / snapshot_dir_name(ka) / f"{var}.tif"
            case_label = "정적모델" if case_key == "static" else "동적모델"
            title = f"{VAR_LABELS[var]} — {case_label}, {ka} ka BP"

        self.figure.clear()
        ax = self.figure.add_subplot(111)
        if not tif_path.exists():
            ax.text(0.5, 0.5, f"파일 없음:\n{tif_path.name}", ha="center", va="center")
            self.canvas.draw()
            return
        with rasterio.open(tif_path) as ds:
            arr = ds.read(1)
            nodata = ds.nodata
            arr = np.where(arr == nodata, np.nan, arr) if nodata is not None else arr

        if case_key == "difference" and is_veg:
            self._render_match_mismatch(ax, arr, title)
        elif is_veg:
            self._render_categorical_vegetation(ax, arr, title)
        else:
            cmap = "RdBu_r" if case_key == "difference" else "viridis"
            im = ax.imshow(arr, cmap=cmap)
            ax.set_title(title)
            self.figure.colorbar(im, ax=ax, shrink=0.8)
        self.canvas.draw()

    def render_overview(self) -> None:
        if not self._results:
            return
        case_key = self.case_combo.currentData()
        var = self.var_combo.currentData()
        if case_key is None or var is None:
            return
        is_veg = (var == "vegetation_code")
        is_diff = (case_key == "difference")

        kas = [self.snapshot_combo.itemData(i) for i in range(self.snapshot_combo.count())]
        kas = sorted([k for k in kas if k is not None], reverse=True)
        if not kas:
            return

        arrays = {}
        for ka in kas:
            if is_diff:
                fname = "vegetation_code_match.tif" if is_veg else f"{var}_diff.tif"
                tif_path = (Path(self._results["dynamic"]["output_dir"]).parent
                            / "model_difference_dynamic_minus_static" / snapshot_dir_name(ka) / fname)
            else:
                tif_path = Path(self._results[case_key]["output_dir"]) / snapshot_dir_name(ka) / f"{var}.tif"
            if not tif_path.exists():
                continue
            with rasterio.open(tif_path) as ds:
                arr = ds.read(1)
                nodata = ds.nodata
                arrays[ka] = np.where(arr == nodata, np.nan, arr) if nodata is not None else arr

        if not arrays:
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.text(0.5, 0.5, "표시할 스냅샷이 없습니다", ha="center", va="center")
            self.canvas.draw()
            return

        n = len(arrays)
        ncols = int(np.ceil(np.sqrt(n)))
        nrows = int(np.ceil(n / ncols))
        self.figure.clear()
        self.figure.set_size_inches(2.6 * ncols, 2.6 * nrows)

        vmin = vmax = None
        if not is_veg and not (is_diff and is_veg):
            all_vals = np.concatenate([a[np.isfinite(a)] for a in arrays.values()]) if arrays else np.array([0.0])
            if all_vals.size:
                if is_diff:
                    lim = float(np.nanmax(np.abs(all_vals))) if all_vals.size else 1.0
                    vmin, vmax = -lim, lim
                else:
                    vmin, vmax = float(np.nanmin(all_vals)), float(np.nanmax(all_vals))

        from matplotlib.colors import ListedColormap, BoundaryNorm
        from matplotlib.patches import Patch
        for i, ka in enumerate(kas):
            if ka not in arrays:
                continue
            ax = self.figure.add_subplot(nrows, ncols, i + 1)
            arr = arrays[ka]
            if is_diff and is_veg:
                cmap = ListedColormap(["#d73027", "#1a9850"])
                norm = BoundaryNorm(boundaries=[-0.5, 0.5, 1.5], ncolors=2)
                ax.imshow(arr, cmap=cmap, norm=norm)
            elif is_veg:
                codes = sorted(VEG_CLASS_NAMES.keys())
                cmap = ListedColormap([VEG_CLASS_COLORS[c] for c in codes])
                norm = BoundaryNorm(boundaries=[c - 0.5 for c in codes] + [codes[-1] + 0.5], ncolors=len(codes))
                ax.imshow(arr, cmap=cmap, norm=norm)
            else:
                cmap = "RdBu_r" if is_diff else "viridis"
                ax.imshow(arr, cmap=cmap, vmin=vmin, vmax=vmax)
            ax.set_title(f"{ka} ka BP", fontsize=9)
            ax.set_xticks([]); ax.set_yticks([])

        case_label = {"static": "정적모델", "dynamic": "동적모델", "difference": "차이(동적-정적)"}[case_key]
        self.figure.suptitle(f"{VAR_LABELS[var]} — {case_label} (전체 시점)", fontsize=11)
        if is_diff and is_veg:
            patches = [Patch(facecolor="#1a9850", label="일치"), Patch(facecolor="#d73027", label="불일치")]
            self.figure.legend(handles=patches, loc="lower center", ncol=2, fontsize=9, frameon=False)
            self.figure.tight_layout(rect=(0, 0.06, 1, 0.93))
        elif is_veg:
            codes = sorted(VEG_CLASS_NAMES.keys())
            patches = [Patch(facecolor=VEG_CLASS_COLORS[c], label=f"{c} {VEG_CLASS_NAMES[c]}") for c in codes]
            self.figure.legend(handles=patches, loc="lower center", ncol=4, fontsize=9, frameon=False)
            self.figure.tight_layout(rect=(0, 0.06, 1, 0.93))
        else:
            self.figure.tight_layout(rect=(0, 0, 1, 0.95))
        self.canvas.draw()

    def _render_categorical_vegetation(self, ax, arr: np.ndarray, title: str) -> None:
        from matplotlib.colors import ListedColormap, BoundaryNorm

        codes = sorted(VEG_CLASS_NAMES.keys())
        cmap = ListedColormap([VEG_CLASS_COLORS[c] for c in codes])
        norm = BoundaryNorm(boundaries=[c - 0.5 for c in codes] + [codes[-1] + 0.5], ncolors=len(codes))
        im = ax.imshow(arr, cmap=cmap, norm=norm)
        ax.set_title(title)
        cbar = self.figure.colorbar(im, ax=ax, ticks=codes, shrink=0.8)
        cbar.ax.set_yticklabels([VEG_CLASS_NAMES[c] for c in codes])

    def _render_match_mismatch(self, ax, arr: np.ndarray, title: str) -> None:
        from matplotlib.colors import ListedColormap, BoundaryNorm

        cmap = ListedColormap(["#d73027", "#1a9850"])  # 0=불일치(빨강), 1=일치(초록)
        norm = BoundaryNorm(boundaries=[-0.5, 0.5, 1.5], ncolors=2)
        im = ax.imshow(arr, cmap=cmap, norm=norm)
        ax.set_title(title)
        cbar = self.figure.colorbar(im, ax=ax, ticks=[0, 1], shrink=0.8)
        cbar.ax.set_yticklabels(["불일치", "일치"])
        n_valid = int(np.sum(np.isfinite(arr)))
        n_match = int(np.nansum(arr))
        if n_valid > 0:
            ax.set_xlabel(f"일치율: {n_match}/{n_valid} ({100*n_match/n_valid:.1f}%)")
        self.canvas.draw()


class GraphSubTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._results: Optional[Dict[str, object]] = None
        layout = QVBoxLayout(self)

        controls = QHBoxLayout()
        self.var_combo = QComboBox()
        for name, label in [("mean_elevation_m", "평균 고도"), ("mean_soil_depth_m", "평균 토심"),
                             ("mean_npp", "평균 NPP"), ("mean_eemt", "평균 EEMT"),
                             ("vegetation_ratio", "식생유형 비율")]:
            self.var_combo.addItem(label, userData=name)
        self.show_button = QPushButton("표시")
        self.show_button.clicked.connect(self.render)
        controls.addWidget(QLabel("변수"))
        controls.addWidget(self.var_combo)
        controls.addWidget(self.show_button)
        layout.addLayout(controls)

        self.figure = Figure(figsize=(5, 4))
        self.canvas = FigureCanvasQTAgg(self.figure)
        layout.addWidget(self.canvas)

    def set_results(self, results: Dict[str, object]) -> None:
        self._results = results

    def render(self) -> None:
        if not self._results:
            return
        var = self.var_combo.currentData()
        if var == "vegetation_ratio":
            self._render_vegetation_ratio()
            return

        self.figure.clear()
        ax = self.figure.add_subplot(111)
        for key, label in [("static", "정적모델"), ("dynamic", "동적모델")]:
            if key not in self._results:
                continue
            csv_path = Path(self._results[key]["output_dir"]) / "summary_timeseries.csv"
            if not csv_path.exists():
                continue
            df = pd.read_csv(csv_path)
            if var not in df.columns:
                continue
            ax.plot(df["ka_bp"], df[var], label=label)
        ax.invert_xaxis()
        ax.set_xlabel("ka BP")
        ax.set_ylabel(var)
        ax.legend()
        self.canvas.draw()

    def _render_vegetation_ratio(self) -> None:
        """시간에 따른 식생유형 비율 변화 — 케이스별(정적/동적) stackplot."""
        frames = []
        for key, label in [("dynamic", "동적모델"), ("static", "정적모델")]:
            if key not in self._results:
                continue
            csv_path = Path(self._results[key]["output_dir"]) / "summary_timeseries.csv"
            if not csv_path.exists():
                continue
            df = pd.read_csv(csv_path)
            if "vegetation_class_counts" not in df.columns or "n_cells" not in df.columns:
                continue
            df = df.copy()
            df["yr_bp"] = df["ka_bp"].astype(float) * 1000.0
            df["case_label"] = label
            frames.append(df)

        self.figure.clear()
        if not frames:
            ax = self.figure.add_subplot(111)
            ax.text(0.5, 0.5, "식생유형 비율 데이터가 없습니다", ha="center", va="center")
            self.canvas.draw()
            return

        ts = pd.concat(frames, ignore_index=True)
        ratio = parse_vegetation_ratio_long(ts)
        if ratio.empty:
            ax = self.figure.add_subplot(111)
            ax.text(0.5, 0.5, "식생유형 비율 데이터가 없습니다", ha="center", va="center")
            self.canvas.draw()
            return

        class_order = [0, 1, 2, 3, 4]
        colors = [VEG_CLASS_COLORS[c] for c in class_order]
        case_order = list(dict.fromkeys(ratio["case_label"].tolist()))
        axes = self.figure.subplots(nrows=len(case_order), ncols=1, sharex=True, squeeze=False)
        for ax, case_label in zip(axes[:, 0], case_order):
            sub = ratio[ratio["case_label"] == case_label]
            pivot = sub.pivot_table(index="yr_bp", columns="vegetation_code", values="ratio_pct",
                                     aggfunc="mean").sort_index(ascending=False)
            for cls in class_order:
                if cls not in pivot.columns:
                    pivot[cls] = 0.0
            pivot = pivot[class_order].fillna(0.0)
            ax.stackplot(pivot.index.values, [pivot[c].values for c in class_order],
                         labels=[VEG_CODE_LABEL_KO[c] for c in class_order], colors=colors, alpha=0.85)
            ax.set_title(case_label, fontsize=10)
            ax.set_ylabel("면적 비율 (%)")
            ax.set_ylim(0, 100)
            ax.invert_xaxis()
        axes[-1, 0].set_xlabel("시간 (yr BP)")
        handles, labels = axes[0, 0].get_legend_handles_labels()
        self.figure.legend(handles, labels, loc="lower center", ncol=5, fontsize=8, frameon=False)
        self.figure.suptitle("시간에 따른 식생유형 비율", fontsize=11)
        self.figure.tight_layout(rect=(0, 0.08, 1, 0.93))
        self.canvas.draw()


class AccuracySubTab(QWidget):
    """선택한 고식생 정확도 측정 방법과 점유율 기준의 단일 결과."""
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        note = QLabel(
            "선택한 점유율 기준에서 고식생 정확도(%)를 표시합니다. "
            "'출력시점(dt)별'은 구간 안의 각 dt를 평가하고, '구간 내 최소 1회(dt)'는 "
            "각 고식생 구간에서 한 번이라도 기준 이상이면 그 구간을 일치로 판정합니다."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels([
            "모델", "정확도 측정 방법", "점유율 기준", "일치 수", "평가 수", "정확도(%)",
        ])
        layout.addWidget(self.table)
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.image_label)

    def set_results(self, results: Dict[str, object]) -> None:
        rows = results.get("validation_accuracy_rows")
        if not rows:
            # Single-model mode: calculate the configured-threshold summary locally.
            from pb4studio.validation import compute_selected_accuracy_table
            by_case = {}
            for case_key, case_label in (("static", "정적모델"), ("dynamic", "동적모델")):
                case = results.get(case_key)
                if case and case.get("validation_per_output_rows"):
                    by_case[case_label] = case.get("validation_per_output_rows", [])
            if by_case:
                rows = compute_selected_accuracy_table(
                    by_case, method=str(results.get("validation_accuracy_method", "per_output_time"))
                ).to_dict("records")
        if not rows:
            self.table.setRowCount(0)
            self.image_label.clear()
            return

        method_labels = {
            "basin_presence_fraction_per_output_time": "출력시점(dt)별 일치율",
            "per_output_time": "출력시점(dt)별 일치율",
            "interval_any_dt": "구간 내 최소 1회(dt) 출현율",
        }
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            threshold = float(row.get("basin_presence_min_percent", float("nan")))
            correct_n = int(row.get("correct_n", 0))
            method = str(row.get("primary_accuracy_method", results.get("validation_accuracy_method", "per_output_time")))
            if method == "interval_any_dt":
                n_eval = int(row.get("n_palaeo_records", row.get("n", 0)))
            else:
                n_eval = int(row.get("n_time_steps", row.get("n", 0)))
            accuracy = float(row.get("accuracy_pct", float("nan")))
            self.table.setItem(r, 0, QTableWidgetItem(str(row.get("case_label", ""))))
            self.table.setItem(r, 1, QTableWidgetItem(method_labels.get(method, method)))
            self.table.setItem(r, 2, QTableWidgetItem(f"{threshold:g}%"))
            self.table.setItem(r, 3, QTableWidgetItem(str(correct_n)))
            self.table.setItem(r, 4, QTableWidgetItem(str(n_eval)))
            self.table.setItem(r, 5, QTableWidgetItem(f"{accuracy:.2f}"))

        png_path = None
        # In static+dynamic comparison mode prefer the combined single-threshold chart.
        if results.get("static") and results.get("dynamic"):
            out_root = Path(results["static"]["output_dir"]).parent
            candidate = out_root / "figures" / "validation_accuracy_static_dynamic.png"
            if candidate.exists():
                png_path = candidate
        if png_path is None:
            for case_key in ("static", "dynamic"):
                case = results.get(case_key)
                if not case:
                    continue
                candidate = Path(case["output_dir"]) / "figures" / "validation_accuracy.png"
                if candidate.exists():
                    png_path = candidate
                    break
        if png_path is not None:
            pix = QPixmap(str(png_path))
            self.image_label.setPixmap(pix.scaledToWidth(720, Qt.SmoothTransformation))
        else:
            self.image_label.clear()


class StandardReportSubTab(QWidget):
    """Compact seven-figure result board (21/10/5/0 ka + time series + validation)."""
    FIGURE_LABELS = {
        "01_soil_depth_maps.png": "1. 토심 지도 (21·10·5·0 ka)",
        "02_mean_soil_depth.png": "2. 평균 토심 변화",
        "03_vegetation_maps.png": "3. 식생유형 지도 (21·10·5·0 ka)",
        "04_vegetation_ratio.png": "4. 시간에 따른 식생유형 비율",
        "05_paleovegetation_accuracy.png": "5. 고식생 검증 정확도",
        "06_elevation_maps.png": "6. 고도 지도 (21·10·5·0 ka)",
        "07_mean_elevation.png": "7. 평균 고도 변화",
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self._results: Optional[Dict[str, object]] = None
        self._paths: Dict[str, Path] = {}
        layout = QVBoxLayout(self)
        controls = QHBoxLayout()
        self.figure_combo = QComboBox()
        self.regen_button = QPushButton("표준 결과판 다시 생성")
        self.regen_button.clicked.connect(self.regenerate)
        self.show_button = QPushButton("표시")
        self.show_button.clicked.connect(self.render)
        controls.addWidget(QLabel("결과 그림"))
        controls.addWidget(self.figure_combo, 1)
        controls.addWidget(self.show_button)
        controls.addWidget(self.regen_button)
        layout.addLayout(controls)
        self.path_label = QLabel()
        self.path_label.setWordWrap(True)
        layout.addWidget(self.path_label)
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.image_label)
        layout.addWidget(scroll, 1)

    def _output_root(self) -> Optional[Path]:
        if not self._results:
            return None
        for key in ("static", "dynamic"):
            case = self._results.get(key)
            if case and case.get("output_dir"):
                return Path(case["output_dir"]).parent
        return None

    def set_results(self, results: Dict[str, object]) -> None:
        self._results = results
        self.refresh_paths()
        if self.figure_combo.count():
            self.figure_combo.setCurrentIndex(0)
            self.render()

    def refresh_paths(self) -> None:
        self.figure_combo.clear()
        self._paths = {}
        root = self._output_root()
        if root is None:
            self.path_label.setText("정적+동적 비교 결과가 없습니다.")
            return
        report_dir = root / "standard_report"
        for fname, label in self.FIGURE_LABELS.items():
            p = report_dir / fname
            if p.exists():
                self._paths[fname] = p
                self.figure_combo.addItem(label, userData=fname)
        self.path_label.setText(f"저장 폴더: {report_dir}")

    def regenerate(self) -> None:
        root = self._output_root()
        if root is None:
            self.path_label.setText("정적+동적 비교 결과가 없습니다.")
            return
        try:
            make_standard_report(root, allow_nearest=False)
            self.refresh_paths()
            if self.figure_combo.count():
                self.figure_combo.setCurrentIndex(0)
                self.render()
        except Exception as exc:  # noqa: BLE001
            self.path_label.setText(f"표준 결과판 생성 실패: {exc}")

    def render(self) -> None:
        fname = self.figure_combo.currentData()
        if not fname or fname not in self._paths:
            self.image_label.clear()
            return
        p = self._paths[fname]
        pix = QPixmap(str(p))
        if pix.isNull():
            self.image_label.setText(f"그림을 읽지 못했습니다: {p}")
            return
        # Keep enough resolution to inspect map cells; the scroll area handles overflow.
        target_w = max(800, min(1150, pix.width()))
        self.image_label.setPixmap(pix.scaledToWidth(target_w, Qt.SmoothTransformation))
        self.path_label.setText(f"파일: {p}")


class ResultsTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        self.sub_tabs = QTabWidget()
        self.map_tab = MapSubTab()
        self.graph_tab = GraphSubTab()
        self.accuracy_tab = AccuracySubTab()
        self.standard_report_tab = StandardReportSubTab()
        self.sub_tabs.addTab(self.map_tab, "지도")
        self.sub_tabs.addTab(self.graph_tab, "그래프")
        self.sub_tabs.addTab(self.accuracy_tab, "고식생 검증")
        self.sub_tabs.addTab(self.standard_report_tab, "표준 결과판")
        layout.addWidget(self.sub_tabs)

    def set_results(self, results: Dict[str, object]) -> None:
        self.map_tab.set_results(results)
        self.graph_tab.set_results(results)
        self.accuracy_tab.set_results(results)
        self.standard_report_tab.set_results(results)
