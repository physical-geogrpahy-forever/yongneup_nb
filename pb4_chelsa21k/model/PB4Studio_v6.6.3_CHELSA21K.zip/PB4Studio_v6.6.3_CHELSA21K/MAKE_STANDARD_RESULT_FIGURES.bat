@echo off
setlocal
cd /d "%~dp0"
set "OUT=%~1"
if "%OUT%"=="" set "OUT=outputs_CHELSA21K"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\make_standard_result_figures.py "%OUT%"
) else (
  python tools\make_standard_result_figures.py "%OUT%"
)
if errorlevel 1 (
  echo.
  echo Standard result figure generation FAILED.
  pause
  exit /b 1
)
echo.
echo Finished. Figures are in %OUT%\standard_report
pause
