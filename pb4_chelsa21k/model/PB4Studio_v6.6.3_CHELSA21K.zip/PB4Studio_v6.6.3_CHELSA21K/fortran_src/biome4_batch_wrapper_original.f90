! OpenMP batch wrapper for the original BIOME4 v4.2b2 50-slot interface.
subroutine biome4_batch(ncell, vars_in_all, output_all) bind(C, name="biome4_batch")
  use, intrinsic :: iso_c_binding, only: c_int, c_float
  implicit none
  integer(c_int), value :: ncell
  real(c_float), intent(in) :: vars_in_all(50, ncell)
  real(c_float), intent(out) :: output_all(500, ncell)
  integer :: i
  real :: vars_in(50)
  real :: output(500)
!$omp parallel do default(none) shared(ncell, vars_in_all, output_all) private(i, vars_in, output) schedule(dynamic, 32)
  do i = 1, ncell
     vars_in(:) = vars_in_all(:, i)
     output(:) = 0.0
     call biome4(vars_in, output)
     output_all(:, i) = output(:)
  end do
!$omp end parallel do
end subroutine biome4_batch
