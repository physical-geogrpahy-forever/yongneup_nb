실행 결과는 이 폴더에 생성됩니다.
RUN_YONGNEUP_21KA_AND_EXPORT_ALL.bat을 실행하십시오.
