@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\check_package_contract.py
) else (
  python tools\check_package_contract.py
)
if errorlevel 1 pause
