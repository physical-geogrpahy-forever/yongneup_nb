# -*- coding: utf-8 -*-
"""Snapshot age naming helpers.

Snapshot directories must preserve the actual requested model age.  Earlier
versions rounded ages to an integer when constructing ``snapshot_*ka`` paths,
so 4.5, 4.4 and 4.3 ka could overwrite one another.  These helpers provide one
canonical reversible representation for both writers and readers.
"""
from __future__ import annotations

import re
from pathlib import Path

_SNAPSHOT_RE = re.compile(r"^snapshot_([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)ka$")


def format_snapshot_age_ka(age_ka: float) -> str:
    """Return a stable, human-readable ka label without unnecessary zeros.

    Ten decimal places are far finer than any model timestep used by PB4Studio
    while suppressing ordinary binary floating-point tails (e.g. 4.6000000001).
    Integer ages remain backward-compatible (``5`` -> ``snapshot_5ka``).
    """
    age = round(float(age_ka), 10)
    if abs(age) < 5e-11:
        age = 0.0
    text = f"{age:.10f}".rstrip("0").rstrip(".")
    return text if text not in ("-0", "") else "0"


def snapshot_dir_name(age_ka: float) -> str:
    return f"snapshot_{format_snapshot_age_ka(age_ka)}ka"


def parse_snapshot_dir_name(name_or_path) -> float:
    """Parse a canonical/legacy ``snapshot_*ka`` directory name to float ka."""
    name = Path(name_or_path).name
    match = _SNAPSHOT_RE.match(name)
    if not match:
        raise ValueError(f"Not a snapshot directory name: {name}")
    return float(match.group(1))


def map_snapshot_ages_to_output_indices(output_ages_ka, requested_ages_ka, *, atol_ka: float = 1e-6):
    """Return ``{output_index: [requested_age, ...]}`` using exact-age matching.

    Snapshot ages are scientific timestamps.  An off-grid request must never be
    silently relabelled with the nearest available model state.  Every requested
    age therefore has to coincide with an actual model output age within the
    floating-point tolerance used by :class:`TimeConfig` (1e-6 ka by default).
    """
    import math

    outputs = [float(x) for x in output_ages_ka]
    requested = [float(x) for x in requested_ages_ka]
    mapping = {}
    if not outputs:
        if requested:
            raise ValueError("모델 출력시점이 없어 스냅샷을 저장할 수 없습니다.")
        return mapping
    if not all(math.isfinite(x) for x in outputs + requested):
        raise ValueError("스냅샷 또는 모델 출력 연대에 유효하지 않은 값이 있습니다.")

    base_tol = max(float(atol_ka), 0.0)
    for req in requested:
        diffs = [abs(x - req) for x in outputs]
        idx = min(range(len(outputs)), key=lambda j: diffs[j])
        tol = max(base_tol, 1e-10 * max(1.0, abs(req), abs(outputs[idx])))
        if diffs[idx] > tol:
            raise ValueError(
                "스냅샷 요청시점이 실제 모델 출력시점과 일치하지 않습니다: "
                f"요청 {req:g} ka BP, 가장 가까운 출력 {outputs[idx]:g} ka BP. "
                "스냅샷 저장 간격을 모델 출력 간격(interval_kyr)의 배수로 설정하거나, "
                "모델 출력 간격을 더 짧게 설정하세요. 가장 가까운 시점의 결과를 "
                "다른 연대 이름으로 저장하지 않습니다."
            )
        mapping.setdefault(idx, []).append(req)
    return mapping
