# -*- coding: utf-8 -*-
"""Standard PB4Studio result-board figures.

This module creates the compact seven-figure result set requested for the
Yongneup static/dynamic comparison workflow:
  1) soil-depth maps (dynamic/static/difference) at 21/10/5/0 ka
  2) mean soil-depth time series
  3) vegetation maps (dynamic/static/match-mismatch) at 21/10/5/0 ka
  4) vegetation-class area-ratio time series
  5) palaeovegetation validation accuracy by record
  6) elevation maps (dynamic/static/difference) at 21/10/5/0 ka
  7) mean elevation time series

The scientific model is not modified here.  This is output-only postprocessing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import json

import numpy as np
import pandas as pd
import rasterio

from .validation import setup_korean_matplotlib
from .snapshots import parse_snapshot_dir_name, snapshot_dir_name

REPORT_AGES_KA: Tuple[float, ...] = (21.0, 10.0, 5.0, 0.0)
VEG_LABELS = {
    0: "침엽수림",
    1: "활엽수림",
    2: "혼효림",
    3: "초본·개방식생",
    4: "무식생·나지",
}
VEG_COLORS = {
    0: "#2c7fb8",
    1: "#2ca02c",
    2: "#addd8e",
    3: "#fdbf6f",
    4: "#bdbdbd",
}
MATCH_COLORS = {0: "#e31a1c", 1: "#1b9e77"}


def _read_tif(path: Path) -> Optional[np.ndarray]:
    path = Path(path)
    if not path.exists():
        return None
    with rasterio.open(path) as ds:
        a = ds.read(1).astype("float64")
        if ds.nodata is not None:
            a = np.where(a == ds.nodata, np.nan, a)
        return a


def _available_snapshot_ages(case_dir: Path) -> List[float]:
    ages: List[float] = []
    for p in Path(case_dir).glob("snapshot_*ka"):
        try:
            ages.append(float(parse_snapshot_dir_name(p.name)))
        except Exception:
            continue
    return sorted(set(ages), reverse=True)


def _resolve_age(case_dir: Path, requested_ka: float, allow_nearest: bool = False) -> Tuple[float, bool]:
    ages = _available_snapshot_ages(case_dir)
    if not ages:
        raise FileNotFoundError(f"스냅샷 폴더가 없습니다: {case_dir}")
    for a in ages:
        if abs(a - requested_ka) <= 1e-8:
            return a, False
    if allow_nearest:
        nearest = min(ages, key=lambda x: abs(x - requested_ka))
        return nearest, True
    raise FileNotFoundError(
        f"표준 보고서에 필요한 {requested_ka:g} ka 스냅샷이 없습니다. "
        f"사용 가능한 시점: {', '.join(f'{x:g}' for x in ages)}"
    )


def _outline(ax, arr: np.ndarray) -> None:
    m = np.isfinite(arr)
    if np.any(m):
        ax.contour(m.astype(float), levels=[0.5], colors="black", linewidths=0.9)


def _safe_percentile(values: Iterable[np.ndarray], q: float, default: float = 0.0) -> float:
    parts = [a[np.isfinite(a)] for a in values if a is not None and np.any(np.isfinite(a))]
    if not parts:
        return default
    return float(np.nanpercentile(np.concatenate(parts), q))


def _panel_title(requested: float, actual: float, suffix: str, fallback: bool) -> str:
    if fallback:
        return f"{requested:g} ka(대체 {actual:g} ka) | {suffix}"
    return f"{requested:g} ka | {suffix}"


def _make_numeric_map_board(
    static_dir: Path,
    dynamic_dir: Path,
    report_dir: Path,
    var: str,
    title: str,
    base_cmap: str,
    output_name: str,
    ages: Sequence[float] = REPORT_AGES_KA,
    allow_nearest: bool = False,
) -> Path:
    setup_korean_matplotlib()
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm

    rows = []
    for req in ages:
        da, dfallback = _resolve_age(dynamic_dir, req, allow_nearest=allow_nearest)
        sa, sfallback = _resolve_age(static_dir, req, allow_nearest=allow_nearest)
        d = _read_tif(Path(dynamic_dir) / snapshot_dir_name(da) / f"{var}.tif")
        s = _read_tif(Path(static_dir) / snapshot_dir_name(sa) / f"{var}.tif")
        if d is None or s is None:
            raise FileNotFoundError(f"{var} 스냅샷을 읽을 수 없습니다: {req:g} ka")
        rows.append((req, da, sa, dfallback or sfallback, d, s, d - s))

    base_arrays = [x for row in rows for x in (row[4], row[5])]
    vmin = _safe_percentile(base_arrays, 1.0, 0.0)
    vmax = _safe_percentile(base_arrays, 99.0, 1.0)
    if var == "soil_depth_m":
        vmin = min(0.0, vmin)
    if not np.isfinite(vmax) or vmax <= vmin:
        vmax = vmin + 1.0
    diff_arrays = [row[6] for row in rows]
    lim = _safe_percentile([np.abs(a) for a in diff_arrays], 99.0, 1.0)
    if not np.isfinite(lim) or lim <= 0:
        lim = 1e-9
    diff_norm = TwoSlopeNorm(vcenter=0.0, vmin=-lim, vmax=lim)

    # Standard-report layout: keep all three map columns equal-width and put
    # both colorbars in dedicated columns at the far right.  No colorbar is
    # allowed to occupy map-panel space, so soil-depth/elevation boards share
    # exactly the same geometry at every DPI/font setting.
    nrows = len(rows)
    fig = plt.figure(figsize=(12.6, 2.65 * nrows))
    gs = fig.add_gridspec(
        nrows=nrows, ncols=5,
        width_ratios=(1.0, 1.0, 1.0, 0.045, 0.045),
        left=0.035, right=0.965, bottom=0.035, top=0.935,
        wspace=0.14, hspace=0.22,
    )
    axes = np.empty((nrows, 3), dtype=object)
    for r in range(nrows):
        axes[r, 0] = fig.add_subplot(gs[r, 0])
        axes[r, 1] = fig.add_subplot(gs[r, 1])
        axes[r, 2] = fig.add_subplot(gs[r, 2])
    cax_base = fig.add_subplot(gs[:, 3])
    cax_diff = fig.add_subplot(gs[:, 4])

    im_base = None
    im_diff = None
    for r, (req, da, sa, fallback, d, s, diff) in enumerate(rows):
        for c, (arr, label) in enumerate(((d, "동적모델"), (s, "정적모델"))):
            ax = axes[r, c]
            cmap = plt.get_cmap(base_cmap).copy()
            cmap.set_bad("white")
            im_base = ax.imshow(np.ma.masked_invalid(arr), cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
            _outline(ax, arr)
            actual = da if c == 0 else sa
            ax.set_title(_panel_title(req, actual, label, fallback), fontsize=8)
            ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
        ax = axes[r, 2]
        cmap = plt.get_cmap("coolwarm").copy(); cmap.set_bad("white")
        im_diff = ax.imshow(np.ma.masked_invalid(diff), cmap=cmap, norm=diff_norm, interpolation="nearest")
        _outline(ax, diff)
        ax.set_title(_panel_title(req, da, f"동적-정적 {title.lower()}", fallback), fontsize=8)
        ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")

    fig.suptitle(title, fontsize=15, y=0.985)
    if im_base is not None:
        cb_base = fig.colorbar(im_base, cax=cax_base)
        cb_base.ax.tick_params(labelsize=8)
    else:
        cax_base.set_visible(False)
    if im_diff is not None:
        cb_diff = fig.colorbar(im_diff, cax=cax_diff)
        cb_diff.ax.tick_params(labelsize=8)
    else:
        cax_diff.set_visible(False)
    out = Path(report_dir) / output_name
    fig.savefig(out, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return out


def _make_vegetation_map_board(
    static_dir: Path,
    dynamic_dir: Path,
    report_dir: Path,
    ages: Sequence[float] = REPORT_AGES_KA,
    allow_nearest: bool = False,
) -> Path:
    setup_korean_matplotlib()
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap
    from matplotlib.patches import Patch

    codes = [0, 1, 2, 3, 4]
    veg_cmap = ListedColormap([VEG_COLORS[c] for c in codes]); veg_cmap.set_bad("white")
    veg_norm = BoundaryNorm([-0.5,0.5,1.5,2.5,3.5,4.5], veg_cmap.N)
    match_cmap = ListedColormap([MATCH_COLORS[0], MATCH_COLORS[1]]); match_cmap.set_bad("white")
    match_norm = BoundaryNorm([-0.5,0.5,1.5], match_cmap.N)

    nrows = len(ages)
    fig = plt.figure(figsize=(10.8, 2.5 * nrows + 0.7))
    gs = fig.add_gridspec(
        nrows=nrows, ncols=3,
        left=0.045, right=0.965, bottom=0.105, top=0.935,
        wspace=0.16, hspace=0.22,
    )
    axes = np.empty((nrows, 3), dtype=object)
    for r in range(nrows):
        for c in range(3):
            axes[r, c] = fig.add_subplot(gs[r, c])
    present_codes: set[int] = set()
    for r, req in enumerate(ages):
        da, dfallback = _resolve_age(dynamic_dir, req, allow_nearest=allow_nearest)
        sa, sfallback = _resolve_age(static_dir, req, allow_nearest=allow_nearest)
        fallback = dfallback or sfallback
        d = _read_tif(Path(dynamic_dir) / snapshot_dir_name(da) / "vegetation_code.tif")
        s = _read_tif(Path(static_dir) / snapshot_dir_name(sa) / "vegetation_code.tif")
        if d is None or s is None:
            raise FileNotFoundError(f"vegetation_code 스냅샷을 읽을 수 없습니다: {req:g} ka")
        d = np.where(np.isfinite(d), np.rint(d), np.nan)
        s = np.where(np.isfinite(s), np.rint(s), np.nan)
        for a in (d, s):
            present_codes.update(int(x) for x in np.unique(a[np.isfinite(a)]) if int(x) in VEG_LABELS)
        for c, (arr, label, actual) in enumerate(((d, "동적모델", da), (s, "정적모델", sa))):
            ax = axes[r,c]
            ax.imshow(np.ma.masked_invalid(arr), cmap=veg_cmap, norm=veg_norm, interpolation="nearest")
            _outline(ax, arr)
            ax.set_title(_panel_title(req, actual, label, fallback), fontsize=8)
            ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
        valid = np.isfinite(d) & np.isfinite(s)
        match = np.full(d.shape, np.nan, dtype="float64")
        match[valid] = (d[valid] == s[valid]).astype(float)
        ax = axes[r,2]
        ax.imshow(np.ma.masked_invalid(match), cmap=match_cmap, norm=match_norm, interpolation="nearest")
        _outline(ax, match)
        ax.set_title(_panel_title(req, da, "일치/불일치", fallback), fontsize=8)
        ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")

    legend_codes = [c for c in codes if c in present_codes]
    veg_handles = [Patch(facecolor=VEG_COLORS[c], label=f"{c} {VEG_LABELS[c]}") for c in legend_codes]
    match_handles = [Patch(facecolor=MATCH_COLORS[1], label="일치"), Patch(facecolor=MATCH_COLORS[0], label="불일치")]
    nlegend = min(4, max(1, len(veg_handles + match_handles)))
    fig.legend(
        handles=veg_handles + match_handles, loc="lower center",
        bbox_to_anchor=(0.5, 0.025), ncol=nlegend, fontsize=8.5,
        frameon=False, columnspacing=1.4, handletextpad=0.5,
    )
    fig.suptitle("식생유형", fontsize=15, y=0.985)
    out = Path(report_dir) / "03_vegetation_maps.png"
    fig.savefig(out, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return out


def _read_timeseries(static_dir: Path, dynamic_dir: Path) -> pd.DataFrame:
    frames = []
    for case_dir, label in ((dynamic_dir, "동적모델"), (static_dir, "정적모델")):
        p = Path(case_dir) / "summary_timeseries.csv"
        if not p.exists():
            raise FileNotFoundError(f"summary_timeseries.csv가 없습니다: {p}")
        d = pd.read_csv(p)
        d["case_label"] = label
        d["yr_bp"] = d["ka_bp"].astype(float) * 1000.0
        frames.append(d)
    return pd.concat(frames, ignore_index=True)


def _make_mean_series(ts: pd.DataFrame, col: str, title: str, ylabel: str, out: Path) -> Path:
    setup_korean_matplotlib()
    import matplotlib.pyplot as plt
    from matplotlib.ticker import ScalarFormatter

    dynamic = ts[ts["case_label"] == "동적모델"].sort_values("ka_bp", ascending=False)
    static = ts[ts["case_label"] == "정적모델"].sort_values("ka_bp", ascending=False)

    fig, ax1 = plt.subplots(figsize=(8.2, 4.8))
    dynamic_line, = ax1.plot(
        dynamic["ka_bp"], dynamic[col],
        color="firebrick", linewidth=1.6, linestyle="-", label="동적모델"
    )
    ax1.set_xlabel("연대 (ka BP)")
    ax1.set_ylabel(ylabel)
    ax1.set_xlim(21, 0)
    ax1.set_xticks(np.arange(21, -0.1, -3))

    static_line, = ax1.plot(
        static["ka_bp"], static[col],
        color="royalblue", linewidth=1.4, linestyle="-", label="정적모델"
    )
    if col == "mean_elevation_m":
        formatter = ScalarFormatter(useOffset=False)
        formatter.set_scientific(False)
        ax1.yaxis.set_major_formatter(formatter)

    ax1.legend(
        [dynamic_line, static_line], ["동적모델", "정적모델"],
        loc="upper left", frameon=False
    )
    fig.tight_layout()
    fig.savefig(out, dpi=600, bbox_inches="tight")
    plt.close(fig)
    return out


def _parse_class_counts(text: object) -> Dict[int, float]:
    out = {c: 0.0 for c in VEG_LABELS}
    for token in str(text).split(";"):
        token = token.strip()
        if not token or ":" not in token:
            continue
        k, v = token.split(":", 1)
        try:
            kk, vv = int(float(k)), float(v)
        except Exception:
            continue
        if kk in out:
            out[kk] = vv
    return out


def _make_vegetation_ratio(ts: pd.DataFrame, out: Path) -> Path:
    setup_korean_matplotlib()
    import matplotlib.pyplot as plt

    cases = ["동적모델", "정적모델"]
    rows = []
    for _, r in ts.iterrows():
        n = float(r.get("n_cells", np.nan))
        counts = _parse_class_counts(r.get("vegetation_class_counts", ""))
        for c, v in counts.items():
            rows.append({"case_label": r["case_label"], "yr_bp": float(r["yr_bp"]), "code": c,
                         "pct": 100.0 * v / n if np.isfinite(n) and n > 0 else np.nan})
    ratio = pd.DataFrame(rows)
    present = [c for c in VEG_LABELS if float(ratio.loc[ratio["code"] == c, "pct"].fillna(0).max()) > 1e-9]
    if not present:
        present = [0,1,2,3]

    fig, axes = plt.subplots(2, 1, figsize=(10.0, 6.7), sharex=True)
    for ax, label in zip(axes, cases):
        sub = ratio[ratio["case_label"] == label]
        p = sub.pivot_table(index="yr_bp", columns="code", values="pct", aggfunc="mean").sort_index()
        for c in present:
            if c not in p.columns:
                p[c] = 0.0
        p = p[present].fillna(0.0)
        ax.stackplot(p.index.values, [p[c].values for c in present],
                     labels=[VEG_LABELS[c] for c in present],
                     colors=[VEG_COLORS[c] for c in present], alpha=0.88)
        ax.set_title(label, fontsize=11)
        ax.set_ylabel("면적 비율 (%)")
        ax.set_ylim(0,100)
        ax.grid(True, alpha=0.22)
    axes[-1].set_xlabel("시간 (yr BP, 1000년 간격)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles, labels, loc="lower center", bbox_to_anchor=(0.5, 0.02),
        ncol=min(5, max(1, len(labels))), fontsize=9, frameon=True,
        columnspacing=1.3, handletextpad=0.5,
    )
    fig.suptitle("시간에 따른 식생유형 비율", fontsize=15, y=0.985)
    fig.subplots_adjust(left=0.09, right=0.98, bottom=0.13, top=0.90, hspace=0.28)
    fig.savefig(out, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return out


def _load_validation_rows(output_root: Path) -> pd.DataFrame:
    """Load the primary per-output-time palaeovegetation validation table."""
    p = Path(output_root) / "validation_per_output_time_static_dynamic.csv"
    if p.exists():
        d = pd.read_csv(p)
    else:
        pieces = []
        for subdir, label in (("model_static", "정적모델"), ("model_dynamic", "동적모델")):
            q = Path(output_root) / subdir / "validation_per_output_time.csv"
            if q.exists():
                x = pd.read_csv(q)
                if "case_label" not in x.columns:
                    x["case_label"] = label
                pieces.append(x)
        if not pieces:
            return pd.DataFrame()
        d = pd.concat(pieces, ignore_index=True)
    return d


def _validation_per_output_accuracy(output_root: Path) -> pd.DataFrame:
    """Primary PB4Studio validation accuracy.

    Every palaeovegetation-record × model-output-time row is an independent
    evaluation unit.  ``basin_presence_correct`` already contains the model's
    configured basin-presence rule (currently 1% of mapped vegetation cells,
    with no hard cell floor in the Yongneup production configuration).

    This is deliberately *not* a 7-record majority score.
    """
    d = _load_validation_rows(output_root)
    if d.empty or "case_label" not in d.columns:
        return pd.DataFrame()
    correct_col = "basin_presence_correct" if "basin_presence_correct" in d.columns else "correct"
    if correct_col not in d.columns:
        return pd.DataFrame()
    d = d.copy()
    d["_correct"] = pd.to_numeric(d[correct_col], errors="coerce")
    d = d[np.isfinite(d["_correct"])].copy()
    if d.empty:
        return pd.DataFrame()

    summary = d.groupby("case_label", sort=False).agg(
        correct_output_n=("_correct", "sum"),
        output_n=("_correct", "count"),
    ).reset_index()
    summary["correct_output_n"] = summary["correct_output_n"].astype(int)
    summary["output_n"] = summary["output_n"].astype(int)
    summary["accuracy_pct"] = 100.0 * summary["correct_output_n"] / summary["output_n"]

    if "record_id" in d.columns:
        detail = d.groupby(["case_label", "record_id"], sort=False).agg(
            correct_output_n=("_correct", "sum"),
            output_n=("_correct", "count"),
        ).reset_index()
        detail["correct_output_n"] = detail["correct_output_n"].astype(int)
        detail["output_n"] = detail["output_n"].astype(int)
        detail["accuracy_pct"] = 100.0 * detail["correct_output_n"] / detail["output_n"]
    else:
        detail = pd.DataFrame()

    # Preserve the exact rule metadata used by the finished run for the figure
    # caption/manifest, instead of hard-coding a different validation method.
    rule_meta = {}
    for col in ("basin_presence_min_fraction", "basin_presence_min_percent", "basin_presence_rule",
                "validation_denominator", "validation_time_step_yr", "evaluation_unit"):
        if col in d.columns:
            vals = d[col].dropna().unique().tolist()
            if vals:
                rule_meta[col] = vals[0] if len(vals) == 1 else vals
    summary.attrs["detail"] = detail
    summary.attrs["rule_meta"] = rule_meta
    return summary


def _make_validation_accuracy(output_root: Path, report_dir: Path) -> Tuple[Path, Path, Path]:
    setup_korean_matplotlib()
    import matplotlib.pyplot as plt

    summary = _validation_per_output_accuracy(output_root)
    if summary.empty:
        raise FileNotFoundError("고식생 검증 결과를 찾을 수 없습니다.")
    detail = summary.attrs.get("detail", pd.DataFrame())
    rule_meta = summary.attrs.get("rule_meta", {})
    summary_path = Path(report_dir) / "05_paleovegetation_accuracy_per_output_time.csv"
    detail_path = Path(report_dir) / "05_paleovegetation_accuracy_by_record.csv"
    summary.to_csv(summary_path, index=False, encoding="utf-8-sig")
    detail.to_csv(detail_path, index=False, encoding="utf-8-sig")

    order = [x for x in ("동적모델", "정적모델") if x in set(summary["case_label"])]
    summary_plot = summary.set_index("case_label").loc[order].reset_index()
    fig, ax = plt.subplots(figsize=(8.8, 5.3))
    bars = ax.bar(summary_plot["case_label"], summary_plot["accuracy_pct"])
    ax.set_ylim(0, 108)
    ax.set_yticks(np.arange(0, 101, 20))
    ax.set_ylabel("정확도 (%)")
    ax.set_title("동적모델과 정적모델의 고식생 검증 정확도", fontsize=15)
    for bar, (_, r) in zip(bars, summary_plot.iterrows()):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            min(bar.get_height() + 2.0, 103.0),
            f"{int(r.correct_output_n)}/{int(r.output_n)}\n{r.accuracy_pct:.1f}%",
            ha="center", va="bottom", fontsize=11,
        )

    min_pct = rule_meta.get("basin_presence_min_percent")
    step_yr = rule_meta.get("validation_time_step_yr")
    try:
        min_pct_text = f"{float(min_pct):g}%"
    except Exception:
        min_pct_text = "설정된 최소 비율"
    try:
        step_text = f"{float(step_yr):g}년"
    except Exception:
        step_text = "각 출력"
    ax.text(
        0.5, -0.14,
        f"현재 검증법: 고식생 기록 구간의 {step_text} 출력시점을 각각 평가하고, 유역에서 기대 식생이 {min_pct_text} 이상 존재하면 해당 시점을 적중으로 판정",
        ha="center", va="top", transform=ax.transAxes, fontsize=8.5,
    )
    fig.subplots_adjust(left=0.11, right=0.97, bottom=0.20, top=0.88)
    out = Path(report_dir) / "05_paleovegetation_accuracy.png"
    fig.savefig(out, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return out, summary_path, detail_path

def make_standard_report(
    output_root: Path,
    report_dir: Optional[Path] = None,
    ages: Sequence[float] = REPORT_AGES_KA,
    allow_nearest: bool = False,
) -> Dict[str, object]:
    """Generate the seven standard result-board figures from a finished comparison run."""
    output_root = Path(output_root)
    static_dir = output_root / "model_static"
    dynamic_dir = output_root / "model_dynamic"
    if not static_dir.exists() or not dynamic_dir.exists():
        raise FileNotFoundError("표준 결과판은 정적+동적 비교 결과(model_static/model_dynamic)가 필요합니다.")
    report_dir = Path(report_dir) if report_dir is not None else output_root / "standard_report"
    report_dir.mkdir(parents=True, exist_ok=True)

    ts = _read_timeseries(static_dir, dynamic_dir)
    written: List[Path] = []
    written.append(_make_numeric_map_board(static_dir, dynamic_dir, report_dir, "soil_depth_m", "토심 (m)", "YlOrBr", "01_soil_depth_maps.png", ages, allow_nearest))
    written.append(_make_mean_series(ts, "mean_soil_depth_m", "평균 토심 변화", "평균 토심 (m)", report_dir / "02_mean_soil_depth.png"))
    written.append(_make_vegetation_map_board(static_dir, dynamic_dir, report_dir, ages, allow_nearest))
    written.append(_make_vegetation_ratio(ts, report_dir / "04_vegetation_ratio.png"))
    acc_png, acc_summary, acc_detail = _make_validation_accuracy(output_root, report_dir)
    written.append(acc_png)
    written.append(_make_numeric_map_board(static_dir, dynamic_dir, report_dir, "elevation_m", "고도 (m)", "viridis", "06_elevation_maps.png", ages, allow_nearest))
    written.append(_make_mean_series(ts, "mean_elevation_m", "평균 고도 변화", "평균 고도 (m)", report_dir / "07_mean_elevation.png"))

    manifest = {
        "output_root": str(output_root.resolve()),
        "report_dir": str(report_dir.resolve()),
        "requested_snapshot_ages_ka": [float(x) for x in ages],
        "allow_nearest_snapshot_fallback": bool(allow_nearest),
        "figures": [p.name for p in written],
        "validation_per_output_time_summary_csv": acc_summary.name,
        "validation_by_record_detail_csv": acc_detail.name,
        "validation_note": "Primary accuracy = correct palaeovegetation-record × 100-year model-output-time rows / all evaluated rows, using each row's configured basin_presence_correct rule (Yongneup production: expected vegetation present in >=1% of mapped vegetation cells).",
    }
    (report_dir / "STANDARD_REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"report_dir": str(report_dir), "figures": [str(p) for p in written], "manifest": manifest}
