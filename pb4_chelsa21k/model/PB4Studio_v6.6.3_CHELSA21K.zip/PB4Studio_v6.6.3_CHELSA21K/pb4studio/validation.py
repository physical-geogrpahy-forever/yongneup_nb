"""
validation.py — 고식생 검증.

고식생 검증은 사용자가 선택한 두 가지 정확도 산정법 중 하나를 사용한다.

1. ``per_output_time``: palaeovegetation 연대구간에 포함되는 **각 모델 출력시점(dt)**을
   평가단위로 사용한다. 기본 모의 출력간격이 0.1 kyr이면 100년 시간단위
   일치율(time-step agreement rate)이다.
2. ``interval_any_dt``: 각 palaeovegetation **연대구간**을 평가단위로 사용하고,
   그 구간 안의 출력시점 중 최소 한 번이라도 관측 식생유형이 지정 점유율 이상
   나타나면 해당 구간을 일치로 판정한다.

두 방법 모두 각 dt에서 관측 식생유형이 유효식생 셀의 지정 비율 이상을 차지하는지
동일한 공간 기준을 사용한다. 출력시점별 방법의 시점들은 서로 독립된 고식생
관측표본이라고 해석하지 않는다.

구간별 시간가중 평균 유역면적비율은 별도의 보조 진단으로 계속 계산·저장한다. 구간
경계가 모델 출력시점과 일치하지 않으면 인접 출력의 면적비율을 선형보간하고
사다리꼴 적분을 적용한다.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, List

import numpy as np
import pandas as pd
import rasterio


def _parse_accepted_reduced_codes(row: pd.Series) -> list[int]:
    """Parse the accepted reduced KBIOME codes stored in one validation row."""
    if "accepted_reduced_codes" in row.index and pd.notna(row["accepted_reduced_codes"]):
        raw = str(row["accepted_reduced_codes"]).replace(",", ";")
        codes: list[int] = []
        for token in raw.split(";"):
            token = token.strip()
            if token:
                codes.append(int(float(token)))
        if codes:
            return codes
    return [int(float(row["expected_vegetation_code"]))]
def _load_time_aware_validation_records(
    validation_points_csv: Path,
    model_times_ka: Iterable[float],
    validation_time_step_kyr: float = 1.0,
    target_crs=None,
    basin_bounds_target_crs=None,
) -> list[dict]:
    """Load validation intervals and attach every model output inside each interval.

    검증 CSV는 두 가지 좌표 방식 중 하나를 가질 수 있다:
      1) x_5187/y_5187 (또는 x/y) — 이미 특정 투영좌표계로 준비된 경우.
      2) latitude_dd/longitude_dd — 위경도를 현재 DEM 좌표계로 재투영한다.

    각 고식생 연대구간 안의 모델 출력시점은 ``interval_model_times_ka``에 저장하고,
    구간 경계 보간에 필요한 인접 시점까지 ``integration_model_times_ka``에 저장한다.
    이 시점들은 시간적분 support point이며 서로 독립된 검증표본이 아니다. 구간이
    모델 시간범위와 부분적으로만 겹치면 실제 커버된 기간과 비율을 결과에 기록한다.
    """
    val_path = Path(validation_points_csv)
    if not val_path.exists():
        return []

    val = pd.read_csv(val_path)

    if "x_5187" in val.columns and "y_5187" in val.columns:
        x_col, y_col = "x_5187", "y_5187"
    elif "x" in val.columns and "y" in val.columns:
        x_col, y_col = "x", "y"
    elif "longitude_dd" in val.columns and "latitude_dd" in val.columns:
        if target_crs is None:
            raise ValueError("검증 CSV가 위경도만 갖고 있어 재투영이 필요한데 target_crs가 주어지지 않았습니다.")
        from rasterio.warp import transform as warp_transform
        xs, ys = warp_transform(
            "EPSG:4326", target_crs,
            val["longitude_dd"].astype(float).tolist(), val["latitude_dd"].astype(float).tolist(),
        )
        val = val.copy()
        val["x"] = xs
        val["y"] = ys
        x_col, y_col = "x", "y"
    else:
        raise ValueError("검증 CSV에 좌표 컬럼이 없습니다 (x_5187/y_5187, x/y, latitude_dd/longitude_dd 중 하나 필요).")

    required = {"record_id", "site_id", x_col, y_col, "age_start_ka_bp", "age_end_ka_bp", "expected_vegetation_code"}
    missing = required.difference(val.columns)
    if missing:
        raise ValueError(f"Validation CSV is missing required columns: {sorted(missing)}")

    if basin_bounds_target_crs is not None:
        minx, miny, maxx, maxy = basin_bounds_target_crs
        pad = 5000.0
        in_range = (
            (val[x_col] >= minx - pad) & (val[x_col] <= maxx + pad)
            & (val[y_col] >= miny - pad) & (val[y_col] <= maxy + pad)
        )
        val = val[in_range]
        if val.empty:
            return []

    # Preserve the model execution order (normally old -> young) while removing
    # accidental duplicate output times.
    times_in_run_order: list[float] = []
    for raw_time in model_times_ka:
        t = float(raw_time)
        if not any(abs(t - old) <= 1e-9 for old in times_in_run_order):
            times_in_run_order.append(t)
    if not times_in_run_order:
        return []

    times = np.asarray(times_in_run_order, dtype="float64")
    validation_time_step_kyr = max(float(validation_time_step_kyr), 1e-6)
    records: list[dict] = []
    for _, row in val.iterrows():
        age_start = float(row["age_start_ka_bp"])
        age_end = float(row["age_end_ka_bp"])
        age_old = max(age_start, age_end)
        age_young = min(age_start, age_end)
        age_mid = (
            float(row["age_mid_ka_bp"])
            if "age_mid_ka_bp" in row.index and pd.notna(row["age_mid_ka_bp"])
            else 0.5 * (age_start + age_end)
        )

        interval_times = [
            float(t) for t in times_in_run_order
            if age_young - 1e-9 <= float(t) <= age_old + 1e-9
        ]

        # Primary validation integrates the basin-area fraction over the full
        # palaeo interval.  To interpolate an interval boundary that falls between
        # model outputs we also retain the nearest bracketing output on each side.
        older_brackets = [float(t) for t in times_in_run_order if float(t) > age_old + 1e-9]
        younger_brackets = [float(t) for t in times_in_run_order if float(t) < age_young - 1e-9]
        integration_times = list(interval_times)
        if older_brackets:
            integration_times.append(min(older_brackets))
        if younger_brackets:
            integration_times.append(max(younger_brackets))
        # Preserve model execution order and remove duplicates.
        integration_times = [
            float(t) for t in times_in_run_order
            if any(abs(float(t) - u) <= 1e-9 for u in integration_times)
        ]

        model_min_ka = float(np.nanmin(times))
        model_max_ka = float(np.nanmax(times))
        # Completely out-of-period records remain excluded.
        if age_old < model_min_ka - 1e-9 or age_young > model_max_ka + 1e-9:
            continue

        # Keep the old midpoint-grid diagnostics for backward-compatible output.
        validation_grid_ka = math.floor(age_mid / validation_time_step_kyr + 0.5) * validation_time_step_kyr
        target_ka = float(times[np.argmin(np.abs(times - age_mid))])

        # A palaeo-interval narrower than the output interval may contain no
        # literal model snapshot. Do not substitute an out-of-interval nearest
        # snapshot: only actual outputs inside the closed age interval are valid
        # per-time validation items.
        temporal_fallback_used = False

        primary = int(float(row["expected_vegetation_code"]))
        accepted = _parse_accepted_reduced_codes(row)
        records.append({
            "record_id": str(row["record_id"]),
            "validation_id": row.get("validation_id", ""),
            "site_id": str(row["site_id"]),
            "site_name": row.get("site_name", row["site_id"]),
            "x_5187": float(row[x_col]),
            "y_5187": float(row[y_col]),
            "latitude_dms": row.get("latitude_dms", ""),
            "longitude_dms": row.get("longitude_dms", ""),
            "age_start_ka_bp": age_start,
            "age_end_ka_bp": age_end,
            "age_mid_ka_bp": age_mid,
            "validation_time_step_kyr": validation_time_step_kyr,
            "validation_grid_ka_bp": validation_grid_ka,
            "target_model_ka_bp": target_ka,
            "interval_model_times_ka": interval_times,
            "integration_model_times_ka": integration_times,
            "temporal_fallback_used": temporal_fallback_used,
            "temporal_fallback_reason": "",
            "vegetation_original_ko": row.get("vegetation_original_ko", ""),
            "expected_vegetation_code": primary,
            "accepted_reduced_codes": accepted,
            "accepted_reduced_labels": row.get("accepted_reduced_labels", ""),
            "source_short": row.get("source_short", ""),
            "doi_or_url": row.get("doi_or_url", ""),
            "notes": row.get("notes", ""),
        })
    return records


def _format_time_list(values: Iterable[float]) -> str:
    """Format model ages compactly and deterministically for CSV output."""
    return ";".join(f"{float(v):g}" for v in values)


def _sample_validation_records_for_step(
    validation_records: list[dict],
    resolution_m: int,
    ka_bp: float,
    veg_code: np.ndarray,
    transform,
    nodata_value: int = -999,
    basin_presence_min_fraction: float = 0.01,
    basin_mask: np.ndarray | None = None,
) -> list[dict]:
    """Collect one basin-area-fraction row for time-step validation and interval diagnostics.

    A row is emitted for every model output inside a palaeo-record interval and,
    additionally, for the nearest bracketing outputs needed by the optional interval
    integration diagnostic.  The primary time-step quantity is the *sum* of the basin
    fractions of all accepted reduced vegetation codes.
    """
    del transform, nodata_value  # Kept in the signature for runner/API compatibility.

    code_to_label = {
        -1: "unassigned",
        0: "conifer_forest",
        1: "deciduous_broadleaf_forest",
        2: "mixed_forest",
        3: "herbaceous",
    }
    veg_float = np.asarray(veg_code, dtype="float32")
    if basin_mask is None:
        basin = np.ones(veg_float.shape, dtype=bool)
    else:
        basin = np.asarray(basin_mask, dtype=bool)
        if basin.shape != veg_float.shape:
            raise ValueError("basin_mask shape must match veg_code")

    # Primary Yongneup validation denominator: mapped vegetation classes 0--3.
    # Explicit class 4 (non-vegetated/bare) remains visible in maps but is excluded
    # from the vegetation-presence denominator, matching the finalized Jang-2011
    # 1% basin-presence calculation (62 output-time evaluations).
    validation_valid = basin & np.isfinite(veg_float) & np.isin(veg_float, [0.0, 1.0, 2.0, 3.0])
    valid_basin_cells = int(np.sum(validation_valid))
    presence_fraction = min(1.0, max(0.0, float(basin_presence_min_fraction)))
    hard_min_cells = 0
    equivalent_required_cells = (
        int(math.ceil(presence_fraction * valid_basin_cells - 1e-12))
        if presence_fraction > 0.0 and valid_basin_cells > 0 else 0
    )
    basin_counts = {c: int(np.sum(basin & (veg_float == float(c)))) for c in (0, 1, 2, 3, 4)}
    nonvegetated_basin_cells = int(basin_counts.get(4, 0))
    unclassified_basin_cells = int(np.sum(basin & ~np.isfinite(veg_float)))

    rows: list[dict] = []
    for rec in validation_records:
        support_times = [float(t) for t in rec.get("integration_model_times_ka", rec.get("interval_model_times_ka", []))]
        if not any(abs(float(ka_bp) - t) <= 1e-9 for t in support_times):
            continue

        accepted = sorted(set(int(v) for v in rec["accepted_reduced_codes"]))
        primary = int(rec["expected_vegetation_code"])
        accepted_counts = {int(v): int(basin_counts.get(int(v), 0)) for v in accepted}
        accepted_sum_count = int(sum(accepted_counts.values()))
        accepted_sum_fraction = (
            float(accepted_sum_count) / float(valid_basin_cells)
            if valid_basin_cells > 0 else 0.0
        )
        best_basin_count = int(max(accepted_counts.values())) if accepted_counts else 0
        best_basin_fraction = (
            float(best_basin_count) / float(valid_basin_cells)
            if valid_basin_cells > 0 else 0.0
        )
        diagnostic_present = int(
            valid_basin_cells > 0
            and accepted_sum_fraction + 1e-15 >= presence_fraction
        )
        interval_times = [float(t) for t in rec.get("interval_model_times_ka", [])]
        inside_interval = int(any(abs(float(ka_bp) - t) <= 1e-9 for t in interval_times))

        rows.append({
            "resolution_m": int(resolution_m),
            "validation_buffer_m": np.nan,
            "sampling_method": "basin_area_fraction_integration_support",
            "temporal_matching_method": "interval_integration_support",
            "temporal_fallback_used": 0,
            "temporal_fallback_reason": "",
            "basin_presence_rule": "minimum_fraction_no_hard_cell_floor",
            "validation_denominator": "mapped_vegetation_classes_0_3",
            "basin_presence_min_fraction": presence_fraction,
            "basin_presence_min_percent": presence_fraction * 100.0,
            "basin_presence_min_cells": hard_min_cells,
            "basin_presence_hard_min_cells": hard_min_cells,
            "basin_presence_equivalent_required_cells": equivalent_required_cells,
            "valid_basin_cell_count": valid_basin_cells,
            "basin_cell_count": int(np.sum(basin)),
            "basin_nonvegetated_cell_count": nonvegetated_basin_cells,
            "basin_unclassified_cell_count": unclassified_basin_cells,
            "record_id": rec["record_id"],
            "validation_id": rec["validation_id"],
            "site_id": rec["site_id"],
            "site_name": rec["site_name"],
            "x_5187": float(rec["x_5187"]),
            "y_5187": float(rec["y_5187"]),
            "age_start_ka_bp": rec["age_start_ka_bp"],
            "age_end_ka_bp": rec["age_end_ka_bp"],
            "age_mid_ka_bp": rec["age_mid_ka_bp"],
            "validation_time_step_kyr": rec.get("validation_time_step_kyr", 1.0),
            "validation_time_step_yr": float(rec.get("validation_time_step_kyr", 1.0)) * 1000.0,
            "validation_grid_ka_bp": rec.get("validation_grid_ka_bp", rec["target_model_ka_bp"]),
            "interval_model_time_count": len(interval_times),
            "interval_model_times_ka_bp": _format_time_list(interval_times),
            "integration_support_time_count": len(support_times),
            "integration_support_times_ka_bp": _format_time_list(support_times),
            "model_ka_bp": float(ka_bp),
            "inside_palaeo_interval": inside_interval,
            "validation_item_id": f"{rec['record_id']}@{float(ka_bp):g}ka",
            "evaluation_unit": "palaeo_record_x_model_output_time_diagnostic",
            "age_mid_to_model_time_abs_diff_kyr": abs(float(rec["age_mid_ka_bp"]) - float(ka_bp)),
            "vegetation_original_ko": rec["vegetation_original_ko"],
            "expected_vegetation_code": primary,
            "expected_label": code_to_label.get(primary, str(primary)),
            "accepted_reduced_codes": ";".join(str(v) for v in accepted),
            "accepted_reduced_labels": rec["accepted_reduced_labels"] or ";".join(
                code_to_label.get(v, str(v)) for v in accepted
            ),
            "basin_count_conifer": basin_counts.get(0, 0),
            "basin_count_broadleaf": basin_counts.get(1, 0),
            "basin_count_mixed": basin_counts.get(2, 0),
            "basin_count_herbaceous": basin_counts.get(3, 0),
            "basin_count_nonvegetated": basin_counts.get(4, 0),
            "accepted_class_basin_cell_count_sum": accepted_sum_count,
            "accepted_class_basin_fraction_sum": accepted_sum_fraction,
            "accepted_class_basin_percent_sum": accepted_sum_fraction * 100.0,
            # Retain the previous max fields for old diagnostic scripts.
            "accepted_class_basin_cell_count_max": best_basin_count,
            "accepted_class_basin_fraction_max": best_basin_fraction,
            "accepted_class_basin_percent_max": best_basin_fraction * 100.0,
            "accepted_class_basin_cell_counts": ";".join(f"{k}:{v}" for k, v in accepted_counts.items()),
            "basin_presence_correct": diagnostic_present,
            "correct": diagnostic_present,
            "source_short": rec["source_short"],
            "doi_or_url": rec["doi_or_url"],
            "notes": rec["notes"],
        })
    return rows


def finalize_per_output_validation_rows(step_rows: list[dict]) -> list[dict]:
    """Return the primary *in-interval* model-output validation rows.

    Bracketing support points used solely for interval interpolation are excluded.
    With the default 0.1-kyr model interval, each row is one 100-year evaluation
    time step.  These rows are repeated temporal evaluations within palaeo records,
    not independent palaeovegetation observations.
    """
    out: list[dict] = []
    for raw in step_rows:
        if int(raw.get("inside_palaeo_interval", 1)) != 1:
            continue
        row = dict(raw)
        row["sampling_method"] = "basin_presence_fraction_per_output_time"
        row["temporal_matching_method"] = "per_output_time_exact_interval"
        row["evaluation_unit"] = "palaeo_record_x_model_output_time"
        out.append(row)
    return out


def _linear_interval_average(
    model_ages_ka: np.ndarray,
    fractions: np.ndarray,
    age_young_ka: float,
    age_old_ka: float,
) -> tuple[float, float, float, list[float], list[float]]:
    """Integrate a fraction curve over one palaeo interval.

    The fraction is linearly interpolated between model outputs.  Integration is
    performed only over the overlap between the palaeo interval and the support
    time range.  Returns (mean_fraction, covered_duration, requested_duration,
    knot_ages, knot_fractions).
    """
    x = np.asarray(model_ages_ka, dtype="float64")
    y = np.asarray(fractions, dtype="float64")
    finite = np.isfinite(x) & np.isfinite(y)
    x, y = x[finite], y[finite]
    if x.size == 0:
        return float("nan"), 0.0, max(float(age_old_ka) - float(age_young_ka), 0.0), [], []

    # Average accidental duplicate snapshots, then sort from young -> old for np.interp.
    df = pd.DataFrame({"x": x, "y": y}).groupby("x", as_index=False, sort=True)["y"].mean()
    x = df["x"].to_numpy(dtype="float64")
    y = df["y"].to_numpy(dtype="float64")
    requested_duration = max(float(age_old_ka) - float(age_young_ka), 0.0)
    lo = max(float(age_young_ka), float(np.min(x)))
    hi = min(float(age_old_ka), float(np.max(x)))
    if hi <= lo + 1e-15:
        return float("nan"), 0.0, requested_duration, [], []

    inner = x[(x > lo + 1e-12) & (x < hi - 1e-12)]
    knots = np.unique(np.concatenate(([lo], inner, [hi]))).astype("float64")
    vals = np.interp(knots, x, y)
    covered_duration = float(hi - lo)
    if knots.size == 1 or covered_duration <= 0.0:
        mean_fraction = float(vals[0]) if vals.size else float("nan")
    else:
        if hasattr(np, "trapezoid"):
            integral = float(np.trapezoid(vals, knots))
        else:  # NumPy < 2.0 compatibility for older Windows builds.
            integral = float(np.trapz(vals, knots))
        mean_fraction = integral / covered_duration
    return mean_fraction, covered_duration, requested_duration, knots.tolist(), vals.tolist()


def aggregate_interval_validation_rows(step_rows: list[dict]) -> list[dict]:
    """Collapse model-output support rows to one primary row per palaeo record.

    Primary metric = time-weighted mean basin area fraction (%) of the observed
    vegetation type over the record's full age interval.  Each palaeo record has
    equal status regardless of its duration or the number of 100-year outputs.
    """
    if not step_rows:
        return []

    df = pd.DataFrame(step_rows)
    key_cols = [c for c in ("case", "record_id") if c in df.columns]
    if "record_id" not in key_cols:
        key_cols.append("record_id")

    rows: list[dict] = []
    for _, grp in df.groupby(key_cols, sort=False, dropna=False):
        grp = grp.copy()
        first = grp.iloc[0]
        age_start = float(first["age_start_ka_bp"])
        age_end = float(first["age_end_ka_bp"])
        age_old = max(age_start, age_end)
        age_young = min(age_start, age_end)
        frac_col = (
            "accepted_class_basin_fraction_sum"
            if "accepted_class_basin_fraction_sum" in grp.columns
            else "accepted_class_basin_fraction_max"
        )
        mean_fraction, covered, requested, knots, vals = _linear_interval_average(
            pd.to_numeric(grp["model_ka_bp"], errors="coerce").to_numpy(),
            pd.to_numeric(grp[frac_col], errors="coerce").to_numpy(),
            age_young, age_old,
        )
        coverage_fraction = covered / requested if requested > 0.0 else float("nan")

        # Diagnostics over literal in-interval output points (not a validation N).
        inside = grp[pd.to_numeric(grp.get("inside_palaeo_interval", 1), errors="coerce").fillna(0).astype(int) == 1]
        literal_values = pd.to_numeric(inside[frac_col], errors="coerce").dropna()

        row = {
            "resolution_m": int(first["resolution_m"]),
            "validation_buffer_m": first.get("validation_buffer_m", np.nan),
            "sampling_method": "time_weighted_mean_basin_area_fraction_by_palaeo_interval",
            "temporal_matching_method": "piecewise_linear_interpolation_trapezoidal_integration",
            "evaluation_unit": "palaeo_record_interval",
            "record_id": first["record_id"],
            "validation_id": first.get("validation_id", ""),
            "site_id": first.get("site_id", ""),
            "site_name": first.get("site_name", ""),
            "x_5187": first.get("x_5187", np.nan),
            "y_5187": first.get("y_5187", np.nan),
            "age_start_ka_bp": age_start,
            "age_end_ka_bp": age_end,
            "age_mid_ka_bp": first.get("age_mid_ka_bp", 0.5 * (age_start + age_end)),
            "interval_duration_kyr": requested,
            "covered_duration_kyr": covered,
            "temporal_coverage_fraction": coverage_fraction,
            "temporal_coverage_percent": coverage_fraction * 100.0 if np.isfinite(coverage_fraction) else np.nan,
            "integration_support_time_count": int(pd.to_numeric(grp["model_ka_bp"], errors="coerce").dropna().nunique()),
            "integration_support_times_ka_bp": _format_time_list(
                pd.to_numeric(grp["model_ka_bp"], errors="coerce").dropna().astype(float).tolist()
            ),
            "integration_knot_times_ka_bp": _format_time_list(knots),
            "integration_knot_fractions": _format_time_list(vals),
            "literal_in_interval_output_count": int(len(inside)),
            "vegetation_original_ko": first.get("vegetation_original_ko", ""),
            "expected_vegetation_code": int(first["expected_vegetation_code"]),
            "expected_label": first.get("expected_label", ""),
            "accepted_reduced_codes": first.get("accepted_reduced_codes", ""),
            "accepted_reduced_labels": first.get("accepted_reduced_labels", ""),
            "time_weighted_mean_basin_fraction": mean_fraction,
            "time_weighted_mean_basin_percent": mean_fraction * 100.0 if np.isfinite(mean_fraction) else np.nan,
            "literal_output_fraction_min": float(literal_values.min()) if len(literal_values) else np.nan,
            "literal_output_fraction_max": float(literal_values.max()) if len(literal_values) else np.nan,
            "literal_output_fraction_mean_unweighted": float(literal_values.mean()) if len(literal_values) else np.nan,
            "diagnostic_threshold_fraction": float(first.get("basin_presence_min_fraction", np.nan)),
            "diagnostic_threshold_percent": float(first.get("basin_presence_min_percent", np.nan)),
            "source_short": first.get("source_short", ""),
            "doi_or_url": first.get("doi_or_url", ""),
            "notes": first.get("notes", ""),
        }
        for c in ("case", "case_label", "geomorph_dynamic"):
            if c in grp.columns:
                row[c] = first.get(c)
        rows.append(row)
    return rows


def compute_interval_summary_table(validation_rows_by_case: Dict[str, list]) -> pd.DataFrame:
    """Equal-record summary of the primary interval-area-fraction metric."""
    rows = []
    for case_label, records in validation_rows_by_case.items():
        if not records:
            continue
        df = pd.DataFrame(records)
        vals = pd.to_numeric(df["time_weighted_mean_basin_percent"], errors="coerce").dropna()
        coverage = pd.to_numeric(df.get("temporal_coverage_percent", np.nan), errors="coerce")
        rows.append({
            "case_label": case_label,
            "primary_validation_method": "time_weighted_mean_basin_area_fraction_by_palaeo_interval",
            "n_palaeo_records": int(len(vals)),
            "equal_record_mean_percent": float(vals.mean()) if len(vals) else np.nan,
            "median_record_percent": float(vals.median()) if len(vals) else np.nan,
            "min_record_percent": float(vals.min()) if len(vals) else np.nan,
            "max_record_percent": float(vals.max()) if len(vals) else np.nan,
            "mean_temporal_coverage_percent": float(coverage.mean()) if hasattr(coverage, "mean") else np.nan,
        })
    return pd.DataFrame(rows)


def _accuracy_rows_for_threshold(
    validation_rows_by_case: Dict[str, list],
    threshold_fraction: float,
) -> list[dict]:
    """Summarize per-output agreement for one basin-area threshold."""
    threshold = min(1.0, max(0.0, float(threshold_fraction)))
    rows: list[dict] = []
    for case_label, records in validation_rows_by_case.items():
        if not records:
            continue
        df = pd.DataFrame(records)
        if "accepted_class_basin_fraction_sum" in df.columns:
            frac = pd.to_numeric(df["accepted_class_basin_fraction_sum"], errors="coerce")
            arr = frac.to_numpy(dtype="float64")
            finite = np.isfinite(arr)
            n = int(np.sum(finite))
            correct_mask = finite & (arr + 1e-15 >= threshold)
            correct_n = int(np.sum(correct_mask))
        elif "accepted_class_basin_fraction_max" in df.columns:
            frac = pd.to_numeric(df["accepted_class_basin_fraction_max"], errors="coerce")
            arr = frac.to_numpy(dtype="float64")
            finite = np.isfinite(arr)
            n = int(np.sum(finite))
            correct_mask = finite & (arr + 1e-15 >= threshold)
            correct_n = int(np.sum(correct_mask))
        else:
            # Backward compatibility for already-finalized historical rows that
            # retained only the configured-threshold correct flag.
            source = df["basin_presence_correct"] if "basin_presence_correct" in df.columns else df.get("correct", 0)
            flags = pd.to_numeric(source, errors="coerce").fillna(0).to_numpy(dtype="float64")
            finite = np.isfinite(flags)
            n = int(np.sum(finite))
            correct_n = int(np.sum(flags[finite] >= 0.5))
        accuracy_pct = float(correct_n) / float(n) * 100.0 if n else float("nan")
        n_records = int(df.loc[finite, "record_id"].astype(str).nunique()) if "record_id" in df.columns else 0
        rows.append({
            "case_label": case_label,
            "primary_accuracy_method": "basin_presence_fraction_per_output_time",
            "validation_role": "primary_time_step_agreement",
            "evaluation_unit": "palaeo_record_x_model_output_time",
            "basin_presence_min_fraction": threshold,
            "basin_presence_min_percent": threshold * 100.0,
            "n_palaeo_records": n_records,
            "n_time_steps": n,
            "correct_n": correct_n,
            "accuracy_pct": accuracy_pct,
            # Backward-compatible aliases.
            "n": n,
            "basin_presence_correct_n": correct_n,
            "basin_presence_accuracy_pct": accuracy_pct,
        })
    return rows


def compute_accuracy_table(
    validation_rows_by_case: Dict[str, list],
    threshold_fraction: float | None = None,
) -> pd.DataFrame:
    """Primary per-output time-step agreement summary for one threshold.

    If ``threshold_fraction`` is omitted, the first row's configured threshold is
    used for backward compatibility.
    """
    if threshold_fraction is None:
        threshold_fraction = _configured_threshold_from_rows(validation_rows_by_case)
    return pd.DataFrame(_accuracy_rows_for_threshold(validation_rows_by_case, threshold_fraction))



def _configured_threshold_from_rows(validation_rows_by_case: Dict[str, list], default: float = 0.01) -> float:
    """Return the configured basin-area threshold embedded in validation rows."""
    threshold = float(default)
    for records in validation_rows_by_case.values():
        if not records:
            continue
        raw = records[0].get("basin_presence_min_fraction", default)
        try:
            threshold = float(raw)
        except (TypeError, ValueError):
            threshold = float(default)
        break
    return min(1.0, max(0.0, threshold))


def _fraction_series(df: pd.DataFrame) -> pd.Series:
    """Return the accepted vegetation fraction from current or legacy rows."""
    if "accepted_class_basin_fraction_sum" in df.columns:
        return pd.to_numeric(df["accepted_class_basin_fraction_sum"], errors="coerce")
    if "accepted_class_basin_fraction_max" in df.columns:
        return pd.to_numeric(df["accepted_class_basin_fraction_max"], errors="coerce")
    source = df["basin_presence_correct"] if "basin_presence_correct" in df.columns else df.get("correct", 0)
    return pd.to_numeric(source, errors="coerce")


def compute_interval_any_accuracy_table(
    validation_rows_by_case: Dict[str, list],
    threshold_fraction: float | None = None,
) -> pd.DataFrame:
    """Accuracy by palaeo interval: hit if any in-interval model dt reaches threshold.

    Each palaeovegetation record contributes exactly one denominator unit. A record is
    correct when at least one literal model output inside its age interval has an accepted
    vegetation fraction greater than or equal to ``threshold_fraction``. Bracketing rows
    are not present in the finalized per-output table and therefore cannot create a hit.
    """
    if threshold_fraction is None:
        threshold_fraction = _configured_threshold_from_rows(validation_rows_by_case)
    threshold = min(1.0, max(0.0, float(threshold_fraction)))
    rows: list[dict] = []
    for case_label, records in validation_rows_by_case.items():
        if not records:
            continue
        df = pd.DataFrame(records).copy()
        if "record_id" not in df.columns:
            continue
        frac = _fraction_series(df)
        df["_fraction"] = frac
        df = df[np.isfinite(pd.to_numeric(df["_fraction"], errors="coerce"))].copy()
        if df.empty:
            continue
        record_hits = df.groupby(df["record_id"].astype(str), sort=False)["_fraction"].apply(
            lambda x: bool(np.any(pd.to_numeric(x, errors="coerce").to_numpy(dtype="float64") + 1e-15 >= threshold))
        )
        n_records = int(len(record_hits))
        correct_n = int(record_hits.sum())
        accuracy_pct = float(correct_n) / float(n_records) * 100.0 if n_records else float("nan")
        rows.append({
            "case_label": case_label,
            "primary_accuracy_method": "interval_any_dt",
            "validation_role": "palaeo_interval_any_dt_agreement",
            "evaluation_unit": "palaeo_record",
            "basin_presence_min_fraction": threshold,
            "basin_presence_min_percent": threshold * 100.0,
            "n_palaeo_records": n_records,
            "n_time_steps": int(len(df)),
            "correct_n": correct_n,
            "accuracy_pct": accuracy_pct,
            "n": n_records,
            "basin_presence_correct_n": correct_n,
            "basin_presence_accuracy_pct": accuracy_pct,
        })
    return pd.DataFrame(rows)


def compute_selected_accuracy_table(
    validation_rows_by_case: Dict[str, list],
    method: str = "per_output_time",
    threshold_fraction: float | None = None,
) -> pd.DataFrame:
    """Dispatch the user-selected palaeovegetation accuracy method."""
    method = str(method or "per_output_time")
    if method == "per_output_time":
        return compute_accuracy_table(validation_rows_by_case, threshold_fraction)
    if method == "interval_any_dt":
        return compute_interval_any_accuracy_table(validation_rows_by_case, threshold_fraction)
    raise ValueError(f"알 수 없는 고식생 정확도 측정 방법입니다: {method}")

def compute_accuracy_sensitivity_table(
    validation_rows_by_case: Dict[str, list],
    threshold_fractions: Iterable[float] = (0.01, 0.05, 0.10),
) -> pd.DataFrame:
    """Return primary time-step agreement at 1/5/10% (or supplied) thresholds."""
    thresholds: list[float] = []
    for raw in threshold_fractions:
        value = min(1.0, max(0.0, float(raw)))
        if not any(abs(value - old) <= 1e-12 for old in thresholds):
            thresholds.append(value)
    rows: list[dict] = []
    for threshold in thresholds:
        rows.extend(_accuracy_rows_for_threshold(validation_rows_by_case, threshold))
    return pd.DataFrame(rows)


def make_accuracy_sensitivity_chart(accuracy_df: pd.DataFrame, output_path: Path) -> None:
    """Grouped bar chart of 100-year time-step agreement across thresholds."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    setup_korean_matplotlib()

    if accuracy_df.empty:
        return
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df = accuracy_df.copy()
    thresholds = list(dict.fromkeys(pd.to_numeric(df["basin_presence_min_percent"], errors="coerce").dropna().tolist()))
    cases = list(dict.fromkeys(df["case_label"].astype(str).tolist()))
    x = np.arange(len(thresholds), dtype="float64")
    width = 0.8 / max(len(cases), 1)
    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    for j, case in enumerate(cases):
        sub = df[df["case_label"].astype(str) == case]
        vals = []
        labels = []
        for thr in thresholds:
            hit = sub[np.isclose(pd.to_numeric(sub["basin_presence_min_percent"], errors="coerce"), float(thr))]
            if hit.empty:
                vals.append(np.nan); labels.append("")
            else:
                row = hit.iloc[0]
                vals.append(float(row["accuracy_pct"]))
                labels.append(f"{int(row['correct_n'])}/{int(row['n_time_steps'])}")
        pos = x - 0.4 + width / 2 + j * width
        bars = ax.bar(pos, vals, width=width, label=case)
        for bar, text in zip(bars, labels):
            if text and np.isfinite(bar.get_height()):
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height()+1.0, text, ha="center", va="bottom", fontsize=8)
    ax.set_xticks(x, [f"{float(t):g}%" for t in thresholds])
    ax.set_ylim(0, 110)
    ax.set_xlabel("유효 식생셀 점유율 판정 기준")
    ax.set_ylabel("100년 시간단위 일치율 (%)")
    ax.set_title("고식생 100년 시간단위 검증")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def make_interval_area_fraction_chart(validation_rows_by_case: Dict[str, list], output_path: Path) -> None:
    """Grouped bar chart of record-level time-weighted basin area fractions."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    setup_korean_matplotlib()

    blocks = []
    for case_label, records in validation_rows_by_case.items():
        for rec in records or []:
            r = dict(rec)
            r["case_label"] = case_label
            blocks.append(r)
    if not blocks:
        return
    df = pd.DataFrame(blocks)
    order = list(dict.fromkeys(df["record_id"].astype(str).tolist()))
    cases = list(dict.fromkeys(df["case_label"].astype(str).tolist()))
    x = np.arange(len(order), dtype="float64")
    width = 0.8 / max(len(cases), 1)

    fig, ax = plt.subplots(figsize=(max(8.0, len(order) * 1.35), 5.2))
    for j, case in enumerate(cases):
        sub = df[df["case_label"].astype(str) == case].set_index(df[df["case_label"].astype(str) == case]["record_id"].astype(str))
        vals = [
            float(sub.loc[rid, "time_weighted_mean_basin_percent"]) if rid in sub.index else np.nan
            for rid in order
        ]
        offsets = x - 0.4 + width / 2 + j * width
        ax.bar(offsets, vals, width=width, label=case)
    labels = []
    for rid in order:
        rec = df[df["record_id"].astype(str) == rid].iloc[0]
        labels.append(f"{rid}\n{float(rec['age_start_ka_bp']):g}–{float(rec['age_end_ka_bp']):g} ka")
    ax.set_xticks(x, labels, rotation=0)
    ax.set_ylabel("관측 식생의 시간가중 평균 유역면적비율 (%)")
    ax.set_ylim(bottom=0)
    ax.set_title("고식생 구간별 모델 적합도")
    ax.legend(frameon=False)
    fig.tight_layout()
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def setup_korean_matplotlib() -> None:
    """Windows(설치 대상 환경)에서는 보통 Malgun Gothic이 잡힌다. 리눅스 개발환경에서는
    Noto Sans CJK KR 등을 우선 사용해 그래프의 한글 라벨이 깨지지 않도록 한다."""
    import matplotlib.pyplot as _plt
    import matplotlib.font_manager as _fm

    candidates = [
        "Malgun Gothic", "맑은 고딕", "NanumGothic", "Nanum Gothic",
        "Noto Sans CJK KR", "Noto Sans KR", "Noto Sans CJK JP", "Noto Sans CJK SC",
        "AppleGothic", "Arial Unicode MS",
    ]
    available = {f.name for f in _fm.fontManager.ttflist}
    chosen = next((name for name in candidates if name in available), None)
    _plt.rcParams["font.family"] = chosen or "DejaVu Sans"
    _plt.rcParams["axes.unicode_minus"] = False
    _plt.rcParams["figure.dpi"] = 120


def make_accuracy_bar_chart(accuracy_df: pd.DataFrame, output_path: Path) -> None:
    """Single-threshold chart for the selected palaeovegetation accuracy method."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    setup_korean_matplotlib()

    if accuracy_df.empty:
        return
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    labels = accuracy_df["case_label"].astype(str).tolist()
    x = np.arange(len(labels), dtype="float64")
    accuracy = accuracy_df["accuracy_pct"].astype(float).to_numpy()
    threshold_pct = (
        float(accuracy_df["basin_presence_min_percent"].iloc[0])
        if "basin_presence_min_percent" in accuracy_df.columns else 10.0
    )

    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    bars = ax.bar(x, accuracy, width=0.55)
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 110)
    method = str(accuracy_df.get("primary_accuracy_method", pd.Series(["basin_presence_fraction_per_output_time"])).iloc[0])
    if method == "interval_any_dt":
        ax.set_ylabel("고식생 구간 일치율 (%)")
        ax.set_title(f"고식생 구간 내 최소 1회(dt) 출현율 (유역 내 {threshold_pct:g}% 이상)")
    else:
        ax.set_ylabel("출력시점(dt)별 일치율 (%)")
        ax.set_title(f"고식생 출력시점(dt)별 일치율 (유역 내 {threshold_pct:g}% 이상)")
    for bar, (_, row) in zip(bars, accuracy_df.iterrows()):
        ax.text(
            bar.get_x() + bar.get_width() / 2, bar.get_height() + 1.5,
            f"{int(row['correct_n'])}/{int(row.get('n', 0))}\n{row['accuracy_pct']:.1f}%",
            ha="center", va="bottom", fontsize=9,
        )
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)

