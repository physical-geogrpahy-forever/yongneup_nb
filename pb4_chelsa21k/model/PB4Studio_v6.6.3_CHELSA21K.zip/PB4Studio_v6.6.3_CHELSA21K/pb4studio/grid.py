# -*- coding: utf-8 -*-
"""
grid.py — DEM(지형) 기준 좌표계/셀크기 자동감지, 유역 지오메트리 로딩(임의 CRS
자동 재투영), 기후/토심/토성 등 나머지 자료를 분석 격자로 재투영.

핵심 원칙 (요구사항 그대로):
    "좌표계와 셀 크기는 지형에 맞춥니다."
    → 분석 격자의 CRS와 해상도(dx)는 항상 사용자가 불러온 DEM에서 그대로
      가져온다. 다른 모든 입력자료(유역 폴리곤, 기후 NetCDF, 토심/토성
      래스터)는 각자의 원본 CRS를 자동으로 읽어 DEM 기준 CRS로 재투영한다.

이 파일의 함수 대부분은 yongneup_dynstat20m 패키지에서 검증된 로직을 그대로
가져오되, "target_crs='EPSG:5187' 하드코딩" 부분만 "DEM에서 자동 감지한
CRS/해상도"로 일반화했다.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np
import rasterio
from rasterio import features
from rasterio.enums import Resampling
from rasterio.transform import from_origin
from rasterio.warp import transform as warp_transform


class GridDetectionError(ValueError):
    """DEM이나 유역 자료의 좌표계/격자 정보를 확정할 수 없을 때 발생."""


# ---------------------------------------------------------------------------
# 1) DEM에서 CRS/해상도 자동감지
# ---------------------------------------------------------------------------

def detect_target_grid_from_dem(dem_path: Path, square_tolerance: float = 1e-3) -> Dict[str, object]:
    """DEM 파일을 열어 분석 격자가 따라야 할 CRS와 셀크기(dx)를 결정한다.

    Returns
    -------
    dict with keys: crs (rasterio CRS), resolution_m (float, 정사각 셀 가정),
    dem_transform, dem_shape, warnings (list[str])
    """
    warnings: List[str] = []
    with rasterio.open(dem_path) as src:
        if src.crs is None:
            raise GridDetectionError(
                f"DEM({dem_path})에 좌표계 정보가 없습니다. GeoTIFF에 CRS가 저장되어 "
                "있어야 자동 감지가 가능합니다."
            )
        crs = src.crs
        transform = src.transform
        shape = (src.height, src.width)

    dx = abs(transform.a)
    dy = abs(transform.e)
    if dx <= 0 or dy <= 0:
        raise GridDetectionError(f"DEM 픽셀 크기가 비정상적입니다: dx={dx}, dy={dy}")
    if abs(dx - dy) / max(dx, dy) > square_tolerance:
        warnings.append(
            f"DEM 셀이 정사각형이 아닙니다 (dx={dx:.4f} m, dy={dy:.4f} m). "
            f"이 모델은 정사각 셀을 가정하므로 dx={dx:.4f} m를 대표값으로 사용합니다."
        )
    if crs.is_geographic:
        warnings.append(
            f"DEM 좌표계({crs})가 위경도(지리) 좌표계입니다. 이 모델은 미터 단위 투영좌표계를 "
            "가정합니다 — 셀 크기·거리 계산이 부정확할 수 있으니 투영좌표계 DEM 사용을 권장합니다."
        )

    return {
        "crs": crs,
        "resolution_m": float(dx),
        "dem_transform": transform,
        "dem_shape": shape,
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# 2) 유역 지오메트리 로딩 (임의 형식/CRS, 자동 재투영)
# ---------------------------------------------------------------------------

def load_basin_geometry(path: Path, target_crs) -> Dict[str, object]:
    """유역 폴리곤을 읽어 target_crs(=DEM CRS)로 재투영한다.

    geojson, shp, gpkg 등 geopandas가 읽을 수 있는 모든 벡터 포맷을 지원한다.
    원본 CRS가 target_crs와 다르면 자동으로 재투영하고, 원본에 CRS 정보가 아예
    없으면 (자동으로 알아낼 방법이 없으므로) 명확한 에러를 낸다.
    """
    import geopandas as gpd

    gdf = gpd.read_file(path)
    if gdf.empty:
        raise GridDetectionError(f"유역 파일({path})에 지오메트리가 없습니다.")

    if gdf.crs is None:
        raise GridDetectionError(
            f"유역 파일({path})에 좌표계 정보가 없어 자동 재투영이 불가능합니다. "
            "파일에 CRS를 지정해서 다시 불러와주세요."
        )
    if str(gdf.crs) != str(target_crs):
        gdf = gdf.to_crs(target_crs)

    gdf = gdf[gdf.geometry.notna() & ~gdf.geometry.is_empty]
    gdf = gdf[gdf.geometry.type.isin(["Polygon", "MultiPolygon"])]
    if gdf.empty:
        raise GridDetectionError(f"유역 파일({path})에 Polygon/MultiPolygon 지오메트리가 없습니다.")

    geometries = [geom.__geo_interface__ for geom in gdf.geometry]
    minx, miny, maxx, maxy = gdf.total_bounds
    return {
        "geometries": geometries,
        "bounds": (float(minx), float(miny), float(maxx), float(maxy)),
        "crs": target_crs,
    }


# ---------------------------------------------------------------------------
# 3) DEM 원점에 정렬된 분석 격자 생성
# ---------------------------------------------------------------------------

def build_target_grid_from_dem(dem_path: Path, basin_geom: Dict, resolution_m: float, pad_cells: float = 1.0):
    """DEM 원점(origin)에 스냅된, 유역 범위를 감싸는 분석 격자를 만든다.

    DEM이 여러 해상도로 리샘플링되어도(용늪 패키지의 10/20/30/50 m 비교처럼)
    항상 같은 원점 격자에 정렬되도록 DEM의 좌상단 원점 기준으로 셀 경계를
    스냅한다.
    """
    with rasterio.open(dem_path) as src:
        x_origin = float(src.transform.c)
        y_origin = float(src.transform.f)

    minx, miny, maxx, maxy = basin_geom["bounds"]
    res = float(resolution_m)
    pad = res * float(pad_cells)
    col_min = math.floor((minx - pad - x_origin) / res)
    col_max = math.ceil((maxx + pad - x_origin) / res)
    row_min = math.floor((y_origin - (maxy + pad)) / res)
    row_max = math.ceil((y_origin - (miny - pad)) / res)

    left = x_origin + col_min * res
    top = y_origin - row_min * res
    width = int(col_max - col_min)
    height = int(row_max - row_min)
    transform = from_origin(left, top, res, res)
    return transform, (height, width)


def rasterize_basin(basin_geom: Dict, transform, shape: Tuple[int, int], all_touched: bool = False) -> np.ndarray:
    shapes = [(geom, 1) for geom in basin_geom["geometries"]]
    mask = features.rasterize(
        shapes, out_shape=shape, transform=transform, fill=0, dtype="uint8",
        all_touched=bool(all_touched),
    ).astype(bool)
    return mask


# ---------------------------------------------------------------------------
# 4) 임의 CRS의 래스터를 분석 격자로 집계/재투영 (메모리 최적화: windowed read)
# ---------------------------------------------------------------------------

def aggregate_raster_to_grid(
    src_path: Path,
    dst_crs,
    dst_transform,
    dst_shape: Tuple[int, int],
    method: Resampling = Resampling.average,
) -> np.ndarray:
    """소스 래스터(임의 CRS/해상도)를 분석 격자로 집계한다.

    전역/전국 단위의 큰 래스터(예: 1 km 토심 자료)라도 목적 격자가 덮는 범위만
    windowed read로 읽어 메모리 사용량을 억제한다 (결과는 전체를 읽는 것과
    수학적으로 동일 — 2026-07-02 리눅스 재현 검증 시 확인됨).
    """
    from rasterio.warp import reproject
    from rasterio.crs import CRS

    out = np.full(dst_shape, np.nan, dtype="float32")
    dst_crs_obj = CRS.from_user_input(dst_crs)
    with rasterio.open(src_path) as src:
        dst_height, dst_width = dst_shape
        corners_x = [dst_transform.c, dst_transform.c + dst_width * dst_transform.a]
        corners_y = [dst_transform.f, dst_transform.f + dst_height * dst_transform.e]
        minx_d, maxx_d = min(corners_x), max(corners_x)
        miny_d, maxy_d = min(corners_y), max(corners_y)

        if src.crs is not None and dst_crs_obj != src.crs:
            xs = [minx_d, maxx_d, minx_d, maxx_d]
            ys = [miny_d, miny_d, maxy_d, maxy_d]
            sx, sy = warp_transform(dst_crs_obj, src.crs, xs, ys)
            minx_s, maxx_s = min(sx), max(sx)
            miny_s, maxy_s = min(sy), max(sy)
        else:
            minx_s, maxx_s, miny_s, maxy_s = minx_d, maxx_d, miny_d, maxy_d

        pad_x = abs(src.transform.a) * 4 + abs(dst_transform.a)
        pad_y = abs(src.transform.e) * 4 + abs(dst_transform.e)
        win = rasterio.windows.from_bounds(
            minx_s - pad_x, miny_s - pad_y, maxx_s + pad_x, maxy_s + pad_y,
            transform=src.transform,
        ).round_lengths().round_offsets()
        win = win.intersection(rasterio.windows.Window(0, 0, src.width, src.height))

        if win.width <= 0 or win.height <= 0:
            src_arr = src.read(1)
            src_transform_used = src.transform
        else:
            src_arr = src.read(1, window=win)
            src_transform_used = rasterio.windows.transform(win, src.transform)

        reproject(
            source=src_arr, destination=out,
            src_transform=src_transform_used, src_crs=src.crs, src_nodata=src.nodata,
            dst_transform=dst_transform, dst_crs=dst_crs_obj, dst_nodata=np.nan,
            resampling=method,
        )
    return out.astype("float32")


# ---------------------------------------------------------------------------
# 5) 격자 좌표(투영좌표 + 위경도)
# ---------------------------------------------------------------------------

def grid_coordinates(transform, shape: Tuple[int, int], target_crs):
    """격자의 각 셀 중심 좌표를 target_crs(x/y)와 EPSG:4326(lon/lat, BIOME4 입력용)로 반환."""
    rows, cols = np.indices(shape)
    xs = transform.c + (cols + 0.5) * transform.a
    ys = transform.f + (rows + 0.5) * transform.e
    lon_flat, lat_flat = warp_transform(target_crs, "EPSG:4326", xs.ravel().tolist(), ys.ravel().tolist())
    lon = np.asarray(lon_flat, dtype="float64").reshape(shape)
    lat = np.asarray(lat_flat, dtype="float64").reshape(shape)
    return xs.astype("float64"), ys.astype("float64"), lon, lat


# ---------------------------------------------------------------------------
# 6) 토심(BDRICM)/토성(3분류) 로딩 — yongneup_dynstat20m에서 그대로 이식
# ---------------------------------------------------------------------------

def aggregate_soil_depth_to_grid(src_path: Path, dst_crs, dst_transform, dst_shape, unit: str = "cm") -> np.ndarray:
    """토심(예: SoilGrids BDRICM 기반암깊이) 래스터를 읽어 미터 단위로 변환한다."""
    depth = aggregate_raster_to_grid(src_path, dst_crs, dst_transform, dst_shape, Resampling.average)
    unit = str(unit).lower()
    if unit in ("cm", "centimeter", "centimetre", "centimeters", "centimetres"):
        depth = depth / 100.0
    elif unit in ("mm", "millimeter", "millimetre", "millimeters", "millimetres"):
        depth = depth / 1000.0
    elif unit in ("m", "meter", "metre", "meters", "metres"):
        pass
    elif unit == "auto":
        med = float(np.nanmedian(depth))
        if med > 20.0:
            depth = depth / 100.0
    else:
        raise ValueError(f"지원하지 않는 soil_depth 단위: {unit}")
    return depth.astype("float32")


def _detect_column(columns: Iterable[str], candidates: Iterable[str]) -> str | None:
    lower = {str(c).lower(): str(c) for c in columns}
    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    return None


def _nearest_table_values_to_grid(df, xcol: str, ycol: str, vcol: str, x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """(CSV 형태의 토성 테이블용) 격자 각 셀에 가장 가까운 테이블 값을 배정."""
    from scipy.spatial import cKDTree
    pts = df[[xcol, ycol]].to_numpy(dtype="float64")
    vals = df[vcol].to_numpy(dtype="float64")
    q = np.column_stack([x.ravel(), y.ravel()]).astype("float64")
    dist, idx = cKDTree(pts).query(q, k=1)
    return vals[idx].reshape(x.shape)


def load_soil_texture_class_grid(
    src_path: Path, dst_crs, dst_transform, dst_shape,
    x: np.ndarray, y: np.ndarray, lon: np.ndarray, lat: np.ndarray,
) -> np.ndarray:
    """SoilGrids 기반 3분류(1=조립질,2=중립질,3=세립질) 토성 자료를 읽는다.

    래스터(권장) 또는 좌표컬럼+분류컬럼이 있는 CSV 테이블을 모두 지원한다.
    """
    src_path = Path(src_path)
    if src_path.suffix.lower() in (".tif", ".tiff", ".img", ""):
        try:
            tex = aggregate_raster_to_grid(src_path, dst_crs, dst_transform, dst_shape, Resampling.nearest)
            return np.rint(tex).astype("float32")
        except Exception:
            if src_path.suffix.lower() in (".tif", ".tiff", ".img"):
                raise
    if src_path.suffix.lower() not in (".csv", ""):
        raise ValueError(f"지원하지 않는 토성 자료 형식: {src_path}")

    import pandas as pd
    df = pd.read_csv(src_path)
    vcol = _detect_column(df.columns, [
        "biome4_texture_class", "biome4_soil_class", "texture_class", "soil_texture_class",
        "texture_3class", "class", "soilclass", "value",
    ])
    if vcol is None:
        raise ValueError(f"토성 3분류 컬럼을 찾을 수 없습니다: {src_path}. columns={list(df.columns)}")
    xcol = _detect_column(df.columns, ["x_5187", "x", "easting", "X"])
    ycol = _detect_column(df.columns, ["y_5187", "y", "northing", "Y"])
    if xcol is not None and ycol is not None:
        out = _nearest_table_values_to_grid(df, xcol, ycol, vcol, x, y)
    else:
        loncol = _detect_column(df.columns, ["lon", "longitude", "long", "x_ll"])
        latcol = _detect_column(df.columns, ["lat", "latitude", "y_ll"])
        if loncol is None or latcol is None:
            raise ValueError(f"토성 테이블에 x/y 또는 lon/lat 컬럼이 필요합니다: {src_path}")
        out = _nearest_table_values_to_grid(df, loncol, latcol, vcol, lon, lat)
    return np.rint(out).astype("float32")
