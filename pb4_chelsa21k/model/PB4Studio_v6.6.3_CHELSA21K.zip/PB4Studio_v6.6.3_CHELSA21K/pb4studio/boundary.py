# -*- coding: utf-8 -*-
"""
경계 조건 데이터 모델.

유역 그리드의 각 셀은 다음 4가지 상태 중 하나를 가진다.

    interior          : 일반 계산 셀 (기본값)
    closed            : 유출 없음 (반사 경계, 물/퇴적물이 여기로는 못 빠져나감)
    open_free         : 자유 라우팅 유출 — 라우팅에는 미세 tie-break만 사용.
                         지형발달 상태(z/b/h)는 fixed base-level 경계로 유지.
    open_fixed_slope  : 일정 경사 라우팅 유출 — 사용자가 지정한 공통 경사값(%)만큼
                         라우팅 표면에 경사를 부여하되, 지형발달 상태(z/b/h)는
                         fixed base-level 경계로 유지.

GUI 경계 편집기는 이 배열을 페인트 툴로 채우고 JSON으로 저장/불러오기한다.
기존 yongneup 패키지의 단일 outlet(outlet_x/outlet_y) 방식은
``BoundaryConfig.from_legacy_single_outlet()`` 으로 하위호환한다.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np


class BoundaryType(IntEnum):
    INTERIOR = 0
    CLOSED = 1
    OPEN_FREE = 2
    OPEN_FIXED_SLOPE = 3


_NAME_TO_TYPE = {
    "interior": BoundaryType.INTERIOR,
    "closed": BoundaryType.CLOSED,
    "open_free": BoundaryType.OPEN_FREE,
    "open_fixed_slope": BoundaryType.OPEN_FIXED_SLOPE,
}
_TYPE_TO_NAME = {v: k for k, v in _NAME_TO_TYPE.items()}


def _land_boundary_cells(land_mask: np.ndarray) -> set:
    """유역(land) 가장자리 셀 집합을 반환한다 (격자 테두리이거나, 8-이웃 중
    하나 이상이 land가 아닌 셀). D8 흐름 라우팅은 대각선 이웃으로도 흐르므로
    대각선 인접도 "경계"로 취급한다 (validate()의 판정 기준과 동일)."""
    land_mask = np.asarray(land_mask, dtype=bool)
    nrows, ncols = land_mask.shape
    boundary = set()
    rows, cols = np.where(land_mask)
    for r, c in zip(rows.tolist(), cols.tolist()):
        if r == 0 or c == 0 or r == nrows - 1 or c == ncols - 1:
            boundary.add((r, c))
            continue
        is_boundary = False
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                if not land_mask[r + dr, c + dc]:
                    is_boundary = True
                    break
            if is_boundary:
                break
        if is_boundary:
            boundary.add((r, c))
    return boundary


def _nearest_cell_in_set(cell, candidate_set: set, max_radius: int):
    """candidate_set 안에서 cell로부터 가장 가까운 셀을 찾는다 (반경 max_radius 까지,
    체비쇼프 거리 기준 링 단위로 확장 탐색). 못 찾으면 None."""
    if not candidate_set:
        return None
    r0, c0 = cell
    best = None
    best_dist = None
    for radius in range(0, max_radius + 1):
        found_this_ring = False
        for dr in range(-radius, radius + 1):
            for dc in range(-radius, radius + 1):
                if max(abs(dr), abs(dc)) != radius:
                    continue
                cand = (r0 + dr, c0 + dc)
                if cand in candidate_set:
                    found_this_ring = True
                    dist = dr * dr + dc * dc
                    if best_dist is None or dist < best_dist:
                        best_dist = dist
                        best = cand
        if best is not None and found_this_ring:
            return best
    return best


@dataclass
class BoundaryConfig:
    """유역 그리드 전체에 대한 경계 조건."""

    boundary_type: np.ndarray  # uint8, shape == land grid shape
    common_slope_percent: float = 0.5  # open_fixed_slope 셀에 적용되는 유역 공통 경사(%)
    free_tie_break_eps_m: float = 0.0001  # open_free 셀의 평탄 영역 타이브레이크용 미세 경사(m/cell)

    # 하위호환/회귀테스트 전용: 특정 open 셀에 대해 위 규칙 대신 명시적 eps(m/cell)를
    # 강제로 사용하고 싶을 때 {(row, col): eps_m} 형태로 지정한다. 일반 사용자 워크플로우
    # (GUI)에서는 비워 둔다.
    legacy_eps_override_m: dict = field(default_factory=dict)

    # from_shapefiles()로 생성한 경우, 각 shp에서 실제로 몇 개 셀이 open으로
    # 매칭됐는지 (GUI 미리보기/검증 메시지용). 그 외 경로로 만든 경우 None.
    shapefile_hit_counts: Optional[dict] = None

    # from_shapefiles(snap_to_land_boundary=True)로 생성한 경우, 실제로 스냅이
    # 일어난 셀들의 내역 ({"type","from","to","distance_cells"} 목록).
    snap_report: List[dict] = field(default_factory=list)

    def __post_init__(self):
        self.boundary_type = np.asarray(self.boundary_type, dtype=np.uint8)

    # ------------------------------------------------------------------
    # 조회
    # ------------------------------------------------------------------
    @property
    def shape(self) -> Tuple[int, int]:
        return tuple(self.boundary_type.shape)

    def cells_of_type(self, t: BoundaryType) -> List[Tuple[int, int]]:
        rows, cols = np.where(self.boundary_type == int(t))
        return list(zip(rows.tolist(), cols.tolist()))

    def open_free_cells(self) -> List[Tuple[int, int]]:
        return self.cells_of_type(BoundaryType.OPEN_FREE)

    def open_fixed_slope_cells(self) -> List[Tuple[int, int]]:
        return self.cells_of_type(BoundaryType.OPEN_FIXED_SLOPE)

    def all_open_cells(self) -> List[Tuple[int, int]]:
        rows, cols = np.where(
            (self.boundary_type == int(BoundaryType.OPEN_FREE))
            | (self.boundary_type == int(BoundaryType.OPEN_FIXED_SLOPE))
        )
        return list(zip(rows.tolist(), cols.tolist()))

    def eps_m_for_cell(self, rc: Tuple[int, int], dx_m: float) -> float:
        """이 open 셀에 적용할 경사-바이어스(m / cell)를 반환한다."""
        if rc in self.legacy_eps_override_m:
            return float(self.legacy_eps_override_m[rc])
        t = BoundaryType(int(self.boundary_type[rc]))
        if t == BoundaryType.OPEN_FIXED_SLOPE:
            return float(self.common_slope_percent) / 100.0 * float(dx_m)
        if t == BoundaryType.OPEN_FREE:
            return float(self.free_tie_break_eps_m)
        raise ValueError(f"{rc} is not an open cell (type={t.name})")

    # ------------------------------------------------------------------
    # 검증
    # ------------------------------------------------------------------
    def validate(self, land_mask: np.ndarray, require_component_outlet: bool = False) -> List[str]:
        """경계 설정을 점검하고 경고 메시지 목록을 반환한다.

        ``require_component_outlet``가 True이면 D8과 같은 8-연결 land
        연결성분마다 최소 하나의 open 경계를 요구한다. 유효한 기존 단일유역
        실행의 수치결과는 바꾸지 않고, 고립된 land 조각의 무출구 설정만
        실행 전에 차단한다.
        """
        warnings: List[str] = []
        land_mask = np.asarray(land_mask, dtype=bool)
        if self.boundary_type.shape != land_mask.shape:
            warnings.append(
                f"boundary_type shape {self.boundary_type.shape} != land_mask shape {land_mask.shape}"
            )
            return warnings

        open_cells = self.all_open_cells()
        if not open_cells:
            warnings.append("open 경계가 하나도 지정되지 않았습니다. 최소 1개 이상 필요합니다.")

        nrows, ncols = land_mask.shape
        boundary_set = _land_boundary_cells(land_mask)
        for (r, c) in open_cells:
            if not land_mask[r, c]:
                warnings.append(f"({r},{c})는 open으로 지정되었지만 유역(land) 셀이 아닙니다.")
                continue
            if (r, c) not in boundary_set:
                nearest = _nearest_cell_in_set((r, c), boundary_set, max_radius=max(nrows, ncols))
                nearest_msg = ""
                if nearest is not None:
                    dist_cells = float(np.hypot(r - nearest[0], c - nearest[1]))
                    nearest_msg = (
                        f" 가장 가까운 유역 경계 셀은 ({nearest[0]},{nearest[1]})이고 "
                        f"약 {dist_cells:.1f}셀 떨어져 있습니다 — shp의 좌표를 그쪽으로 옮기는 것을 권장합니다."
                    )
                warnings.append(
                    f"({r},{c})는 유역 내부 셀입니다. open 경계는 통상 유역 경계(가장자리)에 "
                    f"지정해야 물리적으로 의미가 있습니다.{nearest_msg}"
                )

        if require_component_outlet and np.any(land_mask):
            open_set = {rc for rc in open_cells if land_mask[rc]}
            visited = np.zeros_like(land_mask, dtype=bool)
            nrows, ncols = land_mask.shape
            component_id = 0
            # np.where(...) is evaluated before the loop, so explicitly skip
            # seeds that were visited while flooding an earlier component.
            for r0, c0 in zip(*np.where(land_mask)):
                if visited[r0, c0]:
                    continue
                component_id += 1
                stack = [(int(r0), int(c0))]
                visited[r0, c0] = True
                cells = []
                has_open = False
                while stack:
                    r, c = stack.pop()
                    cells.append((r, c))
                    if (r, c) in open_set:
                        has_open = True
                    for dr in (-1, 0, 1):
                        for dc in (-1, 0, 1):
                            if dr == 0 and dc == 0:
                                continue
                            rr, cc = r + dr, c + dc
                            if 0 <= rr < nrows and 0 <= cc < ncols and land_mask[rr, cc] and not visited[rr, cc]:
                                visited[rr, cc] = True
                                stack.append((rr, cc))
                if not has_open:
                    rs = [r for r, _ in cells]; cs = [c for _, c in cells]
                    warnings.append(
                        "동적 지형모델의 land 연결성분에 open 경계가 없습니다: "
                        f"component={component_id}, 셀수={len(cells)}, "
                        f"row={min(rs)}..{max(rs)}, col={min(cs)}..{max(cs)}"
                    )

        if not (0.0 <= float(self.common_slope_percent) < 100.0):
            warnings.append(
                f"common_slope_percent={self.common_slope_percent} 값이 비정상적입니다 (0~100 권장)."
            )
        return warnings

    # ------------------------------------------------------------------
    # 생성 헬퍼
    # ------------------------------------------------------------------
    @classmethod
    def all_closed(cls, shape: Tuple[int, int], common_slope_percent: float = 0.5) -> "BoundaryConfig":
        return cls(
            boundary_type=np.full(shape, int(BoundaryType.CLOSED), dtype=np.uint8),
            common_slope_percent=common_slope_percent,
        )

    def set_cells(self, cells: List[Tuple[int, int]], boundary_type: BoundaryType) -> None:
        for (r, c) in cells:
            self.boundary_type[r, c] = int(boundary_type)

    @classmethod
    def from_legacy_single_outlet(
        cls,
        shape: Tuple[int, int],
        outlet_rc: Tuple[int, int],
        eps_m: float = 0.001,
    ) -> "BoundaryConfig":
        """기존 yongneup 패키지의 단일 outlet(outlet_x/outlet_y) 설정과 동등한
        BoundaryConfig를 만든다. 회귀 테스트 및 하위호환 목적.
        """
        bt = np.full(shape, int(BoundaryType.CLOSED), dtype=np.uint8)
        bt[outlet_rc] = int(BoundaryType.OPEN_FIXED_SLOPE)
        cfg = cls(boundary_type=bt, common_slope_percent=0.0)
        cfg.legacy_eps_override_m = {tuple(outlet_rc): float(eps_m)}
        return cfg

    @classmethod
    def from_shapefiles(
        cls,
        land_mask: np.ndarray,
        transform,
        dst_crs,
        common_slope_percent: float = 0.5,
        open_free_shp: Optional[Path] = None,
        open_fixed_slope_shp: Optional[Path] = None,
        free_tie_break_eps_m: float = 0.0001,
        snap_to_land_boundary: bool = False,
        snap_search_radius_cells: int = 15,
    ) -> "BoundaryConfig":
        """점/선 shapefile로 open 경계를 지정한다.

        각 shp의 지오메트리(점 또는 선)와 겹치는 그리드 셀이 해당 open 유형으로
        지정되고, 나머지 모든 셀은 전부 closed가 된다. shp의 CRS가 격자 CRS와
        다르면 자동으로 재투영한다. 두 shp가 같은 셀을 가리키면
        open_fixed_slope가 우선한다(나중에 적용됨).

        open_free_shp / open_fixed_slope_shp 중 하나는 None이어도 된다(둘 다
        None이면 전부 closed인 경계가 만들어지며, 이 경우 validate()에서
        "open 경계가 하나도 지정되지 않았습니다" 경고가 뜬다).

        ``snap_to_land_boundary``(기본 False): shp가 가리키는 셀이 유역 내부
        셀이면(가장자리가 아니면), 기본적으로는 사용자가 준 좌표를 그대로
        쓴다 — outlet 위치가 유역 경계에서 벗어나 있다면 그건 입력 shp
        자체의 문제이므로, 소프트웨어가 조용히 좌표를 옮기기보다는 사용자가
        직접 shp를 고치는 게 맞다는 판단이다. validate()가 "내부 셀입니다"
        경고를 주는데, 이때 가장 가까운 경계 셀까지의 거리도 함께 알려줘서
        shp를 얼마나/어느 방향으로 고쳐야 하는지 감을 잡을 수 있게 한다.
        True로 켜면(편의 기능, 선택사항) 가장 가까운 유역 경계 셀로 자동
        이동시킨다 — 기존 yongneup 패키지의 단일 outlet 스냅 로직
        (outlet_prefer_boundary_cell)과 동일한 취지다. 스냅된 경우
        ``snap_report``에 내역이 기록된다.
        """
        import geopandas as gpd
        from rasterio.features import rasterize

        land_mask = np.asarray(land_mask, dtype=bool)
        shape = land_mask.shape
        bt = np.full(shape, int(BoundaryType.CLOSED), dtype=np.uint8)
        snap_report: List[dict] = []

        def _rasterize_onto(shp_path, type_value: int, type_name: str) -> int:
            if shp_path is None:
                return 0
            gdf = gpd.read_file(shp_path)
            if gdf.empty:
                return 0
            if gdf.crs is not None and str(gdf.crs) != str(dst_crs):
                gdf = gdf.to_crs(dst_crs)
            geoms = [(geom, 1) for geom in gdf.geometry if geom is not None and not geom.is_empty]
            if not geoms:
                return 0
            mask = rasterize(
                geoms, out_shape=shape, transform=transform,
                fill=0, all_touched=True, dtype="uint8",
            )
            hit_cells = list(zip(*np.where((mask == 1) & land_mask)))

            if snap_to_land_boundary:
                boundary_set = _land_boundary_cells(land_mask)
                final_cells = []
                for cell in hit_cells:
                    if cell in boundary_set:
                        final_cells.append(cell)
                        continue
                    snapped = _nearest_cell_in_set(cell, boundary_set, snap_search_radius_cells)
                    if snapped is None:
                        final_cells.append(cell)  # 반경 안에 경계셀이 없으면 원래 셀 유지
                    else:
                        dist = float(np.hypot(cell[0] - snapped[0], cell[1] - snapped[1]))
                        snap_report.append({
                            "type": type_name, "from": cell, "to": snapped, "distance_cells": dist,
                        })
                        final_cells.append(snapped)
                hit_cells = final_cells

            for r, c in hit_cells:
                bt[r, c] = type_value
            return len(hit_cells)

        n_free = _rasterize_onto(open_free_shp, int(BoundaryType.OPEN_FREE), "open_free")
        n_fixed = _rasterize_onto(open_fixed_slope_shp, int(BoundaryType.OPEN_FIXED_SLOPE), "open_fixed_slope")

        cfg = cls(boundary_type=bt, common_slope_percent=common_slope_percent,
                   free_tie_break_eps_m=free_tie_break_eps_m)
        cfg.shapefile_hit_counts = {"open_free": n_free, "open_fixed_slope": n_fixed}
        cfg.snap_report = snap_report
        return cfg

    # ------------------------------------------------------------------
    # 직렬화
    # ------------------------------------------------------------------
    def to_json(self, path: Path) -> None:
        payload = {
            "shape": list(self.shape),
            "common_slope_percent": float(self.common_slope_percent),
            "free_tie_break_eps_m": float(self.free_tie_break_eps_m),
            # sparse encoding: only non-interior cells are stored
            "cells": [
                {"row": int(r), "col": int(c), "type": _TYPE_TO_NAME[BoundaryType(int(v))]}
                for (r, c), v in np.ndenumerate(self.boundary_type)
                if v != int(BoundaryType.INTERIOR)
            ],
            "legacy_eps_override_m": {
                f"{r},{c}": float(v) for (r, c), v in self.legacy_eps_override_m.items()
            },
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def from_json(cls, path: Path) -> "BoundaryConfig":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        shape = tuple(payload["shape"])
        bt = np.full(shape, int(BoundaryType.INTERIOR), dtype=np.uint8)
        for cell in payload["cells"]:
            bt[cell["row"], cell["col"]] = int(_NAME_TO_TYPE[cell["type"]])
        cfg = cls(
            boundary_type=bt,
            common_slope_percent=float(payload.get("common_slope_percent", 0.5)),
            free_tie_break_eps_m=float(payload.get("free_tie_break_eps_m", 0.0001)),
        )
        cfg.legacy_eps_override_m = {
            tuple(int(x) for x in k.split(",")): float(v)
            for k, v in payload.get("legacy_eps_override_m", {}).items()
        }
        return cfg
