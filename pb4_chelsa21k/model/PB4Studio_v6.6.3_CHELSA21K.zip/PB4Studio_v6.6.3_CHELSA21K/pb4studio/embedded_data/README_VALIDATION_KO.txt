PB4 Yongneup production primary validation
==========================================
주 검증은 Jang et al. (2011) record 95_01~95_04만 사용합니다.
corrected reduced mapping: 95_01=활엽수림(1), 95_02=혼효림(2), 95_03=활엽수림(1), 95_04=혼효림(2).
0.1 kyr 출력에서 평가수는 62입니다. 1% criterion의 최종 기준값은 static 24/62, dynamic 55/62입니다.
Park et al. (2021)은 독립 holdout이며 이 categorical primary score에 합치지 않습니다.
