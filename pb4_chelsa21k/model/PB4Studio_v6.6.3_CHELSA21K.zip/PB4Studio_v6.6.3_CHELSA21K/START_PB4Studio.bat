@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m gui.main
) else (
  python -m gui.main
)
if errorlevel 1 (
  echo.
  echo PB4Studio failed to start. See the error message above and pb4studio_startup.log.
  pause
)
endlocal
