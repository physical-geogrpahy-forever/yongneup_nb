PB4Studio CHELSA21K U008 AUDITED FULL EXPORT
===============================================

버전
- 6.6.3-CHELSA21K-FINAL-nativeClimate-BIOME4AGB-U008
- regional uplift U = 0.08 m/kyr

실행
1. FIRST_RUN_SETUP.bat 최초 1회
2. START_PB4Studio.bat: GUI
3. RUN_YONGNEUP_21KA_AND_EXPORT_ALL.bat: 21 ka 전체 실행 및 전체 출력

시간축/출력
- 21.0 ka BP -> 0.0 ka BP
- 0.1 kyr 간격, 총 211 시점
- GUI 기본도 매 스텝 snapshot 저장(스냅샷 간격 0)
- 표준 결과판 지도 시점: 21, 10, 5, 0 ka BP

주 고식생 검증
- Jang et al. (2011) 4개 record만 사용
- corrected reduced mapping: 95_01=활엽수림, 95_02=혼효림, 95_03=활엽수림, 95_04=혼효림
- 0.1 kyr output-time 평가 n=62
- 1% criterion 기준 최종 회귀값: static 24/62, dynamic 55/62
- Park et al. (2021)은 독립 holdout이며 주 정확도에 합산하지 않음

고도/토심/NPP 시계열 그림
- plot_chelsa_climate.py와 동일한 형식
- x축 21 -> 0 ka BP
- 동적모델 firebrick 1.6, 정적모델 royalblue 1.4
- 제목/grid 없음, 범례 좌상단 frame 없음, PNG 600 dpi

CHECK_CHELSA21K_CONTRACT.bat으로 패키지 계약을 점검할 수 있습니다.
