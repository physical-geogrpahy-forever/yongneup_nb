@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)
%PY% -m pip install --upgrade pip
if errorlevel 1 goto :fail
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto :fail
echo.
echo Python packages installed. If BIOME4 compilation reports that gfortran is missing, install a 64-bit gfortran compiler and ensure gfortran is available on PATH.
echo.
pause
exit /b 0
:fail
echo.
echo Setup failed. Copy the error message and send it for diagnosis.
pause
exit /b 1
