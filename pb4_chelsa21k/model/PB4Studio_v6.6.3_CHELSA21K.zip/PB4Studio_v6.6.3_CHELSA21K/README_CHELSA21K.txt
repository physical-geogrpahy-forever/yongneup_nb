PB4Studio v6.6.3 CHELSA21K

이 배포판은 기존 Beyer 120 ka 배포판과 분리된 CHELSA-TraCE21k 전용판입니다.

고정 규칙
1. 기후입력: CHELSA EnviCloud RAW WIDE CSV
2. 허용 시간: 0~21 ka BP. GUI 및 TimeConfig가 21 ka 초과를 거부합니다.
3. 온도: tasmin/tasmax Kelvin을 읽고 월평균 ((tasmin+tasmax)/2)-273.15 로 섭씨 변환합니다.
4. 강수: CHELSA pr_raw를 월 강수량 수치로 그대로 사용합니다.
5. 고도보정: 적용하지 않습니다. lapse_rate_C_per_m = 0으로 강제합니다. CHELSA는 이미 지형 하향조정 자료입니다.
6. cloud: CHELSA-TraCE21k Centennial에는 cloud 변수가 없으므로 BIOME4 필수 광입력을 위해 내장 Beyer cloud_pct 0~21 ka만 보조자료로 선형보간합니다. 온도/강수에는 Beyer 값을 사용하지 않습니다.
7. absolute Tmin: CHELSA에 BIOME4 absolute Tmin이 없으므로 BIOME4 원본 회귀식 alttmin = 0.006*cold^2 + 1.316*cold - 21.9를 사용합니다.
8. CO2: 기존 PB4Studio와 동일하게 내장 Bereiter 2015 record를 사용합니다.

기본 기후파일
embedded_inputs/yongneup_exact20m/YONGNEUP_CHELSA_TRACE21k_ENVICLOUD_RAW_WIDE.csv

검증
CHECK_CHELSA21K_CONTRACT.bat

기존 120 ka/Beyer 모델을 사용하려면 별도 PB4Studio_v6.6.3_BEYER120K 배포판을 사용하십시오.
