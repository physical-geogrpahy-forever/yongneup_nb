# -*- coding: utf-8 -*-
"""PB4Studio engine layer (GUI-independent, CLI-compatible)."""

__version__ = '6.6.3-corrected-hotfix10n10-biome4-sd-mckenzie2003-soilgrids-panel590-pft5m19gdd900-sitch2003bone-tw23-sc15-20m-mixband51-allpft-interptime-selfcontained-standardreport-layoutfix1'
